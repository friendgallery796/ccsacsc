<?php
/**
 * Template Name: Team Page
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor
$is_elementor = class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID());

if ($is_elementor) :
    // Elementor content
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Default theme content

// Define theme URI fallback
$theme_uri = defined('TANWAR_URI') ? TANWAR_URI : get_template_directory_uri();

// Team members data
$team_members = array(
    array(
        'name' => 'Adv. Rajesh Tanwar',
        'role' => 'Senior Partner',
        'specialization' => 'Civil & Corporate Law',
        'experience' => '25+ Years',
        'education' => 'LL.M., Rajasthan University',
        'bar_council' => 'Bar Council of Rajasthan',
        'courts' => 'Supreme Court, Rajasthan High Court',
        'bio' => 'Adv. Rajesh Tanwar is the founding partner with over 25 years of experience in civil litigation and corporate law. He has successfully handled landmark cases at the Rajasthan High Court.',
        'image' => $theme_uri . '/images/attorney-1.jpg',
    ),
    array(
        'name' => 'Adv. Priya Sharma',
        'role' => 'Partner',
        'specialization' => 'Family & Matrimonial Law',
        'experience' => '18+ Years',
        'education' => 'LL.B., Delhi University',
        'bar_council' => 'Bar Council of Rajasthan',
        'courts' => 'Rajasthan High Court, Family Courts',
        'bio' => 'Adv. Priya Sharma specializes in family law matters including divorce, custody, and domestic violence cases. Known for her compassionate approach to sensitive cases.',
        'image' => $theme_uri . '/images/attorney-2.jpg',
    ),
    array(
        'name' => 'Adv. Vikram Singh',
        'role' => 'Associate Partner',
        'specialization' => 'Criminal Law',
        'experience' => '15+ Years',
        'education' => 'LL.M., NLSIU Bangalore',
        'bar_council' => 'Bar Council of Rajasthan',
        'courts' => 'Rajasthan High Court, Sessions Courts',
        'bio' => 'Adv. Vikram Singh handles criminal matters including bail applications, trials, and appeals. He has secured acquittals in numerous high-profile cases.',
        'image' => $theme_uri . '/images/attorney-3.jpg',
    ),
    array(
        'name' => 'Adv. Neha Agarwal',
        'role' => 'Senior Associate',
        'specialization' => 'Property & Real Estate',
        'experience' => '12+ Years',
        'education' => 'LL.B., Jodhpur University',
        'bar_council' => 'Bar Council of Rajasthan',
        'courts' => 'District Courts, RERA Tribunal',
        'bio' => 'Adv. Neha Agarwal is an expert in property law, title verification, RERA matters, and real estate documentation.',
        'image' => $theme_uri . '/images/attorney-4.jpg',
    ),
    array(
        'name' => 'Adv. Amit Joshi',
        'role' => 'Associate',
        'specialization' => 'Corporate & Commercial',
        'experience' => '8+ Years',
        'education' => 'LL.B., NLIU Bhopal',
        'bar_council' => 'Bar Council of Rajasthan',
        'courts' => 'NCLT, High Court',
        'bio' => 'Adv. Amit Joshi handles corporate matters including company formation, M&A, contract drafting, and NCLT proceedings.',
        'image' => $theme_uri . '/images/attorney-5.jpg',
    ),
    array(
        'name' => 'Adv. Sunita Meena',
        'role' => 'Associate',
        'specialization' => 'Consumer & Banking Law',
        'experience' => '6+ Years',
        'education' => 'LL.M., Rajasthan University',
        'bar_council' => 'Bar Council of Rajasthan',
        'courts' => 'Consumer Forums, DRT',
        'bio' => 'Adv. Sunita Meena specializes in consumer protection, banking disputes, cheque bounce cases, and recovery matters.',
        'image' => $theme_uri . '/images/attorney-6.jpg',
    ),
);

// Fallback image for team members
$fallback_image = 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=500&fit=crop';
?>

<div class="page-hero">
    <div class="container">
        <div class="page-hero-content">
            <nav class="breadcrumbs">
                <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                <span>/</span>
                <span>Our Team</span>
            </nav>
            <h1><?php esc_html_e('Our Legal Team', 'tanwar-associates'); ?></h1>
            <p><?php esc_html_e('Meet our experienced team of advocates dedicated to providing exceptional legal representation at Rajasthan High Court and beyond.', 'tanwar-associates'); ?></p>
        </div>
    </div>
</div>

<section class="section team">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle"><?php esc_html_e('Expert Advocates', 'tanwar-associates'); ?></span>
            <h2 class="section-title"><?php esc_html_e('Experienced Legal Professionals', 'tanwar-associates'); ?></h2>
            <p class="section-description"><?php esc_html_e('Our team combines decades of experience across all major practice areas to deliver outstanding results for our clients.', 'tanwar-associates'); ?></p>
        </div>

        <div class="team-grid">
            <?php foreach ($team_members as $member) : ?>
            <div class="team-card">
                <div class="team-card-image">
                    <img src="<?php echo esc_url($member['image']); ?>" alt="<?php echo esc_attr($member['name']); ?>" onerror="this.src='<?php echo esc_url($fallback_image); ?>'">
                    <div class="team-card-overlay">
                        <a href="<?php echo esc_url(home_url('/team/' . sanitize_title($member['name']) . '/')); ?>">
                            <?php esc_html_e('View Profile', 'tanwar-associates'); ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="team-card-body">
                    <h3 class="team-card-name"><?php echo esc_html($member['name']); ?></h3>
                    <p class="team-card-role"><?php echo esc_html($member['role']); ?></p>
                    <p class="team-card-specialization"><?php echo esc_html($member['specialization']); ?></p>
                    <p style="font-size: 0.8125rem; color: var(--muted-foreground); margin-top: 0.5rem;">
                        <?php echo esc_html($member['experience']); ?> Experience
                    </p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<!-- Why Our Team Section -->
<section class="section" style="background-color: var(--muted);">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle"><?php esc_html_e('Our Commitment', 'tanwar-associates'); ?></span>
            <h2 class="section-title"><?php esc_html_e('Why Choose Our Team', 'tanwar-associates'); ?></h2>
        </div>
        
        <div class="grid md:grid-cols-3 gap-8">
            <div class="card" style="text-align: center; padding: 2rem;">
                <div style="width: 60px; height: 60px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2">
                        <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                        <polyline points="22 4 12 14.01 9 11.01"></polyline>
                    </svg>
                </div>
                <h4><?php esc_html_e('High Court Expertise', 'tanwar-associates'); ?></h4>
                <p style="color: var(--muted-foreground); font-size: 0.9375rem;"><?php esc_html_e('Regular practice at Rajasthan High Court with extensive experience in constitutional and appellate matters.', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="card" style="text-align: center; padding: 2rem;">
                <div style="width: 60px; height: 60px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <h4><?php esc_html_e('Client-Centric Approach', 'tanwar-associates'); ?></h4>
                <p style="color: var(--muted-foreground); font-size: 0.9375rem;"><?php esc_html_e('We prioritize your needs and keep you informed at every step of your legal journey.', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="card" style="text-align: center; padding: 2rem;">
                <div style="width: 60px; height: 60px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 1rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2">
                        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                        <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                    </svg>
                </div>
                <h4><?php esc_html_e('Strict Confidentiality', 'tanwar-associates'); ?></h4>
                <p style="color: var(--muted-foreground); font-size: 0.9375rem;"><?php esc_html_e('All client information is protected under advocate-client privilege with utmost discretion.', 'tanwar-associates'); ?></p>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/contact-cta'); ?>

<?php endif; // End Elementor check ?>

<?php get_footer(); ?>
