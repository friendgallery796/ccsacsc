<?php
/**
 * Archive Template - Blog/News Listing
 * Fully Elementor Editable
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if Elementor Theme Builder handles this archive
if (function_exists('elementor_theme_do_location') && elementor_theme_do_location('archive')) {
    // Elementor Theme Builder archive template
} else {
    // Default theme content
    
// Get current archive info
$archive_title = '';
$archive_description = '';

if (is_category()) {
    $archive_title = single_cat_title('', false);
    $archive_description = category_description();
} elseif (is_tag()) {
    $archive_title = single_tag_title('', false);
    $archive_description = tag_description();
} elseif (is_author()) {
    $archive_title = get_the_author();
    $archive_description = get_the_author_meta('description');
} elseif (is_date()) {
    if (is_day()) {
        $archive_title = get_the_date();
    } elseif (is_month()) {
        $archive_title = get_the_date('F Y');
    } elseif (is_year()) {
        $archive_title = get_the_date('Y');
    }
} elseif (is_search()) {
    $archive_title = sprintf(__('Search Results for: %s', 'tanwar-associates'), get_search_query());
} else {
    $archive_title = __('Legal Insights & News', 'tanwar-associates');
    $archive_description = __('Stay informed with the latest legal updates, case studies, and expert insights from our team of advocates.', 'tanwar-associates');
}

// Get categories for filter
$categories = get_categories(array(
    'orderby' => 'name',
    'order'   => 'ASC',
    'hide_empty' => true,
));

// Pagination
$paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
?>

<div class="page-hero blog-hero">
    <div class="container">
        <div class="page-hero-content">
            <nav class="breadcrumbs">
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'tanwar-associates'); ?></a>
                <span>/</span>
                <?php if (is_category() || is_tag()) : ?>
                    <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts'))); ?>"><?php esc_html_e('Blog', 'tanwar-associates'); ?></a>
                    <span>/</span>
                <?php endif; ?>
                <span><?php echo esc_html($archive_title); ?></span>
            </nav>
            <h1><?php echo esc_html($archive_title); ?></h1>
            <?php if ($archive_description) : ?>
                <p><?php echo wp_kses_post($archive_description); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<section class="section blog-section">
    <div class="container">
        <div class="blog-layout">
            <!-- Main Content -->
            <div class="blog-main">
                <!-- Category Filter -->
                <?php if (!empty($categories) && !is_search()) : ?>
                <div class="blog-filter">
                    <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts')) ?: home_url('/blog/')); ?>" class="filter-tag <?php echo !is_category() ? 'active' : ''; ?>">
                        <?php esc_html_e('All', 'tanwar-associates'); ?>
                    </a>
                    <?php foreach ($categories as $category) : ?>
                        <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>" class="filter-tag <?php echo is_category($category->term_id) ? 'active' : ''; ?>">
                            <?php echo esc_html($category->name); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <!-- Posts Grid -->
                <?php if (have_posts()) : ?>
                <div class="posts-grid">
                    <?php 
                    $post_count = 0;
                    while (have_posts()) : the_post(); 
                        $post_count++;
                        $is_featured = ($post_count === 1 && $paged === 1 && !is_search());
                    ?>
                    <article class="post-card <?php echo $is_featured ? 'post-card-featured' : ''; ?>" id="post-<?php the_ID(); ?>">
                        <?php if (has_post_thumbnail()) : ?>
                        <a href="<?php the_permalink(); ?>" class="post-card-image">
                            <?php the_post_thumbnail($is_featured ? 'large' : 'medium_large', array('alt' => get_the_title())); ?>
                            <div class="post-card-image-overlay"></div>
                        </a>
                        <?php else : ?>
                        <a href="<?php the_permalink(); ?>" class="post-card-image post-card-image-placeholder">
                            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                <polyline points="14 2 14 8 20 8"></polyline>
                                <line x1="16" y1="13" x2="8" y2="13"></line>
                                <line x1="16" y1="17" x2="8" y2="17"></line>
                                <polyline points="10 9 9 9 8 9"></polyline>
                            </svg>
                        </a>
                        <?php endif; ?>
                        
                        <div class="post-card-content">
                            <div class="post-card-meta">
                                <?php 
                                $categories_list = get_the_category();
                                if (!empty($categories_list)) :
                                    $primary_cat = $categories_list[0];
                                ?>
                                <a href="<?php echo esc_url(get_category_link($primary_cat->term_id)); ?>" class="post-card-category">
                                    <?php echo esc_html($primary_cat->name); ?>
                                </a>
                                <?php endif; ?>
                                <span class="post-card-date">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                        <line x1="16" y1="2" x2="16" y2="6"></line>
                                        <line x1="8" y1="2" x2="8" y2="6"></line>
                                        <line x1="3" y1="10" x2="21" y2="10"></line>
                                    </svg>
                                    <?php echo get_the_date(); ?>
                                </span>
                            </div>
                            
                            <h2 class="post-card-title">
                                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                            </h2>
                            
                            <p class="post-card-excerpt">
                                <?php echo wp_trim_words(get_the_excerpt(), $is_featured ? 30 : 20, '...'); ?>
                            </p>
                            
                            <div class="post-card-footer">
                                <div class="post-card-author">
                                    <?php echo get_avatar(get_the_author_meta('ID'), 32); ?>
                                    <span><?php the_author(); ?></span>
                                </div>
                                <a href="<?php the_permalink(); ?>" class="post-card-link">
                                    <?php esc_html_e('Read More', 'tanwar-associates'); ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                        <polyline points="12 5 19 12 12 19"></polyline>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </article>
                    <?php endwhile; ?>
                </div>

                <!-- Pagination -->
                <nav class="blog-pagination">
                    <?php
                    the_posts_pagination(array(
                        'mid_size'  => 2,
                        'prev_text' => '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg> ' . __('Previous', 'tanwar-associates'),
                        'next_text' => __('Next', 'tanwar-associates') . ' <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>',
                    ));
                    ?>
                </nav>

                <?php else : ?>
                
                <div class="no-posts">
                    <svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                        <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                        <polyline points="14 2 14 8 20 8"></polyline>
                    </svg>
                    <h3><?php esc_html_e('No Articles Found', 'tanwar-associates'); ?></h3>
                    <p><?php esc_html_e('We couldn\'t find any articles matching your criteria. Please try a different search or browse our categories.', 'tanwar-associates'); ?></p>
                    <a href="<?php echo esc_url(home_url('/blog/')); ?>" class="btn btn-primary">
                        <?php esc_html_e('View All Articles', 'tanwar-associates'); ?>
                    </a>
                </div>

                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <aside class="blog-sidebar">
                <!-- Search -->
                <div class="sidebar-widget">
                    <h4><?php esc_html_e('Search', 'tanwar-associates'); ?></h4>
                    <form role="search" method="get" class="search-form" action="<?php echo esc_url(home_url('/')); ?>">
                        <input type="search" name="s" placeholder="<?php esc_attr_e('Search articles...', 'tanwar-associates'); ?>" value="<?php echo get_search_query(); ?>" class="form-control" maxlength="100">
                        <button type="submit" class="search-submit" aria-label="<?php esc_attr_e('Search', 'tanwar-associates'); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="11" cy="11" r="8"></circle>
                                <line x1="21" y1="21" x2="16.65" y2="16.65"></line>
                            </svg>
                        </button>
                    </form>
                </div>

                <!-- Categories -->
                <?php if (!empty($categories)) : ?>
                <div class="sidebar-widget">
                    <h4><?php esc_html_e('Categories', 'tanwar-associates'); ?></h4>
                    <ul class="category-list">
                        <?php foreach ($categories as $category) : ?>
                        <li>
                            <a href="<?php echo esc_url(get_category_link($category->term_id)); ?>">
                                <?php echo esc_html($category->name); ?>
                                <span class="count"><?php echo esc_html($category->count); ?></span>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Recent Posts -->
                <?php
                $recent_posts = get_posts(array(
                    'numberposts' => 5,
                    'post_status' => 'publish',
                ));
                if (!empty($recent_posts)) :
                ?>
                <div class="sidebar-widget">
                    <h4><?php esc_html_e('Recent Articles', 'tanwar-associates'); ?></h4>
                    <ul class="recent-posts-list">
                        <?php foreach ($recent_posts as $recent) : ?>
                        <li>
                            <a href="<?php echo esc_url(get_permalink($recent->ID)); ?>">
                                <?php if (has_post_thumbnail($recent->ID)) : ?>
                                    <?php echo get_the_post_thumbnail($recent->ID, 'thumbnail', array('class' => 'recent-post-thumb')); ?>
                                <?php else : ?>
                                    <div class="recent-post-thumb-placeholder">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                            <polyline points="14 2 14 8 20 8"></polyline>
                                        </svg>
                                    </div>
                                <?php endif; ?>
                                <div class="recent-post-info">
                                    <span class="recent-post-title"><?php echo esc_html($recent->post_title); ?></span>
                                    <span class="recent-post-date"><?php echo get_the_date('', $recent->ID); ?></span>
                                </div>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <!-- Tags -->
                <?php
                $tags = get_tags(array(
                    'orderby' => 'count',
                    'order'   => 'DESC',
                    'number'  => 15,
                ));
                if (!empty($tags)) :
                ?>
                <div class="sidebar-widget">
                    <h4><?php esc_html_e('Popular Tags', 'tanwar-associates'); ?></h4>
                    <div class="tag-cloud">
                        <?php foreach ($tags as $tag) : ?>
                            <a href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>" class="tag-item">
                                <?php echo esc_html($tag->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Newsletter CTA -->
                <div class="sidebar-widget sidebar-cta">
                    <div class="sidebar-cta-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                            <polyline points="22,6 12,13 2,6"></polyline>
                        </svg>
                    </div>
                    <h4><?php esc_html_e('Stay Updated', 'tanwar-associates'); ?></h4>
                    <p><?php esc_html_e('Get the latest legal insights delivered to your inbox.', 'tanwar-associates'); ?></p>
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary w-full">
                        <?php esc_html_e('Subscribe', 'tanwar-associates'); ?>
                    </a>
                </div>

                <!-- Consultation CTA -->
                <div class="sidebar-widget sidebar-consultation">
                    <h4><?php esc_html_e('Need Legal Help?', 'tanwar-associates'); ?></h4>
                    <p><?php esc_html_e('Schedule a consultation with our expert advocates.', 'tanwar-associates'); ?></p>
                    <a href="tel:<?php echo esc_attr(tanwar_format_phone(tanwar_get_option('phone', '+91 98290 12345'))); ?>" class="consultation-phone">
                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        <?php echo esc_html(tanwar_get_option('phone', '+91 98290 12345')); ?>
                    </a>
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-outline w-full">
                        <?php esc_html_e('Book Consultation', 'tanwar-associates'); ?>
                    </a>
                </div>
            </aside>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/contact-cta'); ?>

<?php } // End Elementor check ?>

<?php get_footer(); ?>
