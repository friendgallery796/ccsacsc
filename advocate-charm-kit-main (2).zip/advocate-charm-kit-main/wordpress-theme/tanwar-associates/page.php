<?php
/**
 * The template for displaying all pages
 * Fully Elementor Editable
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor
$is_elementor = class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID());

if ($is_elementor) :
    // Elementor content - Display the Elementor-built page
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Default theme content - Standard WordPress page
?>

<div class="page-hero">
    <div class="container">
        <div class="page-hero-content">
            <nav class="breadcrumbs" aria-label="Breadcrumb">
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'tanwar-associates'); ?></a>
                <span>/</span>
                <span><?php the_title(); ?></span>
            </nav>
            <h1><?php the_title(); ?></h1>
        </div>
    </div>
</div>

<section class="section">
    <div class="container">
        <article id="post-<?php the_ID(); ?>" <?php post_class('page-content'); ?>>
            <?php
            while (have_posts()) :
                the_post();
                the_content();
            endwhile;
            ?>
        </article>
    </div>
</section>

<?php endif; // End Elementor check ?>

<?php get_footer(); ?>
