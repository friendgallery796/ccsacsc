<?php
/**
 * Template Name: Testimonials Page
 * 
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor
$is_elementor = class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID());

if ($is_elementor) :
    // Elementor content
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Default theme content
?>

<main id="primary" class="site-main">
    
    <!-- Testimonials Hero Section -->
    <section class="testimonials-hero">
        <div class="container">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                <span class="separator">›</span>
                <span class="current">Client Testimonials</span>
            </nav>
            <h1 class="page-title">Client Testimonials</h1>
            <p class="page-subtitle">Hear what our clients say about their experience working with us</p>
            
            <!-- Stats Row -->
            <div class="testimonials-stats">
                <div class="stat-item">
                    <span class="stat-number">500+</span>
                    <span class="stat-label">Happy Clients</span>
                </div>
                <div class="stat-divider"></div>
                <div class="stat-item">
                    <span class="stat-number">98%</span>
                    <span class="stat-label">Success Rate</span>
                </div>
                <div class="stat-divider"></div>
                <div class="stat-item">
                    <span class="stat-number">4.9</span>
                    <span class="stat-label">Average Rating</span>
                </div>
            </div>
        </div>
    </section>

    <!-- Filter Section -->
    <section class="testimonials-filter">
        <div class="container">
            <div class="filter-wrapper">
                <span class="filter-label">Filter by Practice Area:</span>
                <div class="filter-buttons">
                    <button class="filter-btn active" data-filter="all">All</button>
                    <button class="filter-btn" data-filter="corporate">Corporate</button>
                    <button class="filter-btn" data-filter="civil">Civil</button>
                    <button class="filter-btn" data-filter="criminal">Criminal</button>
                    <button class="filter-btn" data-filter="family">Family</button>
                    <button class="filter-btn" data-filter="property">Property</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Featured Testimonial -->
    <section class="featured-testimonial">
        <div class="container">
            <div class="featured-card">
                <div class="featured-quote-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                    </svg>
                </div>
                <blockquote class="featured-quote">
                    "Tanwar & Associates handled our company's complex merger with exceptional professionalism. Their attention to detail and strategic approach saved us from potential legal pitfalls. I highly recommend them for any corporate legal matters."
                </blockquote>
                <div class="featured-author">
                    <div class="author-avatar">
                        <img src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/images/testimonial-featured.jpg" alt="Rajesh Sharma" onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                        <div class="avatar-placeholder" style="display: none;">RS</div>
                    </div>
                    <div class="author-info">
                        <h4 class="author-name">Rajesh Sharma</h4>
                        <p class="author-title">CEO, TechVentures Pvt. Ltd.</p>
                        <div class="author-rating">
                            <div class="stars">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            </div>
                        </div>
                    </div>
                </div>
                <span class="featured-badge">Featured Review</span>
            </div>
        </div>
    </section>

    <!-- Testimonials Grid -->
    <section class="testimonials-grid-section">
        <div class="container">
            <div class="testimonials-grid">
                
                <!-- Testimonial Card 1 -->
                <div class="testimonial-card" data-category="criminal">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">AK</div>
                        </div>
                        <div class="card-author">
                            <h4>Amit Kumar</h4>
                            <p>Business Owner</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>5.0</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"When I faced false allegations, the criminal defense team at Tanwar & Associates stood by me. They fought tirelessly and got me acquitted. Forever grateful for their dedication."</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Criminal Defense</span>
                        <span class="card-date">2 months ago</span>
                    </div>
                </div>

                <!-- Testimonial Card 2 -->
                <div class="testimonial-card" data-category="family">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">PM</div>
                        </div>
                        <div class="card-author">
                            <h4>Priya Malhotra</h4>
                            <p>Homemaker</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>5.0</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"Going through a divorce is never easy, but the family law team handled my case with sensitivity and professionalism. They ensured fair custody arrangements for my children."</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Family Law</span>
                        <span class="card-date">3 months ago</span>
                    </div>
                </div>

                <!-- Testimonial Card 3 -->
                <div class="testimonial-card" data-category="property">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">VG</div>
                        </div>
                        <div class="card-author">
                            <h4>Vikram Gupta</h4>
                            <p>Real Estate Developer</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>4.9</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"Their property law expertise is unmatched. They helped resolve a long-standing land dispute that had been pending for years. Highly professional and result-oriented."</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Property Law</span>
                        <span class="card-date">1 month ago</span>
                    </div>
                </div>

                <!-- Testimonial Card 4 -->
                <div class="testimonial-card" data-category="corporate">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">SK</div>
                        </div>
                        <div class="card-author">
                            <h4>Sunita Kapoor</h4>
                            <p>Startup Founder</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>5.0</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"As a first-time entrepreneur, I needed guidance on company formation and compliance. The team made the entire process seamless and continues to support our legal needs."</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Corporate Law</span>
                        <span class="card-date">2 weeks ago</span>
                    </div>
                </div>

                <!-- Testimonial Card 5 -->
                <div class="testimonial-card" data-category="civil">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">RJ</div>
                        </div>
                        <div class="card-author">
                            <h4>Ramesh Joshi</h4>
                            <p>Retired Government Officer</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>4.8</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"Won a civil suit that I thought was impossible. The lawyers were thorough in their research and presented my case brilliantly. Justice was finally served."</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Civil Litigation</span>
                        <span class="card-date">4 months ago</span>
                    </div>
                </div>

                <!-- Testimonial Card 6 -->
                <div class="testimonial-card" data-category="corporate">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">NA</div>
                        </div>
                        <div class="card-author">
                            <h4>Neha Agarwal</h4>
                            <p>CFO, Manufacturing Co.</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>5.0</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"Their tax advisory services saved our company lakhs in compliance issues. They identified risks we weren't even aware of. Truly experts in corporate taxation."</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Corporate Law</span>
                        <span class="card-date">6 weeks ago</span>
                    </div>
                </div>

                <!-- Testimonial Card 7 -->
                <div class="testimonial-card" data-category="family">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">AS</div>
                        </div>
                        <div class="card-author">
                            <h4>Arjun Singh</h4>
                            <p>IT Professional</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>4.9</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"Inheritance disputes can tear families apart. The lawyers at Tanwar & Associates helped us reach an amicable settlement while preserving family relationships."</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Family Law</span>
                        <span class="card-date">5 months ago</span>
                    </div>
                </div>

                <!-- Testimonial Card 8 -->
                <div class="testimonial-card" data-category="criminal">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">DM</div>
                        </div>
                        <div class="card-author">
                            <h4>Deepak Mehta</h4>
                            <p>Restaurant Owner</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>5.0</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"Secured anticipatory bail within 24 hours when I was wrongly accused. Their quick response and legal acumen saved my reputation and business. Highly recommend!"</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Criminal Defense</span>
                        <span class="card-date">3 weeks ago</span>
                    </div>
                </div>

                <!-- Testimonial Card 9 -->
                <div class="testimonial-card" data-category="property">
                    <div class="card-header">
                        <div class="card-avatar">
                            <div class="avatar-placeholder">KR</div>
                        </div>
                        <div class="card-author">
                            <h4>Kavita Reddy</h4>
                            <p>NRI Client</p>
                        </div>
                        <div class="card-rating">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>
                            <span>4.9</span>
                        </div>
                    </div>
                    <div class="card-content">
                        <p>"Being an NRI, managing property matters in India was challenging. They handled everything from documentation to registration. Completely trustworthy and efficient."</p>
                    </div>
                    <div class="card-footer">
                        <span class="card-category">Property Law</span>
                        <span class="card-date">2 months ago</span>
                    </div>
                </div>

            </div>

            <!-- No Results -->
            <div class="no-testimonials" style="display: none;">
                <div class="no-testimonials-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M16 16s-1.5-2-4-2-4 2-4 2"/>
                        <line x1="9" y1="9" x2="9.01" y2="9"/>
                        <line x1="15" y1="9" x2="15.01" y2="9"/>
                    </svg>
                </div>
                <p>No testimonials found for this category.</p>
            </div>

        </div>
    </section>

    <!-- Video Testimonials Section -->
    <section class="video-testimonials">
        <div class="container">
            <div class="section-header">
                <span class="section-subtitle">Video Reviews</span>
                <h2 class="section-title">Watch Our Clients Share Their Experience</h2>
            </div>
            
            <div class="video-grid">
                <div class="video-card">
                    <div class="video-thumbnail">
                        <img src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=300&fit=crop" alt="Video Testimonial">
                        <div class="play-button">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                <polygon points="5 3 19 12 5 21 5 3"/>
                            </svg>
                        </div>
                    </div>
                    <div class="video-info">
                        <h4>Corporate Merger Success</h4>
                        <p>Rajesh Sharma, CEO</p>
                    </div>
                </div>
                
                <div class="video-card">
                    <div class="video-thumbnail">
                        <img src="https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=400&h=300&fit=crop" alt="Video Testimonial">
                        <div class="play-button">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                <polygon points="5 3 19 12 5 21 5 3"/>
                            </svg>
                        </div>
                    </div>
                    <div class="video-info">
                        <h4>Property Dispute Resolution</h4>
                        <p>Meera Patel, Business Owner</p>
                    </div>
                </div>
                
                <div class="video-card">
                    <div class="video-thumbnail">
                        <img src="https://images.unsplash.com/photo-1556157382-97edd2f7f3a7?w=400&h=300&fit=crop" alt="Video Testimonial">
                        <div class="play-button">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
                                <polygon points="5 3 19 12 5 21 5 3"/>
                            </svg>
                        </div>
                    </div>
                    <div class="video-info">
                        <h4>Criminal Defense Victory</h4>
                        <p>Anonymous Client</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="testimonials-cta">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Experience Excellence?</h2>
                <p>Join hundreds of satisfied clients who trust Tanwar & Associates for their legal needs.</p>
                <div class="cta-buttons">
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">
                        Schedule Consultation
                    </a>
                    <a href="tel:+919829012345" class="btn btn-outline btn-lg">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                        </svg>
                        Call: +91 98290 12345
                    </a>
                </div>
            </div>
        </div>
    </section>

</main>

<!-- Testimonials JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Filter functionality
    const filterButtons = document.querySelectorAll('.filter-btn');
    const testimonialCards = document.querySelectorAll('.testimonial-card');
    const noResults = document.querySelector('.no-testimonials');
    
    filterButtons.forEach(button => {
        button.addEventListener('click', function() {
            const filter = this.dataset.filter;
            
            // Update active button
            filterButtons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');
            
            // Filter cards
            let visibleCount = 0;
            testimonialCards.forEach(card => {
                if (filter === 'all' || card.dataset.category === filter) {
                    card.style.display = 'block';
                    visibleCount++;
                } else {
                    card.style.display = 'none';
                }
            });
            
            // Show/hide no results message
            if (noResults) {
                noResults.style.display = visibleCount === 0 ? 'block' : 'none';
            }
        });
    });
});
</script>

<?php endif; // End Elementor check ?>

<?php get_footer(); ?>
