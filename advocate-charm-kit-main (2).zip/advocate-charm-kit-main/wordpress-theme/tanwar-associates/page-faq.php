<?php
/**
 * Template Name: FAQ Page
 * 
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor
$is_elementor = class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID());

if ($is_elementor) :
    // Elementor content
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Default theme content
?>

<main id="primary" class="site-main">
    
    <!-- FAQ Hero Section -->
    <section class="faq-hero">
        <div class="container">
            <nav class="breadcrumb" aria-label="Breadcrumb">
                <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                <span class="separator">›</span>
                <span class="current">Frequently Asked Questions</span>
            </nav>
            <h1 class="page-title">Frequently Asked Questions</h1>
            <p class="page-subtitle">Find answers to common legal questions across our practice areas</p>
            
            <!-- Search FAQs -->
            <div class="faq-search-wrapper">
                <div class="faq-search">
                    <svg class="search-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="11" cy="11" r="8"/>
                        <path d="m21 21-4.35-4.35"/>
                    </svg>
                    <input type="text" id="faq-search-input" placeholder="Search for questions..." />
                </div>
            </div>
        </div>
    </section>

    <!-- FAQ Categories Navigation -->
    <section class="faq-categories-nav">
        <div class="container">
            <div class="category-tabs">
                <button class="category-tab active" data-category="all">All Questions</button>
                <button class="category-tab" data-category="corporate">Corporate Law</button>
                <button class="category-tab" data-category="civil">Civil Litigation</button>
                <button class="category-tab" data-category="criminal">Criminal Defense</button>
                <button class="category-tab" data-category="family">Family Law</button>
                <button class="category-tab" data-category="property">Property Law</button>
                <button class="category-tab" data-category="tax">Tax Law</button>
            </div>
        </div>
    </section>

    <!-- FAQ Content -->
    <section class="faq-content">
        <div class="container">
            <div class="faq-layout">
                
                <!-- Main FAQ Accordions -->
                <div class="faq-main">
                    
                    <!-- Corporate Law FAQs -->
                    <div class="faq-category" data-category="corporate">
                        <div class="category-header">
                            <div class="category-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="2" y="7" width="20" height="14" rx="2" ry="2"/>
                                    <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>
                                </svg>
                            </div>
                            <h2 class="category-title">Corporate Law</h2>
                        </div>
                        
                        <div class="accordion-group">
                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What are the steps to register a company in India?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>Company registration in India involves several key steps:</p>
                                        <ol>
                                            <li><strong>Obtain Digital Signature Certificate (DSC)</strong> - Required for all proposed directors</li>
                                            <li><strong>Apply for Director Identification Number (DIN)</strong> - Mandatory for directors</li>
                                            <li><strong>Name Reservation</strong> - Apply through RUN (Reserve Unique Name) service on MCA portal</li>
                                            <li><strong>File SPICe+ Form</strong> - Includes incorporation application, PAN, TAN, and GST registration</li>
                                            <li><strong>Draft MOA and AOA</strong> - Memorandum and Articles of Association</li>
                                            <li><strong>Certificate of Incorporation</strong> - Issued by Registrar of Companies</li>
                                        </ol>
                                        <p>The entire process typically takes 10-15 working days. Our team can handle the complete registration process for you.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What is the difference between Private Limited and LLP?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p><strong>Private Limited Company:</strong></p>
                                        <ul>
                                            <li>Governed by Companies Act, 2013</li>
                                            <li>Separate legal entity with perpetual succession</li>
                                            <li>Higher compliance requirements</li>
                                            <li>Can raise equity funding from investors</li>
                                            <li>Suitable for businesses planning rapid growth</li>
                                        </ul>
                                        <p><strong>Limited Liability Partnership (LLP):</strong></p>
                                        <ul>
                                            <li>Governed by LLP Act, 2008</li>
                                            <li>Combines benefits of partnership and limited liability</li>
                                            <li>Lower compliance burden</li>
                                            <li>Cannot raise equity funding easily</li>
                                            <li>Suitable for professional services and small businesses</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What are the annual compliance requirements for a Private Limited Company?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>Private Limited Companies must fulfill the following annual compliances:</p>
                                        <ul>
                                            <li><strong>Annual General Meeting (AGM)</strong> - Within 6 months from end of financial year</li>
                                            <li><strong>Board Meetings</strong> - Minimum 4 meetings per year</li>
                                            <li><strong>Annual Return (Form MGT-7)</strong> - Within 60 days of AGM</li>
                                            <li><strong>Financial Statements (Form AOC-4)</strong> - Within 30 days of AGM</li>
                                            <li><strong>Income Tax Return</strong> - By September 30th</li>
                                            <li><strong>GST Returns</strong> - Monthly/Quarterly as applicable</li>
                                            <li><strong>Statutory Audit</strong> - Mandatory for all companies</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Civil Litigation FAQs -->
                    <div class="faq-category" data-category="civil">
                        <div class="category-header">
                            <div class="category-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                                </svg>
                            </div>
                            <h2 class="category-title">Civil Litigation</h2>
                        </div>
                        
                        <div class="accordion-group">
                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What is the limitation period for filing a civil suit?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>The Limitation Act, 1963 prescribes different periods for different types of civil suits:</p>
                                        <ul>
                                            <li><strong>Contract disputes</strong> - 3 years from breach</li>
                                            <li><strong>Recovery of money</strong> - 3 years from when debt becomes due</li>
                                            <li><strong>Immovable property possession</strong> - 12 years</li>
                                            <li><strong>Specific performance</strong> - 3 years from date fixed for performance</li>
                                            <li><strong>Tort/Negligence</strong> - 1 year from when damage occurs</li>
                                            <li><strong>Defamation</strong> - 1 year from publication</li>
                                        </ul>
                                        <p>It's crucial to file within the limitation period, as courts generally cannot entertain time-barred suits.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">How long does a civil case typically take in Indian courts?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>The duration of civil cases varies based on complexity and court workload:</p>
                                        <ul>
                                            <li><strong>District Courts</strong> - 2-5 years on average</li>
                                            <li><strong>High Courts (Original)</strong> - 1-3 years</li>
                                            <li><strong>Commercial Courts</strong> - 1-2 years (expedited process)</li>
                                            <li><strong>Appeals</strong> - Additional 1-3 years per level</li>
                                        </ul>
                                        <p>We recommend exploring alternative dispute resolution methods like mediation and arbitration for faster resolution.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What is the difference between mediation and arbitration?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p><strong>Mediation:</strong></p>
                                        <ul>
                                            <li>Neutral mediator facilitates discussion</li>
                                            <li>Non-binding unless parties agree</li>
                                            <li>Parties retain control over outcome</li>
                                            <li>Confidential and less adversarial</li>
                                            <li>Cost-effective and faster</li>
                                        </ul>
                                        <p><strong>Arbitration:</strong></p>
                                        <ul>
                                            <li>Arbitrator acts as private judge</li>
                                            <li>Binding decision (arbitral award)</li>
                                            <li>More formal procedure</li>
                                            <li>Limited grounds for appeal</li>
                                            <li>Enforceable like court decree</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Criminal Defense FAQs -->
                    <div class="faq-category" data-category="criminal">
                        <div class="category-header">
                            <div class="category-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"/>
                                    <line x1="12" y1="8" x2="12" y2="12"/>
                                    <line x1="12" y1="16" x2="12.01" y2="16"/>
                                </svg>
                            </div>
                            <h2 class="category-title">Criminal Defense</h2>
                        </div>
                        
                        <div class="accordion-group">
                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What are my rights if I am arrested?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>Under Indian law, every arrested person has the following fundamental rights:</p>
                                        <ul>
                                            <li><strong>Right to know grounds of arrest</strong> - Police must inform reason for arrest</li>
                                            <li><strong>Right to legal counsel</strong> - You can consult a lawyer of your choice</li>
                                            <li><strong>Right to be produced before magistrate within 24 hours</strong></li>
                                            <li><strong>Right against self-incrimination</strong> - You cannot be compelled to confess</li>
                                            <li><strong>Right to inform family/friend</strong> - Police must inform a relative</li>
                                            <li><strong>Right to medical examination</strong> - If required</li>
                                            <li><strong>Right to bail</strong> - In bailable offenses, bail is a right</li>
                                        </ul>
                                        <p>Contact us immediately if you or a family member is arrested. We provide 24/7 emergency legal assistance.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What is the difference between bail and anticipatory bail?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p><strong>Regular Bail:</strong></p>
                                        <ul>
                                            <li>Applied after arrest</li>
                                            <li>Filed in court where case is pending</li>
                                            <li>Person is in custody during application</li>
                                        </ul>
                                        <p><strong>Anticipatory Bail (Section 438 CrPC):</strong></p>
                                        <ul>
                                            <li>Applied before arrest in apprehension of arrest</li>
                                            <li>Filed in Sessions Court or High Court</li>
                                            <li>Person is not in custody</li>
                                            <li>Protects against arrest if granted</li>
                                        </ul>
                                        <p>If you anticipate arrest, it's crucial to file for anticipatory bail immediately.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Family Law FAQs -->
                    <div class="faq-category" data-category="family">
                        <div class="category-header">
                            <div class="category-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                                    <circle cx="9" cy="7" r="4"/>
                                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                                </svg>
                            </div>
                            <h2 class="category-title">Family Law</h2>
                        </div>
                        
                        <div class="accordion-group">
                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What are the grounds for divorce in India?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>Under the Hindu Marriage Act, 1955, grounds for divorce include:</p>
                                        <ul>
                                            <li><strong>Adultery</strong> - Extra-marital relationship</li>
                                            <li><strong>Cruelty</strong> - Physical or mental cruelty</li>
                                            <li><strong>Desertion</strong> - For continuous 2 years</li>
                                            <li><strong>Conversion</strong> - Change of religion</li>
                                            <li><strong>Mental disorder</strong> - Incurable mental illness</li>
                                            <li><strong>Leprosy</strong> - Virulent and incurable form</li>
                                            <li><strong>Venereal disease</strong> - Communicable STDs</li>
                                            <li><strong>Renunciation</strong> - Entering religious order</li>
                                            <li><strong>Presumed dead</strong> - Not heard of for 7 years</li>
                                        </ul>
                                        <p><strong>Mutual Consent Divorce:</strong> Both parties can file for divorce by mutual consent after 1 year of marriage.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">How is child custody determined?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>Courts determine custody based on the "welfare of the child" principle:</p>
                                        <ul>
                                            <li><strong>Age of child</strong> - Children below 5 years generally stay with mother</li>
                                            <li><strong>Child's preference</strong> - Views of older children are considered</li>
                                            <li><strong>Financial stability</strong> - Ability to provide for child's needs</li>
                                            <li><strong>Moral character</strong> - Parent's conduct and lifestyle</li>
                                            <li><strong>Educational continuity</strong> - Minimum disruption to schooling</li>
                                            <li><strong>Emotional bond</strong> - Attachment with each parent</li>
                                        </ul>
                                        <p>Courts can grant <strong>sole custody</strong>, <strong>joint custody</strong>, or <strong>visitation rights</strong> depending on circumstances.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Property Law FAQs -->
                    <div class="faq-category" data-category="property">
                        <div class="category-header">
                            <div class="category-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                                    <polyline points="9 22 9 12 15 12 15 22"/>
                                </svg>
                            </div>
                            <h2 class="category-title">Property Law</h2>
                        </div>
                        
                        <div class="accordion-group">
                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What documents should I verify before buying property?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>Essential documents to verify:</p>
                                        <ul>
                                            <li><strong>Title Deed</strong> - Original sale deed or conveyance deed</li>
                                            <li><strong>Chain of ownership</strong> - History of transfers for 30+ years</li>
                                            <li><strong>Encumbrance Certificate</strong> - No pending loans or charges</li>
                                            <li><strong>Property Tax Receipts</strong> - Up-to-date tax payments</li>
                                            <li><strong>Building Plan Approval</strong> - Sanctioned plan from authorities</li>
                                            <li><strong>Completion Certificate</strong> - For constructed buildings</li>
                                            <li><strong>Occupancy Certificate</strong> - Permission to occupy</li>
                                            <li><strong>RERA Registration</strong> - For under-construction properties</li>
                                            <li><strong>Society NOC</strong> - For apartments</li>
                                        </ul>
                                        <p>We provide comprehensive title verification services to protect your investment.</p>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What is RERA and how does it protect buyers?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>Real Estate (Regulation and Development) Act, 2016 (RERA) protects buyers by:</p>
                                        <ul>
                                            <li><strong>Mandatory Registration</strong> - All projects must be registered</li>
                                            <li><strong>Timely Delivery</strong> - Builders must complete on promised date</li>
                                            <li><strong>70% Funds in Escrow</strong> - Cannot be diverted to other projects</li>
                                            <li><strong>No Misleading Ads</strong> - What you see is what you get</li>
                                            <li><strong>5-Year Defect Liability</strong> - Builder must fix structural defects</li>
                                            <li><strong>Carpet Area Clarity</strong> - Payment based on carpet area only</li>
                                            <li><strong>Fast-track Resolution</strong> - RERA tribunal for disputes</li>
                                        </ul>
                                        <p>Always verify RERA registration before buying from a builder.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Tax Law FAQs -->
                    <div class="faq-category" data-category="tax">
                        <div class="category-header">
                            <div class="category-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="12" y1="1" x2="12" y2="23"/>
                                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                                </svg>
                            </div>
                            <h2 class="category-title">Tax Law</h2>
                        </div>
                        
                        <div class="accordion-group">
                            <div class="accordion-item">
                                <button class="accordion-trigger" aria-expanded="false">
                                    <span class="question-text">What should I do if I receive an Income Tax Notice?</span>
                                    <span class="accordion-icon">
                                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <polyline points="6 9 12 15 18 9"/>
                                        </svg>
                                    </span>
                                </button>
                                <div class="accordion-content">
                                    <div class="answer-text">
                                        <p>Steps to take when you receive a tax notice:</p>
                                        <ol>
                                            <li><strong>Don't panic</strong> - Many notices are routine queries</li>
                                            <li><strong>Read carefully</strong> - Understand what is being asked</li>
                                            <li><strong>Check details</strong> - Verify PAN, assessment year, section cited</li>
                                            <li><strong>Note deadline</strong> - Respond within the stipulated time</li>
                                            <li><strong>Gather documents</strong> - Collect relevant proofs</li>
                                            <li><strong>Consult a professional</strong> - Get legal/tax advice</li>
                                            <li><strong>Respond appropriately</strong> - File reply on e-filing portal</li>
                                        </ol>
                                        <p>Common notices include: intimation (143(1)), scrutiny (143(2)), and demand (156).</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

                <!-- Sidebar -->
                <aside class="faq-sidebar">
                    <div class="sidebar-card">
                        <h3>Still Have Questions?</h3>
                        <p>Can't find the answer you're looking for? Our legal experts are here to help.</p>
                        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary">
                            Contact Us
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"/>
                                <polyline points="12 5 19 12 12 19"/>
                            </svg>
                        </a>
                    </div>

                    <div class="sidebar-card">
                        <h3>Free Consultation</h3>
                        <p>Schedule a free 30-minute consultation to discuss your legal matter.</p>
                        <a href="tel:+919829012345" class="btn btn-outline">
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                            </svg>
                            Call Now
                        </a>
                    </div>

                    <div class="sidebar-card quick-links">
                        <h3>Quick Links</h3>
                        <ul>
                            <li><a href="<?php echo esc_url(home_url('/practice-areas/')); ?>">Practice Areas</a></li>
                            <li><a href="<?php echo esc_url(home_url('/team/')); ?>">Our Team</a></li>
                            <li><a href="<?php echo esc_url(home_url('/testimonials/')); ?>">Testimonials</a></li>
                            <li><a href="<?php echo esc_url(home_url('/about/')); ?>">About Us</a></li>
                        </ul>
                    </div>
                </aside>

            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="faq-cta">
        <div class="container">
            <div class="cta-content">
                <h2>Ready to Get Legal Help?</h2>
                <p>Our experienced team is ready to assist you with your legal matters.</p>
                <div class="cta-buttons">
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">
                        Schedule Consultation
                    </a>
                    <a href="tel:+919829012345" class="btn btn-outline btn-lg">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                        </svg>
                        Call: +91 98290 12345
                    </a>
                </div>
            </div>
        </div>
    </section>

</main>

<!-- FAQ JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Accordion functionality
    const accordionTriggers = document.querySelectorAll('.accordion-trigger');
    
    accordionTriggers.forEach(trigger => {
        trigger.addEventListener('click', function() {
            const isExpanded = this.getAttribute('aria-expanded') === 'true';
            const content = this.nextElementSibling;
            
            // Close all other accordions in the same group
            const group = this.closest('.accordion-group');
            if (group) {
                group.querySelectorAll('.accordion-trigger').forEach(otherTrigger => {
                    if (otherTrigger !== this) {
                        otherTrigger.setAttribute('aria-expanded', 'false');
                        otherTrigger.nextElementSibling.style.maxHeight = null;
                    }
                });
            }
            
            // Toggle current accordion
            this.setAttribute('aria-expanded', !isExpanded);
            if (!isExpanded) {
                content.style.maxHeight = content.scrollHeight + 'px';
            } else {
                content.style.maxHeight = null;
            }
        });
    });

    // Category filtering
    const categoryTabs = document.querySelectorAll('.category-tab');
    const faqCategories = document.querySelectorAll('.faq-category');
    
    categoryTabs.forEach(tab => {
        tab.addEventListener('click', function() {
            const category = this.dataset.category;
            
            // Update active tab
            categoryTabs.forEach(t => t.classList.remove('active'));
            this.classList.add('active');
            
            // Filter categories
            faqCategories.forEach(faqCat => {
                if (category === 'all' || faqCat.dataset.category === category) {
                    faqCat.style.display = 'block';
                } else {
                    faqCat.style.display = 'none';
                }
            });
        });
    });

    // Search functionality
    const searchInput = document.getElementById('faq-search-input');
    if (searchInput) {
        searchInput.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            
            document.querySelectorAll('.accordion-item').forEach(item => {
                const questionText = item.querySelector('.question-text').textContent.toLowerCase();
                const answerText = item.querySelector('.answer-text').textContent.toLowerCase();
                
                if (questionText.includes(searchTerm) || answerText.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = searchTerm ? 'none' : 'block';
                }
            });

            // Show/hide category headers based on visible items
            faqCategories.forEach(category => {
                const visibleItems = category.querySelectorAll('.accordion-item[style="display: block"], .accordion-item:not([style*="display"])');
                const hasVisibleItems = Array.from(visibleItems).some(item => item.style.display !== 'none');
                category.style.display = hasVisibleItems || !searchTerm ? 'block' : 'none';
            });
        });
    }
});
</script>

<?php endif; // End Elementor check ?>

<?php get_footer(); ?>
