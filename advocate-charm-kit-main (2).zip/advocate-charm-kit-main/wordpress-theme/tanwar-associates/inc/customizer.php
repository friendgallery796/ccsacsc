<?php
/**
 * Theme Customizer Settings
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) exit;

function tanwar_customize_register($wp_customize) {
    // Firm Info Section
    $wp_customize->add_section('tanwar_firm_info', array(
        'title' => 'Firm Information',
        'priority' => 30,
    ));

    $wp_customize->add_setting('firm_name', array('default' => 'Tanwar & Associates', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('firm_name', array('label' => 'Firm Name', 'section' => 'tanwar_firm_info', 'type' => 'text'));

    $wp_customize->add_setting('phone', array('default' => '+91 98290 12345', 'sanitize_callback' => 'sanitize_text_field'));
    $wp_customize->add_control('phone', array('label' => 'Phone Number', 'section' => 'tanwar_firm_info', 'type' => 'text'));

    $wp_customize->add_setting('email', array('default' => 'info@tanwarassociates.com', 'sanitize_callback' => 'sanitize_email'));
    $wp_customize->add_control('email', array('label' => 'Email', 'section' => 'tanwar_firm_info', 'type' => 'email'));

    $wp_customize->add_setting('address', array('default' => "Chamber No. 123, High Court Premises\nJaipur, Rajasthan 302001", 'sanitize_callback' => 'sanitize_textarea_field'));
    $wp_customize->add_control('address', array('label' => 'Address', 'section' => 'tanwar_firm_info', 'type' => 'textarea'));

    // Social Media Section
    $wp_customize->add_section('tanwar_social', array('title' => 'Social Media', 'priority' => 35));
    
    foreach (array('facebook', 'twitter', 'linkedin', 'instagram') as $social) {
        $wp_customize->add_setting("social_{$social}", array('default' => '', 'sanitize_callback' => 'esc_url_raw'));
        $wp_customize->add_control("social_{$social}", array('label' => ucfirst($social) . ' URL', 'section' => 'tanwar_social', 'type' => 'url'));
    }
}
add_action('customize_register', 'tanwar_customize_register');
