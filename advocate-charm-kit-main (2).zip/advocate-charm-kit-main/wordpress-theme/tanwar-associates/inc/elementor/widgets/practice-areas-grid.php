<?php
/**
 * Elementor Practice Areas Grid Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Practice_Areas_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_practice_areas_grid';
    }

    public function get_title() {
        return esc_html__('Practice Areas Grid', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-gallery-grid';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['practice', 'areas', 'services', 'grid', 'tanwar'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_subtitle',
            [
                'label' => esc_html__('Section Subtitle', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('What We Do', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => esc_html__('Section Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Our Practice Areas', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'section_description',
            [
                'label' => esc_html__('Section Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Comprehensive legal services across all major practice areas.', 'tanwar-associates'),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Practice Area', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'description',
            [
                'label' => esc_html__('Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Description of the practice area.', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-balance-scale',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $repeater->add_control(
            'link',
            [
                'label' => esc_html__('Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $repeater->add_control(
            'services',
            [
                'label' => esc_html__('Services (one per line)', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => "Service 1\nService 2\nService 3",
            ]
        );

        $this->add_control(
            'practice_areas',
            [
                'label' => esc_html__('Practice Areas', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'title' => esc_html__('Civil Litigation', 'tanwar-associates'),
                        'description' => esc_html__('Comprehensive civil litigation services including property disputes, contract enforcement, and recovery suits.', 'tanwar-associates'),
                        'services' => "Property Disputes\nContract Enforcement\nRecovery Suits\nInjunctions",
                    ],
                    [
                        'title' => esc_html__('Criminal Law', 'tanwar-associates'),
                        'description' => esc_html__('Expert criminal defense including bail applications, trial representation, and appeals.', 'tanwar-associates'),
                        'services' => "Bail Applications\nCriminal Trials\nAppeals\nAnticipatory Bail",
                    ],
                    [
                        'title' => esc_html__('Corporate Law', 'tanwar-associates'),
                        'description' => esc_html__('Full-service corporate legal solutions including company incorporation and M&A advisory.', 'tanwar-associates'),
                        'services' => "Company Formation\nContract Drafting\nM&A Advisory\nNCLT Matters",
                    ],
                    [
                        'title' => esc_html__('Family Law', 'tanwar-associates'),
                        'description' => esc_html__('Sensitive handling of family matters including divorce, child custody, and maintenance.', 'tanwar-associates'),
                        'services' => "Divorce Proceedings\nChild Custody\nMaintenance Claims\nDomestic Violence",
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->add_control(
            'columns',
            [
                'label' => esc_html__('Columns', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '2',
                'options' => [
                    '1' => esc_html__('1 Column', 'tanwar-associates'),
                    '2' => esc_html__('2 Columns', 'tanwar-associates'),
                    '3' => esc_html__('3 Columns', 'tanwar-associates'),
                    '4' => esc_html__('4 Columns', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'card_style',
            [
                'label' => esc_html__('Card Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'detailed',
                'options' => [
                    'simple' => esc_html__('Simple', 'tanwar-associates'),
                    'detailed' => esc_html__('Detailed with Services', 'tanwar-associates'),
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => esc_html__('Card Background', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => esc_html__('Accent Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#c9a44a',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="tanwar-practice-areas-section">
            <div class="container">
                <?php if (!empty($settings['section_subtitle']) || !empty($settings['section_title'])) : ?>
                <div class="section-header">
                    <?php if (!empty($settings['section_subtitle'])) : ?>
                        <span class="section-subtitle"><?php echo esc_html($settings['section_subtitle']); ?></span>
                    <?php endif; ?>
                    <?php if (!empty($settings['section_title'])) : ?>
                        <h2 class="section-title"><?php echo esc_html($settings['section_title']); ?></h2>
                    <?php endif; ?>
                    <?php if (!empty($settings['section_description'])) : ?>
                        <p class="section-description"><?php echo esc_html($settings['section_description']); ?></p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <div class="tanwar-practice-areas-grid columns-<?php echo esc_attr($settings['columns']); ?>" style="--card-bg: <?php echo esc_attr($settings['card_background']); ?>; --accent: <?php echo esc_attr($settings['accent_color']); ?>;">
                    <?php foreach ($settings['practice_areas'] as $area) : 
                        $services = !empty($area['services']) ? array_filter(explode("\n", $area['services'])) : [];
                    ?>
                    <div class="tanwar-practice-area-card <?php echo esc_attr($settings['card_style']); ?>">
                        <div class="practice-area-icon">
                            <?php \Elementor\Icons_Manager::render_icon($area['icon'], ['aria-hidden' => 'true']); ?>
                        </div>
                        <h3 class="practice-area-title"><?php echo esc_html($area['title']); ?></h3>
                        <p class="practice-area-description"><?php echo esc_html($area['description']); ?></p>
                        
                        <?php if ($settings['card_style'] === 'detailed' && !empty($services)) : ?>
                        <ul class="practice-area-services">
                            <?php foreach ($services as $service) : ?>
                                <li>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <polyline points="20 6 9 17 4 12"></polyline>
                                    </svg>
                                    <?php echo esc_html(trim($service)); ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php endif; ?>
                        
                        <?php if (!empty($area['link']['url'])) : ?>
                        <a href="<?php echo esc_url($area['link']['url']); ?>" class="practice-area-link">
                            <?php esc_html_e('Learn More', 'tanwar-associates'); ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </a>
                        <?php endif; ?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}