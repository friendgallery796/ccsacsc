<?php
/**
 * Elementor CTA Section Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_CTA_Section_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_cta_section';
    }

    public function get_title() {
        return esc_html__('CTA Section', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-call-to-action';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['cta', 'call to action', 'button', 'banner', 'tanwar'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Need Expert Legal Assistance?', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => esc_html__('Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Contact us today for a free consultation. Our experienced advocates are ready to help you with your legal matters.', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'primary_button_text',
            [
                'label' => esc_html__('Primary Button Text', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Free Consultation', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'primary_button_link',
            [
                'label' => esc_html__('Primary Button Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '/contact/',
                ],
            ]
        );

        $this->add_control(
            'secondary_button_text',
            [
                'label' => esc_html__('Secondary Button Text', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Call Now', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'secondary_button_link',
            [
                'label' => esc_html__('Secondary Button Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => 'tel:+919829012345',
                ],
            ]
        );

        $this->add_control(
            'phone_number',
            [
                'label' => esc_html__('Phone Number', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '+91 98290 12345',
            ]
        );

        $this->add_control(
            'show_phone',
            [
                'label' => esc_html__('Show Phone Number', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'tanwar-associates'),
                'label_off' => esc_html__('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'layout_style',
            [
                'label' => esc_html__('Layout Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'gradient',
                'options' => [
                    'gradient' => esc_html__('Gradient', 'tanwar-associates'),
                    'solid' => esc_html__('Solid Color', 'tanwar-associates'),
                    'image' => esc_html__('Background Image', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'background_image',
            [
                'label' => esc_html__('Background Image', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'condition' => [
                    'layout_style' => 'image',
                ],
            ]
        );

        $this->add_control(
            'primary_color',
            [
                'label' => esc_html__('Primary Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0a1a2f',
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => esc_html__('Accent Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#c9a44a',
            ]
        );

        $this->add_control(
            'text_alignment',
            [
                'label' => esc_html__('Text Alignment', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__('Left', 'tanwar-associates'),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__('Center', 'tanwar-associates'),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__('Right', 'tanwar-associates'),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $bg_style = '';
        
        if ($settings['layout_style'] === 'image' && !empty($settings['background_image']['url'])) {
            $bg_style = 'background-image: url(' . esc_url($settings['background_image']['url']) . ');';
        }
        ?>
        <section class="tanwar-cta-section <?php echo esc_attr($settings['layout_style']); ?>" 
                 style="--primary: <?php echo esc_attr($settings['primary_color']); ?>; --accent: <?php echo esc_attr($settings['accent_color']); ?>; text-align: <?php echo esc_attr($settings['text_alignment']); ?>; <?php echo esc_attr($bg_style); ?>">
            <?php if ($settings['layout_style'] === 'image') : ?>
            <div class="cta-overlay"></div>
            <?php endif; ?>
            
            <div class="container">
                <div class="cta-content">
                    <?php if (!empty($settings['title'])) : ?>
                        <h2 class="cta-title"><?php echo esc_html($settings['title']); ?></h2>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['description'])) : ?>
                        <p class="cta-description"><?php echo esc_html($settings['description']); ?></p>
                    <?php endif; ?>
                    
                    <?php if ($settings['show_phone'] === 'yes' && !empty($settings['phone_number'])) : ?>
                    <div class="cta-phone">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/', '', $settings['phone_number'])); ?>">
                            <?php echo esc_html($settings['phone_number']); ?>
                        </a>
                    </div>
                    <?php endif; ?>
                    
                    <div class="cta-buttons">
                        <?php if (!empty($settings['primary_button_text'])) : ?>
                        <a href="<?php echo esc_url($settings['primary_button_link']['url']); ?>" class="btn btn-accent btn-lg">
                            <?php echo esc_html($settings['primary_button_text']); ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($settings['secondary_button_text'])) : ?>
                        <a href="<?php echo esc_url($settings['secondary_button_link']['url']); ?>" class="btn btn-outline-light btn-lg">
                            <?php echo esc_html($settings['secondary_button_text']); ?>
                        </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }
}