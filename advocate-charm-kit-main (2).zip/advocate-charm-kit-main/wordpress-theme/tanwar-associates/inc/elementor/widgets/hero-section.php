<?php
/**
 * Elementor Hero Section Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Hero_Section_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_hero_section';
    }

    public function get_title() {
        return esc_html__('Hero Section', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-banner';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['hero', 'banner', 'header', 'tanwar'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__('Subtitle', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Advocates & Legal Consultants', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Trusted Legal Excellence at Rajasthan High Court', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => esc_html__('Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('With over 25 years of experience, we provide comprehensive legal services across civil, criminal, corporate, and family law matters.', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'primary_button_text',
            [
                'label' => esc_html__('Primary Button Text', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Free Consultation', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'primary_button_link',
            [
                'label' => esc_html__('Primary Button Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '/contact/',
                ],
            ]
        );

        $this->add_control(
            'secondary_button_text',
            [
                'label' => esc_html__('Secondary Button Text', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Our Services', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'secondary_button_link',
            [
                'label' => esc_html__('Secondary Button Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '/practice-areas/',
                ],
            ]
        );

        $this->add_control(
            'background_image',
            [
                'label' => esc_html__('Background Image', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=1920&h=1080&fit=crop',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'overlay_color',
            [
                'label' => esc_html__('Overlay Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => 'rgba(10, 26, 47, 0.85)',
            ]
        );

        $this->add_control(
            'min_height',
            [
                'label' => esc_html__('Minimum Height', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'vh'],
                'range' => [
                    'px' => [
                        'min' => 300,
                        'max' => 1000,
                    ],
                    'vh' => [
                        'min' => 30,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'unit' => 'vh',
                    'size' => 90,
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $bg_image = !empty($settings['background_image']['url']) ? $settings['background_image']['url'] : '';
        ?>
        <section class="tanwar-hero" style="min-height: <?php echo esc_attr($settings['min_height']['size'] . $settings['min_height']['unit']); ?>; background-image: url('<?php echo esc_url($bg_image); ?>');">
            <div class="tanwar-hero-overlay" style="background: <?php echo esc_attr($settings['overlay_color']); ?>;"></div>
            <div class="tanwar-hero-content">
                <div class="container">
                    <?php if (!empty($settings['subtitle'])) : ?>
                        <span class="tanwar-hero-subtitle"><?php echo esc_html($settings['subtitle']); ?></span>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['title'])) : ?>
                        <h1 class="tanwar-hero-title"><?php echo esc_html($settings['title']); ?></h1>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['description'])) : ?>
                        <p class="tanwar-hero-description"><?php echo esc_html($settings['description']); ?></p>
                    <?php endif; ?>
                    
                    <div class="tanwar-hero-buttons">
                        <?php if (!empty($settings['primary_button_text'])) : ?>
                            <a href="<?php echo esc_url($settings['primary_button_link']['url']); ?>" class="btn btn-primary btn-lg">
                                <?php echo esc_html($settings['primary_button_text']); ?>
                            </a>
                        <?php endif; ?>
                        
                        <?php if (!empty($settings['secondary_button_text'])) : ?>
                            <a href="<?php echo esc_url($settings['secondary_button_link']['url']); ?>" class="btn btn-outline btn-lg">
                                <?php echo esc_html($settings['secondary_button_text']); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <?php
    }
}