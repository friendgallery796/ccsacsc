<?php
/**
 * Pricing Table Widget for Elementor
 *
 * @package Tanwar_Associates
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Tanwar_Pricing_Table_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_pricing_table';
    }

    public function get_title() {
        return esc_html__( 'Pricing Table', 'tanwar-associates' );
    }

    public function get_icon() {
        return 'eicon-price-table';
    }

    public function get_categories() {
        return [ 'tanwar-elements' ];
    }

    public function get_keywords() {
        return [ 'pricing', 'table', 'plans', 'packages', 'tiers', 'fees' ];
    }

    public function get_style_depends() {
        return [ 'tanwar-elementor-widgets' ];
    }

    public function get_script_depends() {
        return [ 'tanwar-elementor-widgets' ];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_header',
            [
                'label' => esc_html__( 'Section Header', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => esc_html__( 'Section Title', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Our Pricing Plans', 'tanwar-associates' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'section_subtitle',
            [
                'label' => esc_html__( 'Section Subtitle', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Transparent pricing for quality legal services', 'tanwar-associates' ),
                'rows' => 2,
            ]
        );

        $this->end_controls_section();

        // Pricing Plans Section
        $this->start_controls_section(
            'section_pricing_plans',
            [
                'label' => esc_html__( 'Pricing Plans', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'plan_name',
            [
                'label' => esc_html__( 'Plan Name', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Basic Plan', 'tanwar-associates' ),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'plan_description',
            [
                'label' => esc_html__( 'Plan Description', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__( 'Perfect for individual legal needs', 'tanwar-associates' ),
                'rows' => 2,
            ]
        );

        $repeater->add_control(
            'plan_icon',
            [
                'label' => esc_html__( 'Plan Icon', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-gavel',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $repeater->add_control(
            'currency_symbol',
            [
                'label' => esc_html__( 'Currency Symbol', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '₹',
            ]
        );

        $repeater->add_control(
            'price',
            [
                'label' => esc_html__( 'Price', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '5,000',
            ]
        );

        $repeater->add_control(
            'price_period',
            [
                'label' => esc_html__( 'Price Period', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( '/consultation', 'tanwar-associates' ),
            ]
        );

        $repeater->add_control(
            'is_featured',
            [
                'label' => esc_html__( 'Featured/Recommended', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tanwar-associates' ),
                'label_off' => esc_html__( 'No', 'tanwar-associates' ),
                'return_value' => 'yes',
                'default' => '',
            ]
        );

        $repeater->add_control(
            'featured_label',
            [
                'label' => esc_html__( 'Featured Label', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Most Popular', 'tanwar-associates' ),
                'condition' => [
                    'is_featured' => 'yes',
                ],
            ]
        );

        $repeater->add_control(
            'features_list',
            [
                'label' => esc_html__( 'Features (one per line)', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => "Initial Consultation\nDocument Review\nLegal Advice\nEmail Support",
                'rows' => 6,
                'description' => esc_html__( 'Enter each feature on a new line. Prefix with - to mark as unavailable.', 'tanwar-associates' ),
            ]
        );

        $repeater->add_control(
            'button_text',
            [
                'label' => esc_html__( 'Button Text', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__( 'Get Started', 'tanwar-associates' ),
            ]
        );

        $repeater->add_control(
            'button_link',
            [
                'label' => esc_html__( 'Button Link', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => esc_html__( 'https://your-link.com', 'tanwar-associates' ),
                'default' => [
                    'url' => '#contact',
                ],
            ]
        );

        $this->add_control(
            'pricing_plans',
            [
                'label' => esc_html__( 'Pricing Plans', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'plan_name' => esc_html__( 'Consultation', 'tanwar-associates' ),
                        'plan_description' => esc_html__( 'One-time legal consultation', 'tanwar-associates' ),
                        'price' => '2,500',
                        'price_period' => '/session',
                        'features_list' => "60-minute consultation\nLegal advice\nDocument review\nFollow-up email\n-Ongoing support\n-Court representation",
                        'plan_icon' => ['value' => 'fas fa-comments', 'library' => 'fa-solid'],
                    ],
                    [
                        'plan_name' => esc_html__( 'Standard', 'tanwar-associates' ),
                        'plan_description' => esc_html__( 'Complete legal support', 'tanwar-associates' ),
                        'price' => '15,000',
                        'price_period' => '/case',
                        'is_featured' => 'yes',
                        'featured_label' => esc_html__( 'Most Popular', 'tanwar-associates' ),
                        'features_list' => "Multiple consultations\nLegal advice\nDocument drafting\nNegotiation support\nCourt representation\n-Priority support",
                        'plan_icon' => ['value' => 'fas fa-balance-scale', 'library' => 'fa-solid'],
                    ],
                    [
                        'plan_name' => esc_html__( 'Premium', 'tanwar-associates' ),
                        'plan_description' => esc_html__( 'Full legal partnership', 'tanwar-associates' ),
                        'price' => '50,000',
                        'price_period' => '/month',
                        'features_list' => "Unlimited consultations\nPriority legal advice\nAll document services\nFull representation\n24/7 Priority support\nDedicated attorney",
                        'plan_icon' => ['value' => 'fas fa-shield-alt', 'library' => 'fa-solid'],
                    ],
                ],
                'title_field' => '{{{ plan_name }}}',
            ]
        );

        $this->end_controls_section();

        // Layout Settings
        $this->start_controls_section(
            'section_layout',
            [
                'label' => esc_html__( 'Layout Settings', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => esc_html__( 'Columns', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-grid' => 'grid-template-columns: repeat({{VALUE}}, 1fr);',
                ],
            ]
        );

        $this->add_control(
            'card_style',
            [
                'label' => esc_html__( 'Card Style', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => esc_html__( 'Default', 'tanwar-associates' ),
                    'bordered' => esc_html__( 'Bordered', 'tanwar-associates' ),
                    'shadow' => esc_html__( 'Shadow', 'tanwar-associates' ),
                    'gradient' => esc_html__( 'Gradient Header', 'tanwar-associates' ),
                    'minimal' => esc_html__( 'Minimal', 'tanwar-associates' ),
                ],
            ]
        );

        $this->add_control(
            'featured_effect',
            [
                'label' => esc_html__( 'Featured Plan Effect', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'scale',
                'options' => [
                    'none' => esc_html__( 'None', 'tanwar-associates' ),
                    'scale' => esc_html__( 'Scale Up', 'tanwar-associates' ),
                    'border' => esc_html__( 'Colored Border', 'tanwar-associates' ),
                    'glow' => esc_html__( 'Glow Effect', 'tanwar-associates' ),
                    'ribbon' => esc_html__( 'Corner Ribbon', 'tanwar-associates' ),
                ],
            ]
        );

        $this->add_control(
            'show_icon',
            [
                'label' => esc_html__( 'Show Plan Icon', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tanwar-associates' ),
                'label_off' => esc_html__( 'No', 'tanwar-associates' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'feature_icon_available',
            [
                'label' => esc_html__( 'Available Feature Icon', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-check',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'feature_icon_unavailable',
            [
                'label' => esc_html__( 'Unavailable Feature Icon', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-times',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'equal_height',
            [
                'label' => esc_html__( 'Equal Height Cards', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tanwar-associates' ),
                'label_off' => esc_html__( 'No', 'tanwar-associates' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Section Style
        $this->start_controls_section(
            'section_style_section',
            [
                'label' => esc_html__( 'Section', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'section_padding',
            [
                'label' => esc_html__( 'Padding', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '80',
                    'right' => '20',
                    'bottom' => '80',
                    'left' => '20',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(),
            [
                'name' => 'section_background',
                'label' => esc_html__( 'Background', 'tanwar-associates' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .tanwar-pricing-section',
            ]
        );

        $this->end_controls_section();

        // Header Style
        $this->start_controls_section(
            'section_style_header',
            [
                'label' => esc_html__( 'Section Header', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Title Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => esc_html__( 'Title Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-pricing-title',
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => esc_html__( 'Subtitle Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'label' => esc_html__( 'Subtitle Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-pricing-subtitle',
            ]
        );

        $this->add_responsive_control(
            'header_spacing',
            [
                'label' => esc_html__( 'Header Bottom Spacing', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 50,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-header' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Card Style
        $this->start_controls_section(
            'section_style_card',
            [
                'label' => esc_html__( 'Pricing Card', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => esc_html__( 'Card Background', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_border_color',
            [
                'label' => esc_html__( 'Border Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '12',
                    'right' => '12',
                    'bottom' => '12',
                    'left' => '12',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_padding',
            [
                'label' => esc_html__( 'Card Padding', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '40',
                    'right' => '30',
                    'bottom' => '40',
                    'left' => '30',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_box_shadow',
                'label' => esc_html__( 'Box Shadow', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-pricing-card',
            ]
        );

        $this->add_responsive_control(
            'card_gap',
            [
                'label' => esc_html__( 'Gap Between Cards', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'default' => [
                    'size' => 30,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-grid' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Featured Card Style
        $this->start_controls_section(
            'section_style_featured',
            [
                'label' => esc_html__( 'Featured Card', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'featured_background',
            [
                'label' => esc_html__( 'Featured Background', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'featured_border_color',
            [
                'label' => esc_html__( 'Featured Border Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured.effect-border' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'featured_label_background',
            [
                'label' => esc_html__( 'Label Background', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-featured-label' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'featured_label_color',
            [
                'label' => esc_html__( 'Label Text Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-featured-label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'featured_label_typography',
                'label' => esc_html__( 'Label Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-featured-label',
            ]
        );

        $this->add_responsive_control(
            'featured_scale',
            [
                'label' => esc_html__( 'Featured Scale', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 1.3,
                        'step' => 0.01,
                    ],
                ],
                'default' => [
                    'size' => 1.05,
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured.effect-scale' => 'transform: scale({{SIZE}});',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'featured_box_shadow',
                'label' => esc_html__( 'Featured Box Shadow', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-pricing-card.is-featured',
            ]
        );

        $this->end_controls_section();

        // Plan Icon Style
        $this->start_controls_section(
            'section_style_plan_icon',
            [
                'label' => esc_html__( 'Plan Icon', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
                'condition' => [
                    'show_icon' => 'yes',
                ],
            ]
        );

        $this->add_responsive_control(
            'plan_icon_size',
            [
                'label' => esc_html__( 'Icon Size', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 50,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-plan-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tanwar-plan-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'plan_icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-plan-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tanwar-plan-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'featured_plan_icon_color',
            [
                'label' => esc_html__( 'Featured Icon Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured .tanwar-plan-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured .tanwar-plan-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'plan_icon_spacing',
            [
                'label' => esc_html__( 'Icon Bottom Spacing', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'size' => 20,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-plan-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Plan Name & Description Style
        $this->start_controls_section(
            'section_style_plan_info',
            [
                'label' => esc_html__( 'Plan Name & Description', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'plan_name_color',
            [
                'label' => esc_html__( 'Plan Name Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-plan-name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'plan_name_typography',
                'label' => esc_html__( 'Plan Name Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-plan-name',
            ]
        );

        $this->add_control(
            'plan_description_color',
            [
                'label' => esc_html__( 'Description Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-plan-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'plan_description_typography',
                'label' => esc_html__( 'Description Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-plan-description',
            ]
        );

        $this->end_controls_section();

        // Price Style
        $this->start_controls_section(
            'section_style_price',
            [
                'label' => esc_html__( 'Price', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'currency_color',
            [
                'label' => esc_html__( 'Currency Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-price-currency' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'currency_typography',
                'label' => esc_html__( 'Currency Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-price-currency',
            ]
        );

        $this->add_control(
            'price_color',
            [
                'label' => esc_html__( 'Price Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-price-amount' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'price_typography',
                'label' => esc_html__( 'Price Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-price-amount',
            ]
        );

        $this->add_control(
            'period_color',
            [
                'label' => esc_html__( 'Period Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-price-period' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'period_typography',
                'label' => esc_html__( 'Period Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-price-period',
            ]
        );

        $this->add_responsive_control(
            'price_spacing',
            [
                'label' => esc_html__( 'Price Section Spacing', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'default' => [
                    'size' => 25,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-price-wrapper' => 'margin: {{SIZE}}{{UNIT}} 0;',
                ],
            ]
        );

        $this->end_controls_section();

        // Features Style
        $this->start_controls_section(
            'section_style_features',
            [
                'label' => esc_html__( 'Features List', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'feature_text_color',
            [
                'label' => esc_html__( 'Feature Text Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-feature-item' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'feature_unavailable_color',
            [
                'label' => esc_html__( 'Unavailable Feature Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-feature-item.unavailable' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'feature_typography',
                'label' => esc_html__( 'Feature Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-feature-item',
            ]
        );

        $this->add_control(
            'feature_icon_available_color',
            [
                'label' => esc_html__( 'Available Icon Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-feature-item.available .tanwar-feature-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tanwar-feature-item.available .tanwar-feature-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'feature_icon_unavailable_color',
            [
                'label' => esc_html__( 'Unavailable Icon Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-feature-item.unavailable .tanwar-feature-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .tanwar-feature-item.unavailable .tanwar-feature-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'feature_icon_size',
            [
                'label' => esc_html__( 'Feature Icon Size', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'size' => 16,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-feature-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .tanwar-feature-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'feature_spacing',
            [
                'label' => esc_html__( 'Space Between Features', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 30,
                    ],
                ],
                'default' => [
                    'size' => 12,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-feature-item' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'features_list_spacing',
            [
                'label' => esc_html__( 'Features List Bottom Spacing', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                    ],
                ],
                'default' => [
                    'size' => 30,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-features-list' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Button Style
        $this->start_controls_section(
            'section_style_button',
            [
                'label' => esc_html__( 'Button', 'tanwar-associates' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs( 'button_tabs' );

        $this->start_controls_tab(
            'button_normal',
            [
                'label' => esc_html__( 'Normal', 'tanwar-associates' ),
            ]
        );

        $this->add_control(
            'button_text_color',
            [
                'label' => esc_html__( 'Text Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_background',
            [
                'label' => esc_html__( 'Background Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_border_color',
            [
                'label' => esc_html__( 'Border Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-button' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_hover',
            [
                'label' => esc_html__( 'Hover', 'tanwar-associates' ),
            ]
        );

        $this->add_control(
            'button_hover_text_color',
            [
                'label' => esc_html__( 'Text Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-button:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_background',
            [
                'label' => esc_html__( 'Background Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-button:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_border_color',
            [
                'label' => esc_html__( 'Border Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-button:hover' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'button_featured',
            [
                'label' => esc_html__( 'Featured', 'tanwar-associates' ),
            ]
        );

        $this->add_control(
            'featured_button_text_color',
            [
                'label' => esc_html__( 'Text Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured .tanwar-pricing-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'featured_button_background',
            [
                'label' => esc_html__( 'Background Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured .tanwar-pricing-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'featured_button_border_color',
            [
                'label' => esc_html__( 'Border Color', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-card.is-featured .tanwar-pricing-button' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'button_typography',
                'label' => esc_html__( 'Button Typography', 'tanwar-associates' ),
                'selector' => '{{WRAPPER}} .tanwar-pricing-button',
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'button_padding',
            [
                'label' => esc_html__( 'Button Padding', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '14',
                    'right' => '28',
                    'bottom' => '14',
                    'left' => '28',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_responsive_control(
            'button_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .tanwar-pricing-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '6',
                    'right' => '6',
                    'bottom' => '6',
                    'left' => '6',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_control(
            'button_full_width',
            [
                'label' => esc_html__( 'Full Width Button', 'tanwar-associates' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'tanwar-associates' ),
                'label_off' => esc_html__( 'No', 'tanwar-associates' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        
        $section_classes = 'tanwar-pricing-section';
        $grid_classes = 'tanwar-pricing-grid';
        
        if ( $settings['equal_height'] === 'yes' ) {
            $grid_classes .= ' equal-height';
        }
        ?>
        <section class="<?php echo esc_attr( $section_classes ); ?>">
            <div class="tanwar-pricing-container">
                <?php if ( $settings['section_title'] || $settings['section_subtitle'] ) : ?>
                    <div class="tanwar-pricing-header">
                        <?php if ( $settings['section_title'] ) : ?>
                            <h2 class="tanwar-pricing-title"><?php echo esc_html( $settings['section_title'] ); ?></h2>
                        <?php endif; ?>
                        <?php if ( $settings['section_subtitle'] ) : ?>
                            <p class="tanwar-pricing-subtitle"><?php echo esc_html( $settings['section_subtitle'] ); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="<?php echo esc_attr( $grid_classes ); ?>">
                    <?php foreach ( $settings['pricing_plans'] as $index => $plan ) : 
                        $card_classes = 'tanwar-pricing-card';
                        $card_classes .= ' style-' . $settings['card_style'];
                        
                        if ( $plan['is_featured'] === 'yes' ) {
                            $card_classes .= ' is-featured';
                            $card_classes .= ' effect-' . $settings['featured_effect'];
                        }
                        
                        // Parse features
                        $features = array_filter( array_map( 'trim', explode( "\n", $plan['features_list'] ) ) );
                    ?>
                        <div class="<?php echo esc_attr( $card_classes ); ?>">
                            <?php if ( $plan['is_featured'] === 'yes' && $plan['featured_label'] ) : ?>
                                <?php if ( $settings['featured_effect'] === 'ribbon' ) : ?>
                                    <div class="tanwar-featured-ribbon">
                                        <span><?php echo esc_html( $plan['featured_label'] ); ?></span>
                                    </div>
                                <?php else : ?>
                                    <div class="tanwar-featured-label">
                                        <?php echo esc_html( $plan['featured_label'] ); ?>
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                            <div class="tanwar-card-content">
                                <?php if ( $settings['show_icon'] === 'yes' && ! empty( $plan['plan_icon']['value'] ) ) : ?>
                                    <div class="tanwar-plan-icon">
                                        <?php \Elementor\Icons_Manager::render_icon( $plan['plan_icon'], [ 'aria-hidden' => 'true' ] ); ?>
                                    </div>
                                <?php endif; ?>

                                <h3 class="tanwar-plan-name"><?php echo esc_html( $plan['plan_name'] ); ?></h3>
                                
                                <?php if ( $plan['plan_description'] ) : ?>
                                    <p class="tanwar-plan-description"><?php echo esc_html( $plan['plan_description'] ); ?></p>
                                <?php endif; ?>

                                <div class="tanwar-price-wrapper">
                                    <span class="tanwar-price-currency"><?php echo esc_html( $plan['currency_symbol'] ); ?></span>
                                    <span class="tanwar-price-amount"><?php echo esc_html( $plan['price'] ); ?></span>
                                    <span class="tanwar-price-period"><?php echo esc_html( $plan['price_period'] ); ?></span>
                                </div>

                                <?php if ( ! empty( $features ) ) : ?>
                                    <ul class="tanwar-features-list">
                                        <?php foreach ( $features as $feature ) :
                                            $is_unavailable = strpos( $feature, '-' ) === 0;
                                            $feature_text = $is_unavailable ? substr( $feature, 1 ) : $feature;
                                            $feature_class = $is_unavailable ? 'unavailable' : 'available';
                                            $icon = $is_unavailable ? $settings['feature_icon_unavailable'] : $settings['feature_icon_available'];
                                        ?>
                                            <li class="tanwar-feature-item <?php echo esc_attr( $feature_class ); ?>">
                                                <span class="tanwar-feature-icon">
                                                    <?php \Elementor\Icons_Manager::render_icon( $icon, [ 'aria-hidden' => 'true' ] ); ?>
                                                </span>
                                                <span class="tanwar-feature-text"><?php echo esc_html( trim( $feature_text ) ); ?></span>
                                            </li>
                                        <?php endforeach; ?>
                                    </ul>
                                <?php endif; ?>

                                <?php if ( $plan['button_text'] ) : 
                                    $button_classes = 'tanwar-pricing-button';
                                    if ( $settings['button_full_width'] === 'yes' ) {
                                        $button_classes .= ' full-width';
                                    }
                                    
                                    $link_url = ! empty( $plan['button_link']['url'] ) ? $plan['button_link']['url'] : '#';
                                    $link_target = ! empty( $plan['button_link']['is_external'] ) ? ' target="_blank"' : '';
                                    $link_nofollow = ! empty( $plan['button_link']['nofollow'] ) ? ' rel="nofollow"' : '';
                                ?>
                                    <a href="<?php echo esc_url( $link_url ); ?>" class="<?php echo esc_attr( $button_classes ); ?>"<?php echo $link_target . $link_nofollow; ?>>
                                        <?php echo esc_html( $plan['button_text'] ); ?>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <style>
            .tanwar-pricing-section {
                width: 100%;
            }
            
            .tanwar-pricing-container {
                max-width: 1200px;
                margin: 0 auto;
            }
            
            .tanwar-pricing-header {
                text-align: center;
            }
            
            .tanwar-pricing-title {
                font-size: 36px;
                font-weight: 700;
                margin: 0 0 10px;
            }
            
            .tanwar-pricing-subtitle {
                font-size: 18px;
                opacity: 0.8;
                margin: 0;
            }
            
            .tanwar-pricing-grid {
                display: grid;
                align-items: start;
            }
            
            .tanwar-pricing-grid.equal-height {
                align-items: stretch;
            }
            
            .tanwar-pricing-grid.equal-height .tanwar-pricing-card {
                display: flex;
                flex-direction: column;
            }
            
            .tanwar-pricing-grid.equal-height .tanwar-card-content {
                display: flex;
                flex-direction: column;
                flex: 1;
            }
            
            .tanwar-pricing-grid.equal-height .tanwar-features-list {
                flex: 1;
            }
            
            .tanwar-pricing-card {
                position: relative;
                background: #ffffff;
                border: 1px solid #e5e5e5;
                transition: all 0.3s ease;
                overflow: hidden;
            }
            
            .tanwar-pricing-card:hover {
                transform: translateY(-5px);
            }
            
            .tanwar-pricing-card.style-bordered {
                border-width: 2px;
            }
            
            .tanwar-pricing-card.style-shadow {
                border: none;
                box-shadow: 0 10px 40px rgba(0, 0, 0, 0.1);
            }
            
            .tanwar-pricing-card.style-gradient .tanwar-plan-icon,
            .tanwar-pricing-card.style-gradient .tanwar-plan-name,
            .tanwar-pricing-card.style-gradient .tanwar-plan-description {
                position: relative;
                z-index: 1;
            }
            
            .tanwar-pricing-card.style-gradient::before {
                content: '';
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                height: 150px;
                background: linear-gradient(135deg, #1a365d 0%, #2c5282 100%);
                z-index: 0;
            }
            
            .tanwar-pricing-card.style-gradient .tanwar-plan-icon,
            .tanwar-pricing-card.style-gradient .tanwar-plan-name {
                color: #ffffff;
            }
            
            .tanwar-pricing-card.style-gradient .tanwar-plan-description {
                color: rgba(255, 255, 255, 0.8);
            }
            
            .tanwar-pricing-card.style-minimal {
                border: none;
                background: transparent;
            }
            
            .tanwar-pricing-card.style-minimal:hover {
                background: #f8f9fa;
            }
            
            /* Featured Effects */
            .tanwar-pricing-card.is-featured.effect-scale {
                z-index: 2;
            }
            
            .tanwar-pricing-card.is-featured.effect-border {
                border-width: 3px;
                border-color: #c9a962;
            }
            
            .tanwar-pricing-card.is-featured.effect-glow {
                box-shadow: 0 0 30px rgba(201, 169, 98, 0.4);
            }
            
            .tanwar-featured-label {
                display: inline-block;
                padding: 6px 16px;
                font-size: 12px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
                background: #c9a962;
                color: #ffffff;
                border-radius: 20px;
                margin-bottom: 15px;
            }
            
            .tanwar-featured-ribbon {
                position: absolute;
                top: 20px;
                right: -35px;
                transform: rotate(45deg);
                background: #c9a962;
                padding: 8px 40px;
                z-index: 10;
            }
            
            .tanwar-featured-ribbon span {
                font-size: 11px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 1px;
                color: #ffffff;
            }
            
            .tanwar-card-content {
                position: relative;
                z-index: 1;
                text-align: center;
            }
            
            .tanwar-plan-icon {
                display: inline-block;
                color: #1a365d;
            }
            
            .tanwar-plan-name {
                font-size: 24px;
                font-weight: 700;
                margin: 0 0 8px;
                color: #1a365d;
            }
            
            .tanwar-plan-description {
                font-size: 14px;
                color: #666666;
                margin: 0;
            }
            
            .tanwar-price-wrapper {
                display: flex;
                align-items: baseline;
                justify-content: center;
                gap: 2px;
            }
            
            .tanwar-price-currency {
                font-size: 24px;
                font-weight: 600;
                color: #1a365d;
            }
            
            .tanwar-price-amount {
                font-size: 48px;
                font-weight: 800;
                line-height: 1;
                color: #1a365d;
            }
            
            .tanwar-price-period {
                font-size: 14px;
                color: #666666;
            }
            
            .tanwar-features-list {
                list-style: none;
                padding: 0;
                margin: 0;
                text-align: left;
            }
            
            .tanwar-feature-item {
                display: flex;
                align-items: center;
                gap: 10px;
            }
            
            .tanwar-feature-item.unavailable {
                opacity: 0.5;
                text-decoration: line-through;
            }
            
            .tanwar-feature-icon {
                flex-shrink: 0;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            
            .tanwar-feature-item.available .tanwar-feature-icon {
                color: #22c55e;
            }
            
            .tanwar-feature-item.unavailable .tanwar-feature-icon {
                color: #ef4444;
            }
            
            .tanwar-feature-text {
                flex: 1;
            }
            
            .tanwar-pricing-button {
                display: inline-block;
                text-decoration: none;
                font-weight: 600;
                text-align: center;
                border: 2px solid #1a365d;
                background: transparent;
                color: #1a365d;
                transition: all 0.3s ease;
                cursor: pointer;
            }
            
            .tanwar-pricing-button:hover {
                background: #1a365d;
                color: #ffffff;
            }
            
            .tanwar-pricing-button.full-width {
                display: block;
                width: 100%;
            }
            
            .tanwar-pricing-card.is-featured .tanwar-pricing-button {
                background: #c9a962;
                border-color: #c9a962;
                color: #ffffff;
            }
            
            .tanwar-pricing-card.is-featured .tanwar-pricing-button:hover {
                background: #b8983f;
                border-color: #b8983f;
            }
            
            /* Responsive */
            @media (max-width: 768px) {
                .tanwar-pricing-card.is-featured.effect-scale {
                    transform: none;
                }
                
                .tanwar-pricing-title {
                    font-size: 28px;
                }
                
                .tanwar-price-amount {
                    font-size: 36px;
                }
            }
        </style>
        <?php
    }
}
