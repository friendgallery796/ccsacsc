<?php
/**
 * Elementor Team Grid Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Team_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_team_grid';
    }

    public function get_title() {
        return esc_html__('Team Grid', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-person';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['team', 'attorneys', 'lawyers', 'staff', 'grid', 'tanwar'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_subtitle',
            [
                'label' => esc_html__('Section Subtitle', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Expert Advocates', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => esc_html__('Section Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Our Legal Team', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'section_description',
            [
                'label' => esc_html__('Section Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Meet our experienced team of advocates dedicated to providing exceptional legal representation.', 'tanwar-associates'),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'name',
            [
                'label' => esc_html__('Name', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Adv. John Doe', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'role',
            [
                'label' => esc_html__('Role', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Senior Partner', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'specialization',
            [
                'label' => esc_html__('Specialization', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Civil & Corporate Law', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'experience',
            [
                'label' => esc_html__('Experience', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('25+ Years', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label' => esc_html__('Photo', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=500&fit=crop',
                ],
            ]
        );

        $repeater->add_control(
            'profile_link',
            [
                'label' => esc_html__('Profile Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->add_control(
            'team_members',
            [
                'label' => esc_html__('Team Members', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'name' => esc_html__('Adv. Rajesh Tanwar', 'tanwar-associates'),
                        'role' => esc_html__('Senior Partner', 'tanwar-associates'),
                        'specialization' => esc_html__('Civil & Corporate Law', 'tanwar-associates'),
                        'experience' => esc_html__('25+ Years', 'tanwar-associates'),
                    ],
                    [
                        'name' => esc_html__('Adv. Priya Sharma', 'tanwar-associates'),
                        'role' => esc_html__('Partner', 'tanwar-associates'),
                        'specialization' => esc_html__('Family & Matrimonial Law', 'tanwar-associates'),
                        'experience' => esc_html__('18+ Years', 'tanwar-associates'),
                    ],
                    [
                        'name' => esc_html__('Adv. Vikram Singh', 'tanwar-associates'),
                        'role' => esc_html__('Associate Partner', 'tanwar-associates'),
                        'specialization' => esc_html__('Criminal Law', 'tanwar-associates'),
                        'experience' => esc_html__('15+ Years', 'tanwar-associates'),
                    ],
                ],
                'title_field' => '{{{ name }}}',
            ]
        );

        $this->add_control(
            'columns',
            [
                'label' => esc_html__('Columns', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'options' => [
                    '2' => esc_html__('2 Columns', 'tanwar-associates'),
                    '3' => esc_html__('3 Columns', 'tanwar-associates'),
                    '4' => esc_html__('4 Columns', 'tanwar-associates'),
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_style',
            [
                'label' => esc_html__('Card Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'overlay',
                'options' => [
                    'overlay' => esc_html__('Image Overlay', 'tanwar-associates'),
                    'simple' => esc_html__('Simple Card', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => esc_html__('Accent Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#c9a44a',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $placeholder = tanwar_get_placeholder_image('attorney');
        ?>
        <section class="tanwar-team-section">
            <div class="container">
                <?php if (!empty($settings['section_subtitle']) || !empty($settings['section_title'])) : ?>
                <div class="section-header">
                    <?php if (!empty($settings['section_subtitle'])) : ?>
                        <span class="section-subtitle"><?php echo esc_html($settings['section_subtitle']); ?></span>
                    <?php endif; ?>
                    <?php if (!empty($settings['section_title'])) : ?>
                        <h2 class="section-title"><?php echo esc_html($settings['section_title']); ?></h2>
                    <?php endif; ?>
                    <?php if (!empty($settings['section_description'])) : ?>
                        <p class="section-description"><?php echo esc_html($settings['section_description']); ?></p>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <div class="tanwar-team-grid columns-<?php echo esc_attr($settings['columns']); ?>" style="--accent: <?php echo esc_attr($settings['accent_color']); ?>;">
                    <?php foreach ($settings['team_members'] as $member) : 
                        $image_url = !empty($member['image']['url']) ? $member['image']['url'] : $placeholder;
                    ?>
                    <div class="tanwar-team-card <?php echo esc_attr($settings['card_style']); ?>">
                        <div class="team-card-image">
                            <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($member['name']); ?>" onerror="this.src='<?php echo esc_url($placeholder); ?>'">
                            <?php if ($settings['card_style'] === 'overlay') : ?>
                            <div class="team-card-overlay">
                                <?php if (!empty($member['profile_link']['url'])) : ?>
                                <a href="<?php echo esc_url($member['profile_link']['url']); ?>" class="view-profile-btn">
                                    <?php esc_html_e('View Profile', 'tanwar-associates'); ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                        <line x1="5" y1="12" x2="19" y2="12"></line>
                                        <polyline points="12 5 19 12 12 19"></polyline>
                                    </svg>
                                </a>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="team-card-content">
                            <h3 class="team-member-name"><?php echo esc_html($member['name']); ?></h3>
                            <p class="team-member-role"><?php echo esc_html($member['role']); ?></p>
                            <?php if (!empty($member['specialization'])) : ?>
                            <p class="team-member-specialization"><?php echo esc_html($member['specialization']); ?></p>
                            <?php endif; ?>
                            <?php if (!empty($member['experience'])) : ?>
                            <p class="team-member-experience"><?php echo esc_html($member['experience']); ?> Experience</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}