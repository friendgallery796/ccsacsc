<?php
/**
 * Blog Posts Grid Widget for Elementor
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Blog_Posts_Grid_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_blog_posts_grid';
    }

    public function get_title() {
        return __('Blog Posts Grid', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-posts-grid';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['blog', 'posts', 'grid', 'news', 'articles', 'legal'];
    }

    protected function register_controls() {

        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => __('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => __('Section Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Latest Legal Insights', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'section_subtitle',
            [
                'label' => __('Section Subtitle', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('From Our Blog', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'section_description',
            [
                'label' => __('Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Stay informed with expert legal analysis, case studies, and updates on Indian law.', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'show_header',
            [
                'label' => __('Show Section Header', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Query Section
        $this->start_controls_section(
            'query_section',
            [
                'label' => __('Query', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'posts_per_page',
            [
                'label' => __('Posts Per Page', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 1,
                'max' => 24,
                'step' => 1,
                'default' => 6,
            ]
        );

        // Get categories for dropdown
        $categories = get_categories([
            'orderby' => 'name',
            'order' => 'ASC',
            'hide_empty' => false,
        ]);
        
        $category_options = ['all' => __('All Categories', 'tanwar-associates')];
        foreach ($categories as $category) {
            $category_options[$category->term_id] = $category->name;
        }

        $this->add_control(
            'category_filter',
            [
                'label' => __('Filter by Category', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'multiple' => true,
                'options' => $category_options,
                'default' => ['all'],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'orderby',
            [
                'label' => __('Order By', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'date',
                'options' => [
                    'date' => __('Date', 'tanwar-associates'),
                    'title' => __('Title', 'tanwar-associates'),
                    'modified' => __('Last Modified', 'tanwar-associates'),
                    'rand' => __('Random', 'tanwar-associates'),
                    'comment_count' => __('Comment Count', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'order',
            [
                'label' => __('Order', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'DESC',
                'options' => [
                    'DESC' => __('Descending', 'tanwar-associates'),
                    'ASC' => __('Ascending', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'offset',
            [
                'label' => __('Offset', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 0,
                'max' => 100,
                'step' => 1,
                'default' => 0,
                'description' => __('Number of posts to skip.', 'tanwar-associates'),
            ]
        );

        $this->end_controls_section();

        // Layout Section
        $this->start_controls_section(
            'layout_section',
            [
                'label' => __('Layout', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'layout_style',
            [
                'label' => __('Layout Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'grid',
                'options' => [
                    'grid' => __('Grid', 'tanwar-associates'),
                    'list' => __('List', 'tanwar-associates'),
                    'masonry' => __('Masonry', 'tanwar-associates'),
                    'featured' => __('Featured + Grid', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_responsive_control(
            'columns',
            [
                'label' => __('Columns', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '3',
                'tablet_default' => '2',
                'mobile_default' => '1',
                'options' => [
                    '1' => '1',
                    '2' => '2',
                    '3' => '3',
                    '4' => '4',
                ],
                'condition' => [
                    'layout_style!' => 'list',
                ],
            ]
        );

        $this->add_control(
            'show_category_filter',
            [
                'label' => __('Show Category Filter', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->add_control(
            'show_pagination',
            [
                'label' => __('Show Pagination', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->end_controls_section();

        // Post Elements Section
        $this->start_controls_section(
            'elements_section',
            [
                'label' => __('Post Elements', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_image',
            [
                'label' => __('Show Featured Image', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'image_size',
            [
                'label' => __('Image Size', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'medium_large',
                'options' => [
                    'thumbnail' => __('Thumbnail', 'tanwar-associates'),
                    'medium' => __('Medium', 'tanwar-associates'),
                    'medium_large' => __('Medium Large', 'tanwar-associates'),
                    'large' => __('Large', 'tanwar-associates'),
                    'full' => __('Full', 'tanwar-associates'),
                ],
                'condition' => [
                    'show_image' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_category',
            [
                'label' => __('Show Category', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_date',
            [
                'label' => __('Show Date', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_author',
            [
                'label' => __('Show Author', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_excerpt',
            [
                'label' => __('Show Excerpt', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'excerpt_length',
            [
                'label' => __('Excerpt Length', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'min' => 10,
                'max' => 100,
                'step' => 5,
                'default' => 20,
                'condition' => [
                    'show_excerpt' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_read_more',
            [
                'label' => __('Show Read More', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => __('Read More Text', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Read More', 'tanwar-associates'),
                'condition' => [
                    'show_read_more' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_reading_time',
            [
                'label' => __('Show Reading Time', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'no',
            ]
        );

        $this->end_controls_section();

        // View All Section
        $this->start_controls_section(
            'view_all_section',
            [
                'label' => __('View All Button', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_view_all',
            [
                'label' => __('Show View All Button', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'tanwar-associates'),
                'label_off' => __('Hide', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'view_all_text',
            [
                'label' => __('Button Text', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('View All Articles', 'tanwar-associates'),
                'condition' => [
                    'show_view_all' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'view_all_link',
            [
                'label' => __('Button Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'tanwar-associates'),
                'default' => [
                    'url' => '',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'show_view_all' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section - Card
        $this->start_controls_section(
            'card_style_section',
            [
                'label' => __('Card Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => __('Card Background', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .blog-post-card' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'card_border',
                'label' => __('Border', 'tanwar-associates'),
                'selector' => '{{WRAPPER}} .blog-post-card',
            ]
        );

        $this->add_control(
            'card_border_radius',
            [
                'label' => __('Border Radius', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .blog-post-card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => 12,
                    'right' => 12,
                    'bottom' => 12,
                    'left' => 12,
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_box_shadow',
                'label' => __('Box Shadow', 'tanwar-associates'),
                'selector' => '{{WRAPPER}} .blog-post-card',
            ]
        );

        $this->add_responsive_control(
            'card_padding',
            [
                'label' => __('Content Padding', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .blog-post-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => 24,
                    'right' => 24,
                    'bottom' => 24,
                    'left' => 24,
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_gap',
            [
                'label' => __('Card Gap', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', 'em'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 60,
                        'step' => 4,
                    ],
                ],
                'default' => [
                    'unit' => 'px',
                    'size' => 24,
                ],
                'selectors' => [
                    '{{WRAPPER}} .blog-posts-grid' => 'gap: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section - Typography
        $this->start_controls_section(
            'typography_style_section',
            [
                'label' => __('Typography', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'label' => __('Title Typography', 'tanwar-associates'),
                'selector' => '{{WRAPPER}} .blog-post-title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Title Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-post-title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label' => __('Title Hover Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-post-title a:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'excerpt_typography',
                'label' => __('Excerpt Typography', 'tanwar-associates'),
                'selector' => '{{WRAPPER}} .blog-post-excerpt',
            ]
        );

        $this->add_control(
            'excerpt_color',
            [
                'label' => __('Excerpt Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-post-excerpt' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'meta_color',
            [
                'label' => __('Meta Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-post-meta' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .blog-post-meta a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section - Category Badge
        $this->start_controls_section(
            'category_style_section',
            [
                'label' => __('Category Badge', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'category_bg_color',
            [
                'label' => __('Background Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#1a365d',
                'selectors' => [
                    '{{WRAPPER}} .blog-post-category' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'category_text_color',
            [
                'label' => __('Text Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .blog-post-category' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section - Read More Button
        $this->start_controls_section(
            'button_style_section',
            [
                'label' => __('Read More Button', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label' => __('Text Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-post-read-more' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_hover_color',
            [
                'label' => __('Hover Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .blog-post-read-more:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();

        // Build query args
        $args = [
            'post_type' => 'post',
            'posts_per_page' => $settings['posts_per_page'],
            'orderby' => $settings['orderby'],
            'order' => $settings['order'],
            'offset' => $settings['offset'],
            'post_status' => 'publish',
        ];

        // Category filter
        if (!empty($settings['category_filter']) && !in_array('all', $settings['category_filter'])) {
            $args['cat'] = implode(',', $settings['category_filter']);
        }

        $query = new WP_Query($args);

        // Get all categories for filter
        $all_categories = get_categories(['hide_empty' => true]);

        // Layout classes
        $layout_class = 'layout-' . $settings['layout_style'];
        $columns_class = 'columns-' . $settings['columns'];
        ?>

        <section class="tanwar-blog-posts-widget">
            <?php if ($settings['show_header'] === 'yes') : ?>
            <div class="section-header">
                <?php if ($settings['section_subtitle']) : ?>
                    <span class="section-subtitle"><?php echo esc_html($settings['section_subtitle']); ?></span>
                <?php endif; ?>
                <?php if ($settings['section_title']) : ?>
                    <h2 class="section-title"><?php echo esc_html($settings['section_title']); ?></h2>
                <?php endif; ?>
                <?php if ($settings['section_description']) : ?>
                    <p class="section-description"><?php echo esc_html($settings['section_description']); ?></p>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <?php if ($settings['show_category_filter'] === 'yes' && !empty($all_categories)) : ?>
            <div class="blog-category-filter">
                <button class="filter-btn active" data-category="all"><?php esc_html_e('All', 'tanwar-associates'); ?></button>
                <?php foreach ($all_categories as $category) : ?>
                    <button class="filter-btn" data-category="<?php echo esc_attr($category->slug); ?>">
                        <?php echo esc_html($category->name); ?>
                    </button>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <?php if ($query->have_posts()) : ?>
                <div class="blog-posts-grid <?php echo esc_attr($layout_class . ' ' . $columns_class); ?>">
                    <?php 
                    $post_index = 0;
                    while ($query->have_posts()) : $query->the_post(); 
                        $post_index++;
                        $categories = get_the_category();
                        $category_slugs = wp_list_pluck($categories, 'slug');
                        $is_featured = ($settings['layout_style'] === 'featured' && $post_index === 1);
                    ?>
                        <article class="blog-post-card <?php echo $is_featured ? 'featured-post' : ''; ?>" data-categories="<?php echo esc_attr(implode(' ', $category_slugs)); ?>">
                            <?php if ($settings['show_image'] === 'yes') : ?>
                                <div class="blog-post-image">
                                    <a href="<?php the_permalink(); ?>">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <?php the_post_thumbnail($settings['image_size'], ['loading' => 'lazy']); ?>
                                        <?php else : ?>
                                            <img src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&h=400&fit=crop" alt="<?php the_title_attribute(); ?>" loading="lazy">
                                        <?php endif; ?>
                                    </a>
                                    <?php if ($settings['show_category'] === 'yes' && !empty($categories)) : ?>
                                        <span class="blog-post-category">
                                            <?php echo esc_html($categories[0]->name); ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>

                            <div class="blog-post-content">
                                <?php if ($settings['show_date'] === 'yes' || $settings['show_author'] === 'yes' || $settings['show_reading_time'] === 'yes') : ?>
                                    <div class="blog-post-meta">
                                        <?php if ($settings['show_date'] === 'yes') : ?>
                                            <span class="post-date">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                                    <line x1="16" y1="2" x2="16" y2="6"></line>
                                                    <line x1="8" y1="2" x2="8" y2="6"></line>
                                                    <line x1="3" y1="10" x2="21" y2="10"></line>
                                                </svg>
                                                <?php echo get_the_date(); ?>
                                            </span>
                                        <?php endif; ?>

                                        <?php if ($settings['show_author'] === 'yes') : ?>
                                            <span class="post-author">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                                                    <circle cx="12" cy="7" r="4"></circle>
                                                </svg>
                                                <?php the_author(); ?>
                                            </span>
                                        <?php endif; ?>

                                        <?php if ($settings['show_reading_time'] === 'yes') : ?>
                                            <span class="post-reading-time">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <circle cx="12" cy="12" r="10"></circle>
                                                    <polyline points="12 6 12 12 16 14"></polyline>
                                                </svg>
                                                <?php 
                                                $content = get_the_content();
                                                $word_count = str_word_count(strip_tags($content));
                                                $reading_time = ceil($word_count / 200);
                                                echo esc_html($reading_time) . ' ' . __('min read', 'tanwar-associates');
                                                ?>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>

                                <h3 class="blog-post-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>

                                <?php if ($settings['show_excerpt'] === 'yes') : ?>
                                    <p class="blog-post-excerpt">
                                        <?php echo wp_trim_words(get_the_excerpt(), $settings['excerpt_length'], '...'); ?>
                                    </p>
                                <?php endif; ?>

                                <?php if ($settings['show_read_more'] === 'yes') : ?>
                                    <a href="<?php the_permalink(); ?>" class="blog-post-read-more">
                                        <?php echo esc_html($settings['read_more_text']); ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                            <line x1="5" y1="12" x2="19" y2="12"></line>
                                            <polyline points="12 5 19 12 12 19"></polyline>
                                        </svg>
                                    </a>
                                <?php endif; ?>
                            </div>
                        </article>
                    <?php endwhile; ?>
                </div>

                <?php if ($settings['show_pagination'] === 'yes' && $query->max_num_pages > 1) : ?>
                    <div class="blog-pagination">
                        <?php
                        echo paginate_links([
                            'total' => $query->max_num_pages,
                            'current' => max(1, get_query_var('paged')),
                            'prev_text' => '&laquo;',
                            'next_text' => '&raquo;',
                        ]);
                        ?>
                    </div>
                <?php endif; ?>

                <?php wp_reset_postdata(); ?>

            <?php else : ?>
                <div class="no-posts-found">
                    <p><?php esc_html_e('No posts found.', 'tanwar-associates'); ?></p>
                </div>
            <?php endif; ?>

            <?php if ($settings['show_view_all'] === 'yes') : 
                $view_all_url = !empty($settings['view_all_link']['url']) ? $settings['view_all_link']['url'] : get_permalink(get_option('page_for_posts'));
                $target = $settings['view_all_link']['is_external'] ? ' target="_blank"' : '';
                $nofollow = $settings['view_all_link']['nofollow'] ? ' rel="nofollow"' : '';
            ?>
                <div class="blog-view-all">
                    <a href="<?php echo esc_url($view_all_url); ?>" class="btn btn-outline"<?php echo $target . $nofollow; ?>>
                        <?php echo esc_html($settings['view_all_text']); ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
            <?php endif; ?>
        </section>

        <style>
            .tanwar-blog-posts-widget {
                padding: 4rem 0;
            }

            .tanwar-blog-posts-widget .section-header {
                text-align: center;
                margin-bottom: 3rem;
            }

            .tanwar-blog-posts-widget .section-subtitle {
                display: inline-block;
                color: var(--accent, #c9a227);
                font-size: 0.875rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.1em;
                margin-bottom: 0.75rem;
            }

            .tanwar-blog-posts-widget .section-title {
                font-size: 2.5rem;
                font-weight: 700;
                color: var(--foreground, #0f172a);
                margin-bottom: 1rem;
            }

            .tanwar-blog-posts-widget .section-description {
                color: var(--muted-foreground, #64748b);
                max-width: 600px;
                margin: 0 auto;
                font-size: 1.0625rem;
            }

            /* Category Filter */
            .blog-category-filter {
                display: flex;
                flex-wrap: wrap;
                justify-content: center;
                gap: 0.75rem;
                margin-bottom: 2.5rem;
            }

            .blog-category-filter .filter-btn {
                padding: 0.625rem 1.25rem;
                border: 1px solid var(--border, #e2e8f0);
                background: var(--background, #ffffff);
                color: var(--foreground, #0f172a);
                border-radius: 2rem;
                font-size: 0.875rem;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .blog-category-filter .filter-btn:hover,
            .blog-category-filter .filter-btn.active {
                background: var(--primary, #1a365d);
                color: var(--primary-foreground, #ffffff);
                border-color: var(--primary, #1a365d);
            }

            /* Posts Grid */
            .blog-posts-grid {
                display: grid;
                gap: 1.5rem;
            }

            .blog-posts-grid.columns-1 { grid-template-columns: 1fr; }
            .blog-posts-grid.columns-2 { grid-template-columns: repeat(2, 1fr); }
            .blog-posts-grid.columns-3 { grid-template-columns: repeat(3, 1fr); }
            .blog-posts-grid.columns-4 { grid-template-columns: repeat(4, 1fr); }

            /* List Layout */
            .blog-posts-grid.layout-list {
                grid-template-columns: 1fr;
            }

            .blog-posts-grid.layout-list .blog-post-card {
                display: grid;
                grid-template-columns: 300px 1fr;
                gap: 2rem;
            }

            .blog-posts-grid.layout-list .blog-post-image {
                height: 100%;
                min-height: 200px;
            }

            /* Featured Layout */
            .blog-posts-grid.layout-featured {
                grid-template-columns: repeat(2, 1fr);
            }

            .blog-posts-grid.layout-featured .featured-post {
                grid-column: span 2;
            }

            .blog-posts-grid.layout-featured .featured-post .blog-post-image {
                height: 400px;
            }

            .blog-posts-grid.layout-featured .featured-post .blog-post-title {
                font-size: 1.75rem;
            }

            /* Post Card */
            .blog-post-card {
                background: var(--card, #ffffff);
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
                transition: all 0.3s ease;
            }

            .blog-post-card:hover {
                transform: translateY(-4px);
                box-shadow: 0 12px 40px rgba(0, 0, 0, 0.12);
            }

            /* Post Image */
            .blog-post-image {
                position: relative;
                height: 220px;
                overflow: hidden;
            }

            .blog-post-image img {
                width: 100%;
                height: 100%;
                object-fit: cover;
                transition: transform 0.5s ease;
            }

            .blog-post-card:hover .blog-post-image img {
                transform: scale(1.05);
            }

            .blog-post-category {
                position: absolute;
                top: 1rem;
                left: 1rem;
                background: var(--primary, #1a365d);
                color: var(--primary-foreground, #ffffff);
                padding: 0.375rem 0.875rem;
                border-radius: 2rem;
                font-size: 0.75rem;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.05em;
            }

            /* Post Content */
            .blog-post-content {
                padding: 1.5rem;
            }

            .blog-post-meta {
                display: flex;
                flex-wrap: wrap;
                align-items: center;
                gap: 1rem;
                margin-bottom: 0.75rem;
                font-size: 0.8125rem;
                color: var(--muted-foreground, #64748b);
            }

            .blog-post-meta span {
                display: flex;
                align-items: center;
                gap: 0.375rem;
            }

            .blog-post-meta svg {
                opacity: 0.7;
            }

            .blog-post-title {
                font-size: 1.25rem;
                font-weight: 700;
                line-height: 1.4;
                margin-bottom: 0.75rem;
            }

            .blog-post-title a {
                color: var(--foreground, #0f172a);
                text-decoration: none;
                transition: color 0.3s ease;
            }

            .blog-post-title a:hover {
                color: var(--primary, #1a365d);
            }

            .blog-post-excerpt {
                color: var(--muted-foreground, #64748b);
                font-size: 0.9375rem;
                line-height: 1.7;
                margin-bottom: 1rem;
            }

            .blog-post-read-more {
                display: inline-flex;
                align-items: center;
                gap: 0.5rem;
                color: var(--accent, #c9a227);
                font-weight: 600;
                font-size: 0.875rem;
                text-decoration: none;
                transition: all 0.3s ease;
            }

            .blog-post-read-more:hover {
                color: var(--primary, #1a365d);
                gap: 0.75rem;
            }

            /* Pagination */
            .blog-pagination {
                display: flex;
                justify-content: center;
                gap: 0.5rem;
                margin-top: 3rem;
            }

            .blog-pagination .page-numbers {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 40px;
                height: 40px;
                border: 1px solid var(--border, #e2e8f0);
                border-radius: 8px;
                color: var(--foreground, #0f172a);
                text-decoration: none;
                font-weight: 500;
                transition: all 0.3s ease;
            }

            .blog-pagination .page-numbers:hover,
            .blog-pagination .page-numbers.current {
                background: var(--primary, #1a365d);
                color: var(--primary-foreground, #ffffff);
                border-color: var(--primary, #1a365d);
            }

            /* View All Button */
            .blog-view-all {
                text-align: center;
                margin-top: 3rem;
            }

            .blog-view-all .btn {
                display: inline-flex;
                align-items: center;
                gap: 0.5rem;
                padding: 0.875rem 2rem;
                border: 2px solid var(--primary, #1a365d);
                color: var(--primary, #1a365d);
                background: transparent;
                border-radius: 8px;
                font-weight: 600;
                text-decoration: none;
                transition: all 0.3s ease;
            }

            .blog-view-all .btn:hover {
                background: var(--primary, #1a365d);
                color: var(--primary-foreground, #ffffff);
            }

            /* No Posts */
            .no-posts-found {
                text-align: center;
                padding: 4rem 2rem;
                color: var(--muted-foreground, #64748b);
            }

            /* Responsive */
            @media (max-width: 1024px) {
                .blog-posts-grid.columns-4 { grid-template-columns: repeat(3, 1fr); }
                .blog-posts-grid.layout-featured .featured-post { grid-column: span 3; }
            }

            @media (max-width: 768px) {
                .blog-posts-grid.columns-3,
                .blog-posts-grid.columns-4 { grid-template-columns: repeat(2, 1fr); }
                .blog-posts-grid.layout-list .blog-post-card { grid-template-columns: 1fr; }
                .blog-posts-grid.layout-featured { grid-template-columns: 1fr; }
                .blog-posts-grid.layout-featured .featured-post { grid-column: span 1; }
                .tanwar-blog-posts-widget .section-title { font-size: 2rem; }
            }

            @media (max-width: 480px) {
                .blog-posts-grid.columns-2,
                .blog-posts-grid.columns-3,
                .blog-posts-grid.columns-4 { grid-template-columns: 1fr; }
                .blog-category-filter { justify-content: flex-start; overflow-x: auto; flex-wrap: nowrap; padding-bottom: 0.5rem; }
            }
        </style>

        <script>
        (function() {
            document.addEventListener('DOMContentLoaded', function() {
                const filterButtons = document.querySelectorAll('.tanwar-blog-posts-widget .filter-btn');
                const postCards = document.querySelectorAll('.tanwar-blog-posts-widget .blog-post-card');
                
                filterButtons.forEach(button => {
                    button.addEventListener('click', function() {
                        const filter = this.dataset.category;
                        
                        // Update active button
                        filterButtons.forEach(btn => btn.classList.remove('active'));
                        this.classList.add('active');
                        
                        // Filter posts
                        postCards.forEach(card => {
                            const categories = card.dataset.categories.split(' ');
                            if (filter === 'all' || categories.includes(filter)) {
                                card.style.display = 'block';
                            } else {
                                card.style.display = 'none';
                            }
                        });
                    });
                });
            });
        })();
        </script>

        <?php
    }
}
