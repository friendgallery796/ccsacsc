<?php
/**
 * Elementor Team Member Card Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Team_Member_Card_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_team_member_card';
    }

    public function get_title() {
        return esc_html__('Team Member Card', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-user-circle-o';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['team', 'member', 'attorney', 'lawyer', 'card', 'tanwar'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'image',
            [
                'label' => esc_html__('Photo', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=500&fit=crop',
                ],
            ]
        );

        $this->add_control(
            'name',
            [
                'label' => esc_html__('Name', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Adv. Rajesh Tanwar', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'role',
            [
                'label' => esc_html__('Role', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Senior Partner', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'specialization',
            [
                'label' => esc_html__('Specialization', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Civil & Corporate Law', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'experience',
            [
                'label' => esc_html__('Experience', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('25+ Years', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'education',
            [
                'label' => esc_html__('Education', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('LL.M., Rajasthan University', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'bar_council',
            [
                'label' => esc_html__('Bar Council', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Bar Council of Rajasthan', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'courts',
            [
                'label' => esc_html__('Courts', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Supreme Court, Rajasthan High Court', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'bio',
            [
                'label' => esc_html__('Bio', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Experienced advocate with expertise in civil litigation and corporate law matters.', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'profile_link',
            [
                'label' => esc_html__('Profile Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_style',
            [
                'label' => esc_html__('Card Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'detailed',
                'options' => [
                    'simple' => esc_html__('Simple', 'tanwar-associates'),
                    'detailed' => esc_html__('Detailed', 'tanwar-associates'),
                    'horizontal' => esc_html__('Horizontal', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => esc_html__('Accent Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#c9a44a',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $placeholder = tanwar_get_placeholder_image('attorney');
        $image_url = !empty($settings['image']['url']) ? $settings['image']['url'] : $placeholder;
        ?>
        <div class="tanwar-single-team-card <?php echo esc_attr($settings['card_style']); ?>" style="--accent: <?php echo esc_attr($settings['accent_color']); ?>;">
            <div class="team-card-image">
                <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($settings['name']); ?>" onerror="this.src='<?php echo esc_url($placeholder); ?>'">
                <div class="team-card-overlay">
                    <?php if (!empty($settings['profile_link']['url'])) : ?>
                    <a href="<?php echo esc_url($settings['profile_link']['url']); ?>" class="view-profile-btn">
                        <?php esc_html_e('View Profile', 'tanwar-associates'); ?>
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="team-card-content">
                <h3 class="team-member-name"><?php echo esc_html($settings['name']); ?></h3>
                <p class="team-member-role"><?php echo esc_html($settings['role']); ?></p>
                
                <?php if ($settings['card_style'] === 'detailed' || $settings['card_style'] === 'horizontal') : ?>
                <div class="team-member-details">
                    <?php if (!empty($settings['specialization'])) : ?>
                    <div class="detail-item">
                        <span class="detail-label"><?php esc_html_e('Specialization:', 'tanwar-associates'); ?></span>
                        <span class="detail-value"><?php echo esc_html($settings['specialization']); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['experience'])) : ?>
                    <div class="detail-item">
                        <span class="detail-label"><?php esc_html_e('Experience:', 'tanwar-associates'); ?></span>
                        <span class="detail-value"><?php echo esc_html($settings['experience']); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['education'])) : ?>
                    <div class="detail-item">
                        <span class="detail-label"><?php esc_html_e('Education:', 'tanwar-associates'); ?></span>
                        <span class="detail-value"><?php echo esc_html($settings['education']); ?></span>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($settings['courts'])) : ?>
                    <div class="detail-item">
                        <span class="detail-label"><?php esc_html_e('Courts:', 'tanwar-associates'); ?></span>
                        <span class="detail-value"><?php echo esc_html($settings['courts']); ?></span>
                    </div>
                    <?php endif; ?>
                </div>
                
                <?php if (!empty($settings['bio'])) : ?>
                <p class="team-member-bio"><?php echo esc_html($settings['bio']); ?></p>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }
}