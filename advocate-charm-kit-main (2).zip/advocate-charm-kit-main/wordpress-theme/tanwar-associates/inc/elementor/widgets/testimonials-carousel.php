<?php
/**
 * Elementor Testimonials Carousel Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Testimonials_Carousel_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_testimonials_carousel';
    }

    public function get_title() {
        return esc_html__('Testimonials Carousel', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-testimonial-carousel';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['testimonials', 'reviews', 'carousel', 'slider', 'tanwar'];
    }

    public function get_script_depends() {
        return ['tanwar-elementor-widgets'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_subtitle',
            [
                'label' => esc_html__('Section Subtitle', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Client Testimonials', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => esc_html__('Section Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('What Our Clients Say', 'tanwar-associates'),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'name',
            [
                'label' => esc_html__('Client Name', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Client Name', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'location',
            [
                'label' => esc_html__('Location', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Jaipur, Rajasthan', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'case_type',
            [
                'label' => esc_html__('Case Type', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Property Dispute', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'testimonial',
            [
                'label' => esc_html__('Testimonial', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Excellent legal services. The team was professional and handled my case with utmost care.', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'rating',
            [
                'label' => esc_html__('Rating', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '5',
                'options' => [
                    '1' => '1 Star',
                    '2' => '2 Stars',
                    '3' => '3 Stars',
                    '4' => '4 Stars',
                    '5' => '5 Stars',
                ],
            ]
        );

        $repeater->add_control(
            'image',
            [
                'label' => esc_html__('Client Photo', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
                ],
            ]
        );

        $this->add_control(
            'testimonials',
            [
                'label' => esc_html__('Testimonials', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'name' => esc_html__('Ramesh Kumar', 'tanwar-associates'),
                        'location' => esc_html__('Jaipur, Rajasthan', 'tanwar-associates'),
                        'case_type' => esc_html__('Property Dispute', 'tanwar-associates'),
                        'testimonial' => esc_html__('Tanwar & Associates provided excellent representation in my property dispute case. Their expertise and dedication helped me win a case that had been pending for years.', 'tanwar-associates'),
                        'rating' => '5',
                    ],
                    [
                        'name' => esc_html__('Priya Agarwal', 'tanwar-associates'),
                        'location' => esc_html__('Jodhpur, Rajasthan', 'tanwar-associates'),
                        'case_type' => esc_html__('Family Law', 'tanwar-associates'),
                        'testimonial' => esc_html__('Very professional handling of my divorce case. They were sensitive to the emotional aspects while being firm on legal matters.', 'tanwar-associates'),
                        'rating' => '5',
                    ],
                    [
                        'name' => esc_html__('Suresh Sharma', 'tanwar-associates'),
                        'location' => esc_html__('Udaipur, Rajasthan', 'tanwar-associates'),
                        'case_type' => esc_html__('Criminal Defense', 'tanwar-associates'),
                        'testimonial' => esc_html__('Got bail within 48 hours thanks to the quick action of the team. Highly recommended for criminal matters.', 'tanwar-associates'),
                        'rating' => '5',
                    ],
                ],
                'title_field' => '{{{ name }}}',
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__('Autoplay', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'tanwar-associates'),
                'label_off' => esc_html__('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => esc_html__('Autoplay Speed (ms)', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 5000,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_style',
            [
                'label' => esc_html__('Card Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => esc_html__('Default', 'tanwar-associates'),
                    'minimal' => esc_html__('Minimal', 'tanwar-associates'),
                    'boxed' => esc_html__('Boxed', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => esc_html__('Accent Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#c9a44a',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $placeholder = tanwar_get_placeholder_image('testimonial');
        $widget_id = $this->get_id();
        ?>
        <section class="tanwar-testimonials-section" style="--accent: <?php echo esc_attr($settings['accent_color']); ?>;">
            <div class="container">
                <?php if (!empty($settings['section_subtitle']) || !empty($settings['section_title'])) : ?>
                <div class="section-header">
                    <?php if (!empty($settings['section_subtitle'])) : ?>
                        <span class="section-subtitle"><?php echo esc_html($settings['section_subtitle']); ?></span>
                    <?php endif; ?>
                    <?php if (!empty($settings['section_title'])) : ?>
                        <h2 class="section-title"><?php echo esc_html($settings['section_title']); ?></h2>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <div class="tanwar-testimonials-carousel <?php echo esc_attr($settings['card_style']); ?>" 
                     data-autoplay="<?php echo esc_attr($settings['autoplay']); ?>"
                     data-speed="<?php echo esc_attr($settings['autoplay_speed']); ?>"
                     id="testimonials-<?php echo esc_attr($widget_id); ?>">
                    <div class="testimonials-track">
                        <?php foreach ($settings['testimonials'] as $index => $testimonial) : 
                            $image_url = !empty($testimonial['image']['url']) ? $testimonial['image']['url'] : $placeholder;
                        ?>
                        <div class="testimonial-slide <?php echo $index === 0 ? 'active' : ''; ?>">
                            <div class="testimonial-card">
                                <div class="testimonial-quote">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="currentColor">
                                        <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z"/>
                                    </svg>
                                </div>
                                <p class="testimonial-text"><?php echo esc_html($testimonial['testimonial']); ?></p>
                                <div class="testimonial-rating">
                                    <?php for ($i = 1; $i <= 5; $i++) : ?>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" 
                                             fill="<?php echo $i <= intval($testimonial['rating']) ? 'currentColor' : 'none'; ?>" 
                                             stroke="currentColor" stroke-width="2">
                                            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                        </svg>
                                    <?php endfor; ?>
                                </div>
                                <div class="testimonial-author">
                                    <img src="<?php echo esc_url($image_url); ?>" alt="<?php echo esc_attr($testimonial['name']); ?>" class="author-image" onerror="this.src='<?php echo esc_url($placeholder); ?>'">
                                    <div class="author-info">
                                        <h4 class="author-name"><?php echo esc_html($testimonial['name']); ?></h4>
                                        <?php if (!empty($testimonial['location'])) : ?>
                                        <p class="author-location"><?php echo esc_html($testimonial['location']); ?></p>
                                        <?php endif; ?>
                                        <?php if (!empty($testimonial['case_type'])) : ?>
                                        <span class="case-type"><?php echo esc_html($testimonial['case_type']); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <?php if (count($settings['testimonials']) > 1) : ?>
                    <div class="testimonials-nav">
                        <button class="nav-prev" aria-label="<?php esc_attr_e('Previous testimonial', 'tanwar-associates'); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="15 18 9 12 15 6"></polyline>
                            </svg>
                        </button>
                        <div class="testimonials-dots">
                            <?php foreach ($settings['testimonials'] as $index => $testimonial) : ?>
                            <button class="dot <?php echo $index === 0 ? 'active' : ''; ?>" data-index="<?php echo esc_attr($index); ?>"></button>
                            <?php endforeach; ?>
                        </div>
                        <button class="nav-next" aria-label="<?php esc_attr_e('Next testimonial', 'tanwar-associates'); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg>
                        </button>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php
    }
}