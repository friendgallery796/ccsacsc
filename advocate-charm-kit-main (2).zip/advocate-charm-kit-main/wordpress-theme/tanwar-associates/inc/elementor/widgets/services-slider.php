<?php
/**
 * Services Slider Widget for Elementor
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Services_Slider_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_services_slider';
    }

    public function get_title() {
        return __('Services Slider', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-slider-push';
    }

    public function get_categories() {
        return ['tanwar-elements'];
    }

    public function get_keywords() {
        return ['services', 'slider', 'carousel', 'practice', 'areas'];
    }

    public function get_script_depends() {
        return ['tanwar-elementor-widgets'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'section_content',
            [
                'label' => __('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'section_title',
            [
                'label' => __('Section Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Our Services', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'section_subtitle',
            [
                'label' => __('Section Subtitle', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Comprehensive legal solutions tailored to your needs', 'tanwar-associates'),
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'service_icon',
            [
                'label' => __('Icon', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-balance-scale',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $repeater->add_control(
            'service_title',
            [
                'label' => __('Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Service Title', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'service_description',
            [
                'label' => __('Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => __('Service description goes here.', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'service_link',
            [
                'label' => __('Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'placeholder' => __('https://your-link.com', 'tanwar-associates'),
                'default' => [
                    'url' => '#',
                ],
            ]
        );

        $repeater->add_control(
            'service_image',
            [
                'label' => __('Background Image', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::MEDIA,
                'default' => [
                    'url' => \Elementor\Utils::get_placeholder_image_src(),
                ],
            ]
        );

        $this->add_control(
            'services_list',
            [
                'label' => __('Services', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'service_title' => __('Corporate Law', 'tanwar-associates'),
                        'service_description' => __('Expert guidance for business formation, contracts, and corporate governance.', 'tanwar-associates'),
                    ],
                    [
                        'service_title' => __('Civil Litigation', 'tanwar-associates'),
                        'service_description' => __('Strong representation in civil disputes and courtroom advocacy.', 'tanwar-associates'),
                    ],
                    [
                        'service_title' => __('Family Law', 'tanwar-associates'),
                        'service_description' => __('Compassionate legal support for divorce, custody, and family matters.', 'tanwar-associates'),
                    ],
                    [
                        'service_title' => __('Real Estate', 'tanwar-associates'),
                        'service_description' => __('Complete property legal services from purchase to dispute resolution.', 'tanwar-associates'),
                    ],
                ],
                'title_field' => '{{{ service_title }}}',
            ]
        );

        $this->end_controls_section();

        // Slider Settings Section
        $this->start_controls_section(
            'section_slider_settings',
            [
                'label' => __('Slider Settings', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_responsive_control(
            'slides_to_show',
            [
                'label' => __('Slides to Show', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3,
                'tablet_default' => 2,
                'mobile_default' => 1,
                'min' => 1,
                'max' => 6,
            ]
        );

        $this->add_control(
            'slides_to_scroll',
            [
                'label' => __('Slides to Scroll', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 1,
                'min' => 1,
                'max' => 6,
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => __('Autoplay', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'tanwar-associates'),
                'label_off' => __('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => __('Autoplay Speed (ms)', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 3000,
                'min' => 1000,
                'max' => 10000,
                'step' => 500,
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'pause_on_hover',
            [
                'label' => __('Pause on Hover', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'tanwar-associates'),
                'label_off' => __('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'infinite_loop',
            [
                'label' => __('Infinite Loop', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'tanwar-associates'),
                'label_off' => __('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'transition_speed',
            [
                'label' => __('Transition Speed (ms)', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => 500,
                'min' => 100,
                'max' => 2000,
                'step' => 100,
            ]
        );

        $this->end_controls_section();

        // Navigation Section
        $this->start_controls_section(
            'section_navigation',
            [
                'label' => __('Navigation', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'show_arrows',
            [
                'label' => __('Show Arrows', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'tanwar-associates'),
                'label_off' => __('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'arrows_position',
            [
                'label' => __('Arrows Position', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'sides',
                'options' => [
                    'sides' => __('Sides', 'tanwar-associates'),
                    'top-right' => __('Top Right', 'tanwar-associates'),
                    'bottom-center' => __('Bottom Center', 'tanwar-associates'),
                ],
                'condition' => [
                    'show_arrows' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'show_dots',
            [
                'label' => __('Show Dots', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'tanwar-associates'),
                'label_off' => __('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'show_progress_bar',
            [
                'label' => __('Show Progress Bar', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Yes', 'tanwar-associates'),
                'label_off' => __('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => '',
                'condition' => [
                    'autoplay' => 'yes',
                ],
            ]
        );

        $this->end_controls_section();

        // Section Style
        $this->start_controls_section(
            'section_style_section',
            [
                'label' => __('Section', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'section_background',
            [
                'label' => __('Background Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .services-slider-section' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'section_padding',
            [
                'label' => __('Padding', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .services-slider-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '80',
                    'right' => '0',
                    'bottom' => '80',
                    'left' => '0',
                    'unit' => 'px',
                ],
            ]
        );

        $this->end_controls_section();

        // Title Style
        $this->start_controls_section(
            'section_style_title',
            [
                'label' => __('Title', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => __('Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .section-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'title_typography',
                'selector' => '{{WRAPPER}} .section-title',
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => __('Margin', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .section-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => __('Subtitle Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'separator' => 'before',
                'selectors' => [
                    '{{WRAPPER}} .section-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typography',
                'selector' => '{{WRAPPER}} .section-subtitle',
            ]
        );

        $this->end_controls_section();

        // Card Style
        $this->start_controls_section(
            'section_style_card',
            [
                'label' => __('Service Card', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_style',
            [
                'label' => __('Card Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'default',
                'options' => [
                    'default' => __('Default', 'tanwar-associates'),
                    'overlay' => __('Image Overlay', 'tanwar-associates'),
                    'minimal' => __('Minimal', 'tanwar-associates'),
                    'bordered' => __('Bordered', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'card_background',
            [
                'label' => __('Background Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-slide' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'card_hover_background',
            [
                'label' => __('Hover Background', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-slide:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_padding',
            [
                'label' => __('Padding', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em'],
                'selectors' => [
                    '{{WRAPPER}} .service-slide' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default' => [
                    'top' => '30',
                    'right' => '25',
                    'bottom' => '30',
                    'left' => '25',
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_responsive_control(
            'card_height',
            [
                'label' => __('Card Height', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 200,
                        'max' => 600,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .service-slide' => 'min-height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Border::get_type(),
            [
                'name' => 'card_border',
                'selector' => '{{WRAPPER}} .service-slide',
            ]
        );

        $this->add_responsive_control(
            'card_border_radius',
            [
                'label' => __('Border Radius', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .service-slide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_box_shadow',
                'selector' => '{{WRAPPER}} .service-slide',
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'card_hover_box_shadow',
                'label' => __('Hover Box Shadow', 'tanwar-associates'),
                'selector' => '{{WRAPPER}} .service-slide:hover',
            ]
        );

        $this->end_controls_section();

        // Icon Style
        $this->start_controls_section(
            'section_style_icon',
            [
                'label' => __('Icon', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => __('Icon Size', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 48,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .service-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .service-icon svg' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_color',
            [
                'label' => __('Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .service-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_hover_color',
            [
                'label' => __('Hover Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-slide:hover .service-icon i' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .service-slide:hover .service-icon svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_background',
            [
                'label' => __('Background Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_padding',
            [
                'label' => __('Padding', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .service-icon' => 'padding: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_border_radius',
            [
                'label' => __('Border Radius', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 100,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .service-icon' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_margin',
            [
                'label' => __('Margin Bottom', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'size' => 20,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .service-icon' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Service Title Style
        $this->start_controls_section(
            'section_style_service_title',
            [
                'label' => __('Service Title', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'service_title_color',
            [
                'label' => __('Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'service_title_hover_color',
            [
                'label' => __('Hover Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-slide:hover .service-title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'service_title_typography',
                'selector' => '{{WRAPPER}} .service-title',
            ]
        );

        $this->add_responsive_control(
            'service_title_margin',
            [
                'label' => __('Margin Bottom', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'default' => [
                    'size' => 15,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .service-title' => 'margin-bottom: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

        // Description Style
        $this->start_controls_section(
            'section_style_description',
            [
                'label' => __('Description', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'description_color',
            [
                'label' => __('Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .service-description' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'description_typography',
                'selector' => '{{WRAPPER}} .service-description',
            ]
        );

        $this->end_controls_section();

        // Navigation Style
        $this->start_controls_section(
            'section_style_navigation',
            [
                'label' => __('Navigation', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'heading_arrows',
            [
                'label' => __('Arrows', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::HEADING,
            ]
        );

        $this->add_responsive_control(
            'arrow_size',
            [
                'label' => __('Arrow Size', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 20,
                        'max' => 80,
                    ],
                ],
                'default' => [
                    'size' => 48,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider-arrow' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_color',
            [
                'label' => __('Arrow Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-arrow' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_background',
            [
                'label' => __('Arrow Background', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-arrow' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_hover_color',
            [
                'label' => __('Hover Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-arrow:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'arrow_hover_background',
            [
                'label' => __('Hover Background', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-arrow:hover' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'arrow_border_radius',
            [
                'label' => __('Border Radius', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px', '%'],
                'range' => [
                    'px' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                    '%' => [
                        'min' => 0,
                        'max' => 50,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider-arrow' => 'border-radius: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'heading_dots',
            [
                'label' => __('Dots', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_responsive_control(
            'dot_size',
            [
                'label' => __('Dot Size', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 6,
                        'max' => 20,
                    ],
                ],
                'default' => [
                    'size' => 10,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider-dot' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'dot_color',
            [
                'label' => __('Dot Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-dot' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dot_active_color',
            [
                'label' => __('Active Dot Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-dot.active' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'dots_spacing',
            [
                'label' => __('Dots Spacing', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 5,
                        'max' => 30,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider-dot' => 'margin: 0 {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'heading_progress',
            [
                'label' => __('Progress Bar', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'progress_background',
            [
                'label' => __('Track Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-progress' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'progress_fill_color',
            [
                'label' => __('Fill Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .slider-progress-fill' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'progress_height',
            [
                'label' => __('Height', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SLIDER,
                'size_units' => ['px'],
                'range' => [
                    'px' => [
                        'min' => 2,
                        'max' => 10,
                    ],
                ],
                'default' => [
                    'size' => 3,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .slider-progress' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $widget_id = $this->get_id();
        
        $slider_settings = [
            'slidesToShow' => !empty($settings['slides_to_show']) ? intval($settings['slides_to_show']) : 3,
            'slidesToShowTablet' => !empty($settings['slides_to_show_tablet']) ? intval($settings['slides_to_show_tablet']) : 2,
            'slidesToShowMobile' => !empty($settings['slides_to_show_mobile']) ? intval($settings['slides_to_show_mobile']) : 1,
            'slidesToScroll' => !empty($settings['slides_to_scroll']) ? intval($settings['slides_to_scroll']) : 1,
            'autoplay' => $settings['autoplay'] === 'yes',
            'autoplaySpeed' => !empty($settings['autoplay_speed']) ? intval($settings['autoplay_speed']) : 3000,
            'pauseOnHover' => $settings['pause_on_hover'] === 'yes',
            'infinite' => $settings['infinite_loop'] === 'yes',
            'speed' => !empty($settings['transition_speed']) ? intval($settings['transition_speed']) : 500,
        ];

        $arrows_class = 'arrows-' . $settings['arrows_position'];
        $card_style_class = 'card-style-' . $settings['card_style'];
        ?>
        <section class="services-slider-section">
            <div class="container">
                <?php if (!empty($settings['section_title']) || !empty($settings['section_subtitle'])) : ?>
                    <div class="section-header">
                        <?php if (!empty($settings['section_title'])) : ?>
                            <h2 class="section-title"><?php echo esc_html($settings['section_title']); ?></h2>
                        <?php endif; ?>
                        <?php if (!empty($settings['section_subtitle'])) : ?>
                            <p class="section-subtitle"><?php echo esc_html($settings['section_subtitle']); ?></p>
                        <?php endif; ?>

                        <?php if ($settings['show_arrows'] === 'yes' && $settings['arrows_position'] === 'top-right') : ?>
                            <div class="slider-arrows-header">
                                <button class="slider-arrow slider-prev" aria-label="<?php esc_attr_e('Previous', 'tanwar-associates'); ?>">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="15 18 9 12 15 6"></polyline>
                                    </svg>
                                </button>
                                <button class="slider-arrow slider-next" aria-label="<?php esc_attr_e('Next', 'tanwar-associates'); ?>">
                                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="9 18 15 12 9 6"></polyline>
                                    </svg>
                                </button>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <div class="services-slider-wrapper <?php echo esc_attr($arrows_class); ?> <?php echo esc_attr($card_style_class); ?>">
                    <?php if ($settings['show_arrows'] === 'yes' && $settings['arrows_position'] === 'sides') : ?>
                        <button class="slider-arrow slider-prev slider-prev-sides" aria-label="<?php esc_attr_e('Previous', 'tanwar-associates'); ?>">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="15 18 9 12 15 6"></polyline>
                            </svg>
                        </button>
                    <?php endif; ?>

                    <div class="services-slider" data-settings='<?php echo wp_json_encode($slider_settings); ?>' data-widget-id="<?php echo esc_attr($widget_id); ?>">
                        <div class="slider-track">
                            <?php foreach ($settings['services_list'] as $index => $service) : 
                                $link_url = !empty($service['service_link']['url']) ? $service['service_link']['url'] : '#';
                                $link_target = !empty($service['service_link']['is_external']) ? '_blank' : '_self';
                                $link_nofollow = !empty($service['service_link']['nofollow']) ? 'nofollow' : '';
                                $has_image = !empty($service['service_image']['url']) && $settings['card_style'] === 'overlay';
                            ?>
                                <div class="slide">
                                    <a href="<?php echo esc_url($link_url); ?>" 
                                       target="<?php echo esc_attr($link_target); ?>" 
                                       rel="<?php echo esc_attr($link_nofollow); ?>"
                                       class="service-slide <?php echo $has_image ? 'has-image' : ''; ?>">
                                        
                                        <?php if ($has_image) : ?>
                                            <div class="service-image-bg" style="background-image: url('<?php echo esc_url($service['service_image']['url']); ?>');"></div>
                                            <div class="service-overlay"></div>
                                        <?php endif; ?>

                                        <div class="service-content">
                                            <?php if (!empty($service['service_icon']['value'])) : ?>
                                                <div class="service-icon">
                                                    <?php \Elementor\Icons_Manager::render_icon($service['service_icon'], ['aria-hidden' => 'true']); ?>
                                                </div>
                                            <?php endif; ?>

                                            <?php if (!empty($service['service_title'])) : ?>
                                                <h3 class="service-title"><?php echo esc_html($service['service_title']); ?></h3>
                                            <?php endif; ?>

                                            <?php if (!empty($service['service_description'])) : ?>
                                                <p class="service-description"><?php echo esc_html($service['service_description']); ?></p>
                                            <?php endif; ?>

                                            <span class="service-arrow">
                                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                                    <polyline points="12 5 19 12 12 19"></polyline>
                                                </svg>
                                            </span>
                                        </div>
                                    </a>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <?php if ($settings['show_arrows'] === 'yes' && $settings['arrows_position'] === 'sides') : ?>
                        <button class="slider-arrow slider-next slider-next-sides" aria-label="<?php esc_attr_e('Next', 'tanwar-associates'); ?>">
                            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <polyline points="9 18 15 12 9 6"></polyline>
                            </svg>
                        </button>
                    <?php endif; ?>
                </div>

                <?php if ($settings['show_progress_bar'] === 'yes' && $settings['autoplay'] === 'yes') : ?>
                    <div class="slider-progress">
                        <div class="slider-progress-fill"></div>
                    </div>
                <?php endif; ?>

                <div class="slider-navigation">
                    <?php if ($settings['show_dots'] === 'yes') : ?>
                        <div class="slider-dots">
                            <?php 
                            $total_slides = count($settings['services_list']);
                            $slides_to_show = !empty($settings['slides_to_show']) ? intval($settings['slides_to_show']) : 3;
                            $dot_count = max(1, ceil($total_slides / $slides_to_show));
                            for ($i = 0; $i < $dot_count; $i++) : ?>
                                <button class="slider-dot <?php echo $i === 0 ? 'active' : ''; ?>" 
                                        data-index="<?php echo esc_attr($i); ?>"
                                        aria-label="<?php echo esc_attr(sprintf(__('Go to slide %d', 'tanwar-associates'), $i + 1)); ?>">
                                </button>
                            <?php endfor; ?>
                        </div>
                    <?php endif; ?>

                    <?php if ($settings['show_arrows'] === 'yes' && $settings['arrows_position'] === 'bottom-center') : ?>
                        <div class="slider-arrows-bottom">
                            <button class="slider-arrow slider-prev" aria-label="<?php esc_attr_e('Previous', 'tanwar-associates'); ?>">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="15 18 9 12 15 6"></polyline>
                                </svg>
                            </button>
                            <button class="slider-arrow slider-next" aria-label="<?php esc_attr_e('Next', 'tanwar-associates'); ?>">
                                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                            </button>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <style>
            .services-slider-section {
                overflow: hidden;
            }

            .services-slider-section .container {
                max-width: 1200px;
                margin: 0 auto;
                padding: 0 15px;
            }

            .services-slider-section .section-header {
                text-align: center;
                margin-bottom: 50px;
                position: relative;
            }

            .services-slider-section .section-title {
                font-size: 36px;
                font-weight: 700;
                margin-bottom: 15px;
            }

            .services-slider-section .section-subtitle {
                font-size: 18px;
                opacity: 0.8;
                max-width: 600px;
                margin: 0 auto;
            }

            .slider-arrows-header {
                position: absolute;
                right: 0;
                top: 50%;
                transform: translateY(-50%);
                display: flex;
                gap: 10px;
            }

            .services-slider-wrapper {
                position: relative;
            }

            .services-slider-wrapper.arrows-sides {
                padding: 0 60px;
            }

            .services-slider {
                overflow: hidden;
            }

            .slider-track {
                display: flex;
                transition: transform 0.5s ease;
            }

            .slide {
                flex: 0 0 auto;
                padding: 0 15px;
                box-sizing: border-box;
            }

            .service-slide {
                display: flex;
                flex-direction: column;
                height: 100%;
                text-decoration: none;
                color: inherit;
                background: #fff;
                border-radius: 12px;
                overflow: hidden;
                transition: all 0.3s ease;
                position: relative;
            }

            .service-slide:hover {
                transform: translateY(-5px);
            }

            .service-slide.has-image {
                color: #fff;
            }

            .service-image-bg {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-size: cover;
                background-position: center;
                transition: transform 0.5s ease;
            }

            .service-slide:hover .service-image-bg {
                transform: scale(1.1);
            }

            .service-overlay {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: linear-gradient(to bottom, rgba(0,0,0,0.3), rgba(0,0,0,0.7));
            }

            .service-content {
                position: relative;
                z-index: 1;
                display: flex;
                flex-direction: column;
                height: 100%;
            }

            .service-icon {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                transition: all 0.3s ease;
            }

            .service-title {
                font-size: 22px;
                font-weight: 600;
                transition: color 0.3s ease;
            }

            .service-description {
                font-size: 15px;
                line-height: 1.6;
                opacity: 0.85;
                flex-grow: 1;
            }

            .service-arrow {
                display: inline-flex;
                align-items: center;
                margin-top: auto;
                opacity: 0;
                transform: translateX(-10px);
                transition: all 0.3s ease;
            }

            .service-slide:hover .service-arrow {
                opacity: 1;
                transform: translateX(0);
            }

            /* Card Styles */
            .card-style-minimal .service-slide {
                background: transparent;
                border: none;
                box-shadow: none;
            }

            .card-style-bordered .service-slide {
                background: transparent;
                border: 2px solid #e5e5e5;
            }

            .card-style-bordered .service-slide:hover {
                border-color: currentColor;
            }

            /* Navigation */
            .slider-arrow {
                display: inline-flex;
                align-items: center;
                justify-content: center;
                width: 48px;
                height: 48px;
                border: none;
                background: #f5f5f5;
                color: #333;
                border-radius: 50%;
                cursor: pointer;
                transition: all 0.3s ease;
            }

            .slider-arrow:hover {
                background: #333;
                color: #fff;
            }

            .slider-prev-sides,
            .slider-next-sides {
                position: absolute;
                top: 50%;
                transform: translateY(-50%);
                z-index: 10;
            }

            .slider-prev-sides {
                left: 0;
            }

            .slider-next-sides {
                right: 0;
            }

            .slider-navigation {
                display: flex;
                align-items: center;
                justify-content: center;
                margin-top: 40px;
                gap: 30px;
            }

            .slider-dots {
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
            }

            .slider-dot {
                width: 10px;
                height: 10px;
                border-radius: 50%;
                border: none;
                background: #ddd;
                cursor: pointer;
                padding: 0;
                transition: all 0.3s ease;
            }

            .slider-dot.active {
                background: #333;
                transform: scale(1.2);
            }

            .slider-dot:hover {
                background: #999;
            }

            .slider-arrows-bottom {
                display: flex;
                gap: 10px;
            }

            .slider-progress {
                width: 100%;
                height: 3px;
                background: #e5e5e5;
                margin-top: 30px;
                border-radius: 2px;
                overflow: hidden;
            }

            .slider-progress-fill {
                height: 100%;
                background: #333;
                width: 0;
                transition: width linear;
            }

            /* Responsive */
            @media (max-width: 1024px) {
                .services-slider-wrapper.arrows-sides {
                    padding: 0 50px;
                }

                .slider-arrows-header {
                    position: static;
                    transform: none;
                    justify-content: center;
                    margin-top: 20px;
                }
            }

            @media (max-width: 768px) {
                .services-slider-section .section-title {
                    font-size: 28px;
                }

                .services-slider-wrapper.arrows-sides {
                    padding: 0;
                }

                .slider-prev-sides,
                .slider-next-sides {
                    display: none;
                }

                .slider-arrow {
                    width: 40px;
                    height: 40px;
                }
            }
        </style>
        <?php
    }
}
