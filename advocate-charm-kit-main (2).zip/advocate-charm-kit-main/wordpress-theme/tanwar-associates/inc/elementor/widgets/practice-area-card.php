<?php
/**
 * Elementor Practice Area Card Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Practice_Area_Card_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_practice_area_card';
    }

    public function get_title() {
        return esc_html__('Practice Area Card', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-info-box';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['practice', 'area', 'service', 'card', 'tanwar'];
    }

    protected function register_controls() {
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-balance-scale',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Civil Litigation', 'tanwar-associates'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'description',
            [
                'label' => esc_html__('Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Comprehensive civil litigation services including property disputes and contract enforcement.', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'services',
            [
                'label' => esc_html__('Services (one per line)', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => "Property Disputes\nContract Enforcement\nRecovery Suits\nInjunctions",
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => esc_html__('Button Text', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Consult Now', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'button_link',
            [
                'label' => esc_html__('Button Link', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::URL,
                'default' => [
                    'url' => '/contact/',
                ],
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'card_style',
            [
                'label' => esc_html__('Card Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'gradient',
                'options' => [
                    'gradient' => esc_html__('Gradient Left', 'tanwar-associates'),
                    'simple' => esc_html__('Simple Card', 'tanwar-associates'),
                    'bordered' => esc_html__('Bordered', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'primary_color',
            [
                'label' => esc_html__('Primary Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#0a1a2f',
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => esc_html__('Accent Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#c9a44a',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $services = !empty($settings['services']) ? array_filter(explode("\n", $settings['services'])) : [];
        ?>
        <div class="tanwar-single-practice-card <?php echo esc_attr($settings['card_style']); ?>" style="--primary: <?php echo esc_attr($settings['primary_color']); ?>; --accent: <?php echo esc_attr($settings['accent_color']); ?>;">
            <?php if ($settings['card_style'] === 'gradient') : ?>
            <div class="practice-card-gradient">
                <div class="practice-card-icon">
                    <?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']); ?>
                </div>
                <h3><?php echo esc_html($settings['title']); ?></h3>
                <p><?php echo esc_html($settings['description']); ?></p>
            </div>
            <div class="practice-card-content">
                <h4><?php esc_html_e('Services We Offer', 'tanwar-associates'); ?></h4>
                <?php if (!empty($services)) : ?>
                <ul class="practice-services-list">
                    <?php foreach ($services as $service) : ?>
                    <li>
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <polyline points="20 6 9 17 4 12"></polyline>
                        </svg>
                        <span><?php echo esc_html(trim($service)); ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <?php endif; ?>
                
                <?php if (!empty($settings['button_text'])) : ?>
                <a href="<?php echo esc_url($settings['button_link']['url']); ?>" class="btn btn-outline">
                    <?php echo esc_html($settings['button_text']); ?>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
                <?php endif; ?>
            </div>
            <?php else : ?>
            <div class="practice-card-icon">
                <?php \Elementor\Icons_Manager::render_icon($settings['icon'], ['aria-hidden' => 'true']); ?>
            </div>
            <h3><?php echo esc_html($settings['title']); ?></h3>
            <p><?php echo esc_html($settings['description']); ?></p>
            <?php if (!empty($services)) : ?>
            <ul class="practice-services-list">
                <?php foreach ($services as $service) : ?>
                <li>
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <polyline points="20 6 9 17 4 12"></polyline>
                    </svg>
                    <span><?php echo esc_html(trim($service)); ?></span>
                </li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
            <?php if (!empty($settings['button_text'])) : ?>
            <a href="<?php echo esc_url($settings['button_link']['url']); ?>" class="btn btn-outline">
                <?php echo esc_html($settings['button_text']); ?>
            </a>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php
    }
}