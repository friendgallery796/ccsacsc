<?php
/**
 * Elementor Contact Form Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Contact_Form_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_contact_form';
    }

    public function get_title() {
        return esc_html__('Contact Form', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-form-horizontal';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['contact', 'form', 'email', 'consultation', 'tanwar'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'form_title',
            [
                'label' => esc_html__('Form Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Request Free Consultation', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'form_description',
            [
                'label' => esc_html__('Form Description', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Fill out the form below and our legal experts will get back to you within 24 hours.', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'show_case_type',
            [
                'label' => esc_html__('Show Case Type Field', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'tanwar-associates'),
                'label_off' => esc_html__('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'case_types',
            [
                'label' => esc_html__('Case Types (one per line)', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => "Civil Litigation\nCriminal Law\nFamily Law\nProperty Law\nCorporate Law\nOther",
                'condition' => [
                    'show_case_type' => 'yes',
                ],
            ]
        );

        $this->add_control(
            'button_text',
            [
                'label' => esc_html__('Button Text', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Submit Request', 'tanwar-associates'),
            ]
        );

        $this->add_control(
            'success_message',
            [
                'label' => esc_html__('Success Message', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Thank you! We will contact you shortly.', 'tanwar-associates'),
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'form_style',
            [
                'label' => esc_html__('Form Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'card',
                'options' => [
                    'card' => esc_html__('Card Style', 'tanwar-associates'),
                    'inline' => esc_html__('Inline Style', 'tanwar-associates'),
                    'minimal' => esc_html__('Minimal', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'background_color',
            [
                'label' => esc_html__('Background Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#ffffff',
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => esc_html__('Accent Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#c9a44a',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        $case_types = !empty($settings['case_types']) ? array_filter(explode("\n", $settings['case_types'])) : [];
        $form_id = 'tanwar-contact-form-' . $this->get_id();
        ?>
        <div class="tanwar-contact-form-widget <?php echo esc_attr($settings['form_style']); ?>" 
             style="--bg-color: <?php echo esc_attr($settings['background_color']); ?>; --accent: <?php echo esc_attr($settings['accent_color']); ?>;">
            
            <?php if (!empty($settings['form_title']) || !empty($settings['form_description'])) : ?>
            <div class="form-header">
                <?php if (!empty($settings['form_title'])) : ?>
                    <h3 class="form-title"><?php echo esc_html($settings['form_title']); ?></h3>
                <?php endif; ?>
                <?php if (!empty($settings['form_description'])) : ?>
                    <p class="form-description"><?php echo esc_html($settings['form_description']); ?></p>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <form id="<?php echo esc_attr($form_id); ?>" class="tanwar-contact-form" method="post">
                <div class="form-row">
                    <div class="form-group">
                        <label for="<?php echo esc_attr($form_id); ?>-name"><?php esc_html_e('Full Name', 'tanwar-associates'); ?> <span class="required">*</span></label>
                        <input type="text" id="<?php echo esc_attr($form_id); ?>-name" name="name" required placeholder="<?php esc_attr_e('Enter your full name', 'tanwar-associates'); ?>">
                    </div>
                    <div class="form-group">
                        <label for="<?php echo esc_attr($form_id); ?>-email"><?php esc_html_e('Email Address', 'tanwar-associates'); ?> <span class="required">*</span></label>
                        <input type="email" id="<?php echo esc_attr($form_id); ?>-email" name="email" required placeholder="<?php esc_attr_e('Enter your email', 'tanwar-associates'); ?>">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="<?php echo esc_attr($form_id); ?>-phone"><?php esc_html_e('Phone Number', 'tanwar-associates'); ?> <span class="required">*</span></label>
                        <input type="tel" id="<?php echo esc_attr($form_id); ?>-phone" name="phone" required placeholder="<?php esc_attr_e('+91 98290 12345', 'tanwar-associates'); ?>">
                    </div>
                    <?php if ($settings['show_case_type'] === 'yes' && !empty($case_types)) : ?>
                    <div class="form-group">
                        <label for="<?php echo esc_attr($form_id); ?>-case-type"><?php esc_html_e('Case Type', 'tanwar-associates'); ?></label>
                        <select id="<?php echo esc_attr($form_id); ?>-case-type" name="case_type">
                            <option value=""><?php esc_html_e('Select case type', 'tanwar-associates'); ?></option>
                            <?php foreach ($case_types as $type) : ?>
                            <option value="<?php echo esc_attr(trim($type)); ?>"><?php echo esc_html(trim($type)); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="<?php echo esc_attr($form_id); ?>-message"><?php esc_html_e('Your Message', 'tanwar-associates'); ?> <span class="required">*</span></label>
                    <textarea id="<?php echo esc_attr($form_id); ?>-message" name="message" rows="5" required placeholder="<?php esc_attr_e('Briefly describe your legal matter...', 'tanwar-associates'); ?>"></textarea>
                </div>

                <input type="hidden" name="action" value="tanwar_contact_form">
                <input type="hidden" name="nonce" value="<?php echo esc_attr(wp_create_nonce('tanwar_nonce')); ?>">

                <div class="form-submit">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <?php echo esc_html($settings['button_text']); ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </button>
                </div>

                <div class="form-message success" style="display: none;">
                    <?php echo esc_html($settings['success_message']); ?>
                </div>
                <div class="form-message error" style="display: none;"></div>
            </form>
        </div>
        <?php
    }
}