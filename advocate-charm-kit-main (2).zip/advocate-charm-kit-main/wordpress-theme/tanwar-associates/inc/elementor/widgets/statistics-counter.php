<?php
/**
 * Elementor Statistics Counter Widget
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

class Tanwar_Statistics_Counter_Widget extends \Elementor\Widget_Base {

    public function get_name() {
        return 'tanwar_statistics_counter';
    }

    public function get_title() {
        return esc_html__('Statistics Counter', 'tanwar-associates');
    }

    public function get_icon() {
        return 'eicon-counter';
    }

    public function get_categories() {
        return ['tanwar-associates'];
    }

    public function get_keywords() {
        return ['statistics', 'counter', 'numbers', 'facts', 'tanwar'];
    }

    public function get_script_depends() {
        return ['tanwar-elementor-widgets'];
    }

    protected function register_controls() {
        // Content Section
        $this->start_controls_section(
            'content_section',
            [
                'label' => esc_html__('Content', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->add_control(
            'number',
            [
                'label' => esc_html__('Number', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '5000',
            ]
        );

        $repeater->add_control(
            'suffix',
            [
                'label' => esc_html__('Suffix', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => '+',
            ]
        );

        $repeater->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Cases Handled', 'tanwar-associates'),
            ]
        );

        $repeater->add_control(
            'icon',
            [
                'label' => esc_html__('Icon', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::ICONS,
                'default' => [
                    'value' => 'fas fa-gavel',
                    'library' => 'fa-solid',
                ],
            ]
        );

        $this->add_control(
            'statistics',
            [
                'label' => esc_html__('Statistics', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'number' => '5000',
                        'suffix' => '+',
                        'title' => esc_html__('Cases Handled', 'tanwar-associates'),
                    ],
                    [
                        'number' => '25',
                        'suffix' => '+',
                        'title' => esc_html__('Years Experience', 'tanwar-associates'),
                    ],
                    [
                        'number' => '98',
                        'suffix' => '%',
                        'title' => esc_html__('Success Rate', 'tanwar-associates'),
                    ],
                    [
                        'number' => '50',
                        'suffix' => '+',
                        'title' => esc_html__('Legal Experts', 'tanwar-associates'),
                    ],
                ],
                'title_field' => '{{{ title }}}',
            ]
        );

        $this->add_control(
            'columns',
            [
                'label' => esc_html__('Columns', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => '4',
                'options' => [
                    '2' => esc_html__('2 Columns', 'tanwar-associates'),
                    '3' => esc_html__('3 Columns', 'tanwar-associates'),
                    '4' => esc_html__('4 Columns', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'animate_numbers',
            [
                'label' => esc_html__('Animate Numbers', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'tanwar-associates'),
                'label_off' => esc_html__('No', 'tanwar-associates'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->end_controls_section();

        // Style Section
        $this->start_controls_section(
            'style_section',
            [
                'label' => esc_html__('Style', 'tanwar-associates'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'layout_style',
            [
                'label' => esc_html__('Layout Style', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'dark',
                'options' => [
                    'dark' => esc_html__('Dark Background', 'tanwar-associates'),
                    'light' => esc_html__('Light Background', 'tanwar-associates'),
                    'gradient' => esc_html__('Gradient Background', 'tanwar-associates'),
                ],
            ]
        );

        $this->add_control(
            'accent_color',
            [
                'label' => esc_html__('Accent Color', 'tanwar-associates'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'default' => '#c9a44a',
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {
        $settings = $this->get_settings_for_display();
        ?>
        <section class="tanwar-statistics-section <?php echo esc_attr($settings['layout_style']); ?>" style="--accent: <?php echo esc_attr($settings['accent_color']); ?>;">
            <div class="container">
                <div class="tanwar-statistics-grid columns-<?php echo esc_attr($settings['columns']); ?>">
                    <?php foreach ($settings['statistics'] as $stat) : ?>
                    <div class="statistic-item" <?php echo $settings['animate_numbers'] === 'yes' ? 'data-animate="true"' : ''; ?>>
                        <?php if (!empty($stat['icon']['value'])) : ?>
                        <div class="statistic-icon">
                            <?php \Elementor\Icons_Manager::render_icon($stat['icon'], ['aria-hidden' => 'true']); ?>
                        </div>
                        <?php endif; ?>
                        <div class="statistic-number">
                            <span class="counter" data-target="<?php echo esc_attr(preg_replace('/[^0-9]/', '', $stat['number'])); ?>">
                                <?php echo esc_html($stat['number']); ?>
                            </span>
                            <?php if (!empty($stat['suffix'])) : ?>
                            <span class="suffix"><?php echo esc_html($stat['suffix']); ?></span>
                            <?php endif; ?>
                        </div>
                        <h4 class="statistic-title"><?php echo esc_html($stat['title']); ?></h4>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
        <?php
    }
}