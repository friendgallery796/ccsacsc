<?php
/**
 * Tanwar Associates Elementor Integration
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main Elementor Integration Class
 */
final class Tanwar_Elementor {

    /**
     * Plugin Version
     */
    const VERSION = '1.0.0';

    /**
     * Minimum Elementor Version
     */
    const MINIMUM_ELEMENTOR_VERSION = '3.0.0';

    /**
     * Minimum PHP Version
     */
    const MINIMUM_PHP_VERSION = '7.4';

    /**
     * Instance
     */
    private static $_instance = null;

    /**
     * Instance
     */
    public static function instance() {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', [$this, 'i18n']);
        add_action('plugins_loaded', [$this, 'init']);
    }

    /**
     * Load Textdomain
     */
    public function i18n() {
        load_plugin_textdomain('tanwar-associates');
    }

    /**
     * Initialize
     */
    public function init() {
        // Check if Elementor installed and activated
        if (!did_action('elementor/loaded')) {
            return;
        }

        // Check for required Elementor version
        if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_elementor_version']);
            return;
        }

        // Check for required PHP version
        if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
            add_action('admin_notices', [$this, 'admin_notice_minimum_php_version']);
            return;
        }

        // Register widgets
        add_action('elementor/widgets/register', [$this, 'register_widgets']);

        // Register widget styles
        add_action('elementor/frontend/after_enqueue_styles', [$this, 'widget_styles']);

        // Register widget scripts
        add_action('elementor/frontend/after_register_scripts', [$this, 'widget_scripts']);
    }

    /**
     * Admin notice for minimum Elementor version
     */
    public function admin_notice_minimum_elementor_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);

        $message = sprintf(
            esc_html__('Tanwar Associates theme requires Elementor version %1$s or greater.', 'tanwar-associates'),
            self::MINIMUM_ELEMENTOR_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    /**
     * Admin notice for minimum PHP version
     */
    public function admin_notice_minimum_php_version() {
        if (isset($_GET['activate'])) unset($_GET['activate']);

        $message = sprintf(
            esc_html__('Tanwar Associates theme requires PHP version %1$s or greater.', 'tanwar-associates'),
            self::MINIMUM_PHP_VERSION
        );

        printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
    }

    /**
     * Register Widgets
     */
    public function register_widgets($widgets_manager) {
        // Include widget files
        require_once TANWAR_DIR . '/inc/elementor/widgets/hero-section.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/practice-areas-grid.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/practice-area-card.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/team-grid.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/team-member-card.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/testimonials-carousel.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/contact-form.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/statistics-counter.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/cta-section.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/blog-posts-grid.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/services-slider.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/clients-logo-carousel.php';
        require_once TANWAR_DIR . '/inc/elementor/widgets/pricing-table.php';

        // Register widgets
        $widgets_manager->register(new \Tanwar_Hero_Section_Widget());
        $widgets_manager->register(new \Tanwar_Practice_Areas_Grid_Widget());
        $widgets_manager->register(new \Tanwar_Practice_Area_Card_Widget());
        $widgets_manager->register(new \Tanwar_Team_Grid_Widget());
        $widgets_manager->register(new \Tanwar_Team_Member_Card_Widget());
        $widgets_manager->register(new \Tanwar_Testimonials_Carousel_Widget());
        $widgets_manager->register(new \Tanwar_Contact_Form_Widget());
        $widgets_manager->register(new \Tanwar_Statistics_Counter_Widget());
        $widgets_manager->register(new \Tanwar_CTA_Section_Widget());
        $widgets_manager->register(new \Tanwar_Blog_Posts_Grid_Widget());
        $widgets_manager->register(new \Tanwar_Services_Slider_Widget());
        $widgets_manager->register(new \Tanwar_Clients_Logo_Carousel_Widget());
        $widgets_manager->register(new \Tanwar_Pricing_Table_Widget());
    }

    /**
     * Widget Styles
     */
    public function widget_styles() {
        wp_enqueue_style(
            'tanwar-elementor-widgets',
            TANWAR_URI . '/css/elementor-widgets.css',
            [],
            self::VERSION
        );
    }

    /**
     * Widget Scripts
     */
    public function widget_scripts() {
        wp_register_script(
            'tanwar-elementor-widgets',
            TANWAR_URI . '/js/elementor-widgets.js',
            ['jquery'],
            self::VERSION,
            true
        );
    }
}

// Initialize
Tanwar_Elementor::instance();