<?php
/**
 * Custom Post Types for Tanwar & Associates Theme
 *
 * @package Tanwar_Associates
 */

if (!defined('ABSPATH')) exit;

// Register Attorney CPT
function tanwar_register_attorney_cpt() {
    register_post_type('attorney', array(
        'labels' => array(
            'name' => 'Attorneys',
            'singular_name' => 'Attorney',
            'add_new_item' => 'Add New Attorney',
            'edit_item' => 'Edit Attorney',
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'team'),
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'menu_icon' => 'dashicons-businessman',
        'show_in_rest' => true,
    ));
}
add_action('init', 'tanwar_register_attorney_cpt');

// Register Testimonial CPT
function tanwar_register_testimonial_cpt() {
    register_post_type('testimonial', array(
        'labels' => array(
            'name' => 'Testimonials',
            'singular_name' => 'Testimonial',
        ),
        'public' => true,
        'supports' => array('title', 'editor', 'thumbnail'),
        'menu_icon' => 'dashicons-format-quote',
    ));
}
add_action('init', 'tanwar_register_testimonial_cpt');

// Register Practice Area CPT
function tanwar_register_practice_area_cpt() {
    register_post_type('practice_area', array(
        'labels' => array(
            'name' => 'Practice Areas',
            'singular_name' => 'Practice Area',
        ),
        'public' => true,
        'has_archive' => true,
        'rewrite' => array('slug' => 'practice-areas'),
        'supports' => array('title', 'editor', 'thumbnail', 'excerpt'),
        'menu_icon' => 'dashicons-portfolio',
    ));
}
add_action('init', 'tanwar_register_practice_area_cpt');
