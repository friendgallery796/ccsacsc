<?php
/**
 * The main template file
 * Fully Elementor Editable
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if Elementor Theme Builder handles this
if (function_exists('elementor_theme_do_location') && elementor_theme_do_location('archive')) {
    // Elementor Theme Builder archive template
} else {
    // Default theme content
?>
<div class="page-hero">
    <div class="container">
        <div class="page-hero-content">
            <nav class="breadcrumbs" aria-label="Breadcrumb">
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'tanwar-associates'); ?></a>
                <span>/</span>
                <span><?php esc_html_e('Blog', 'tanwar-associates'); ?></span>
            </nav>
            <h1><?php esc_html_e('Legal Insights & News', 'tanwar-associates'); ?></h1>
            <p><?php esc_html_e('Stay informed with the latest legal updates, insights, and news from Tanwar & Associates.', 'tanwar-associates'); ?></p>
        </div>
    </div>
</div>

<section class="section">
    <div class="container">
        <?php if (have_posts()) : ?>
            <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
                <?php while (have_posts()) : the_post(); ?>
                    <article class="card">
                        <?php if (has_post_thumbnail()) : ?>
                            <a href="<?php the_permalink(); ?>" class="card-image">
                                <?php the_post_thumbnail('medium_large', array('class' => 'w-full')); ?>
                            </a>
                        <?php endif; ?>
                        
                        <div class="card-body">
                            <div class="mb-3" style="font-size: 0.875rem; color: var(--muted-foreground);">
                                <time datetime="<?php echo get_the_date('c'); ?>">
                                    <?php echo get_the_date(); ?>
                                </time>
                                <?php if (has_category()) : ?>
                                    <span style="margin: 0 0.5rem;">•</span>
                                    <?php the_category(', '); ?>
                                <?php endif; ?>
                            </div>
                            
                            <h3 class="card-title">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_title(); ?>
                                </a>
                            </h3>
                            
                            <p class="card-text">
                                <?php echo wp_trim_words(get_the_excerpt(), 20); ?>
                            </p>
                            
                            <a href="<?php the_permalink(); ?>" class="practice-area-link">
                                <?php esc_html_e('Read More', 'tanwar-associates'); ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                    <polyline points="12 5 19 12 12 19"></polyline>
                                </svg>
                            </a>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>

            <!-- Pagination -->
            <div class="mt-8" style="display: flex; justify-content: center;">
                <?php
                the_posts_pagination(array(
                    'mid_size'  => 2,
                    'prev_text' => '&laquo; Previous',
                    'next_text' => 'Next &raquo;',
                ));
                ?>
            </div>

        <?php else : ?>
            <div class="text-center" style="padding: 4rem 0;">
                <h2><?php esc_html_e('No posts found', 'tanwar-associates'); ?></h2>
                <p style="color: var(--muted-foreground);">
                    <?php esc_html_e('Check back soon for legal insights and updates.', 'tanwar-associates'); ?>
                </p>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php get_template_part('template-parts/contact-cta'); ?>

<?php } // End Elementor check ?>

<?php get_footer(); ?>
