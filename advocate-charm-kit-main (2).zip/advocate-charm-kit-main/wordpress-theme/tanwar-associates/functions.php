<?php
/**
 * Tanwar & Associates Theme Functions
 *
 * @package Tanwar_Associates
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Define theme constants
 */
if (!defined('TANWAR_VERSION')) {
    define('TANWAR_VERSION', '1.0.0');
}
if (!defined('TANWAR_DIR')) {
    define('TANWAR_DIR', get_template_directory());
}
if (!defined('TANWAR_URI')) {
    define('TANWAR_URI', get_template_directory_uri());
}

/**
 * Theme Setup
 */
function tanwar_theme_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 300,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('responsive-embeds');
    add_theme_support('align-wide');
    
    // Elementor theme support
    add_theme_support('elementor');
    add_theme_support('header-footer-elementor');

    // Register navigation menus
    register_nav_menus(array(
        'primary' => esc_html__('Primary Menu', 'tanwar-associates'),
        'footer'  => esc_html__('Footer Menu', 'tanwar-associates'),
    ));

    // Add image sizes
    add_image_size('attorney-thumbnail', 400, 500, true);
    add_image_size('attorney-full', 800, 1000, true);
    add_image_size('hero-image', 1920, 1080, true);
    add_image_size('practice-area-icon', 200, 200, true);
}
add_action('after_setup_theme', 'tanwar_theme_setup');

/**
 * Enqueue scripts and styles
 */
function tanwar_scripts() {
    // Google Fonts
    wp_enqueue_style(
        'tanwar-google-fonts',
        'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Source+Sans+Pro:wght@300;400;600;700&display=swap',
        array(),
        null
    );

    // Main stylesheet
    wp_enqueue_style(
        'tanwar-style',
        get_stylesheet_uri(),
        array(),
        TANWAR_VERSION
    );

    // Custom CSS
    wp_enqueue_style(
        'tanwar-custom',
        TANWAR_URI . '/css/custom.css',
        array('tanwar-style'),
        TANWAR_VERSION
    );

    // Main JavaScript
    wp_enqueue_script(
        'tanwar-main',
        TANWAR_URI . '/js/main.js',
        array('jquery'),
        TANWAR_VERSION,
        true
    );

    // Animations JavaScript
    wp_enqueue_script(
        'tanwar-animations',
        TANWAR_URI . '/js/animations.js',
        array('tanwar-main'),
        TANWAR_VERSION,
        true
    );

    // Localize script
    wp_localize_script('tanwar-main', 'tanwarData', array(
        'ajaxUrl' => admin_url('admin-ajax.php'),
        'nonce'   => wp_create_nonce('tanwar_nonce'),
        'siteUrl' => home_url('/'),
    ));
}
add_action('wp_enqueue_scripts', 'tanwar_scripts');

/**
 * Register widget areas
 */
function tanwar_widgets_init() {
    register_sidebar(array(
        'name'          => esc_html__('Footer Widget 1', 'tanwar-associates'),
        'id'            => 'footer-1',
        'description'   => esc_html__('Add widgets for footer column 1.', 'tanwar-associates'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-heading">',
        'after_title'   => '</h4>',
    ));

    register_sidebar(array(
        'name'          => esc_html__('Footer Widget 2', 'tanwar-associates'),
        'id'            => 'footer-2',
        'description'   => esc_html__('Add widgets for footer column 2.', 'tanwar-associates'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h4 class="footer-heading">',
        'after_title'   => '</h4>',
    ));
}
add_action('widgets_init', 'tanwar_widgets_init');

/**
 * Include additional files
 */
require_once TANWAR_DIR . '/inc/customizer.php';
require_once TANWAR_DIR . '/inc/custom-post-types.php';

/**
 * Include Elementor Integration
 */
if (did_action('elementor/loaded')) {
    require_once TANWAR_DIR . '/inc/elementor/class-tanwar-elementor.php';
}

/**
 * Initialize Elementor integration after plugins loaded
 */
function tanwar_init_elementor() {
    if (did_action('elementor/loaded')) {
        require_once TANWAR_DIR . '/inc/elementor/class-tanwar-elementor.php';
        \Tanwar_Elementor::instance();
    }
}
add_action('plugins_loaded', 'tanwar_init_elementor');

/**
 * Add Elementor widget category
 */
function tanwar_add_elementor_widget_categories($elements_manager) {
    $elements_manager->add_category(
        'tanwar-elements',
        [
            'title' => esc_html__('Tanwar Associates', 'tanwar-associates'),
            'icon' => 'fa fa-balance-scale',
        ]
    );
}
add_action('elementor/elements/categories_registered', 'tanwar_add_elementor_widget_categories');

/**
 * Register Elementor locations for Theme Builder
 */
function tanwar_register_elementor_locations($elementor_theme_manager) {
    $elementor_theme_manager->register_all_core_location();
}
add_action('elementor/theme/register_locations', 'tanwar_register_elementor_locations');

/**
 * Custom excerpt length
 */
function tanwar_excerpt_length($length) {
    return 25;
}
add_filter('excerpt_length', 'tanwar_excerpt_length');

/**
 * Custom excerpt more
 */
function tanwar_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'tanwar_excerpt_more');

/**
 * Add custom body classes
 */
function tanwar_body_classes($classes) {
    // Add page slug as body class
    if (is_single() || is_page() && !is_front_page()) {
        global $post;
        $classes[] = 'page-' . $post->post_name;
    }

    // Add front page class
    if (is_front_page()) {
        $classes[] = 'front-page';
    }
    
    // Add Elementor page class
    if (class_exists('\Elementor\Plugin')) {
        if (\Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID())) {
            $classes[] = 'elementor-page';
        }
    }

    return $classes;
}
add_filter('body_class', 'tanwar_body_classes');

/**
 * Custom navigation walker
 */
class Tanwar_Nav_Walker extends Walker_Nav_Menu {
    public function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        if (in_array('current-menu-item', $classes) || in_array('current-menu-ancestor', $classes)) {
            $classes[] = 'active';
        }

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';

        $output .= '<li' . $class_names . '>';

        $atts = array();
        $atts['title']  = !empty($item->attr_title) ? $item->attr_title : '';
        $atts['target'] = !empty($item->target) ? $item->target : '';
        $atts['rel']    = !empty($item->xfn) ? $item->xfn : '';
        $atts['href']   = !empty($item->url) ? $item->url : '';

        if (in_array('current-menu-item', $classes)) {
            $atts['class'] = 'active';
        }

        $atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args, $depth);

        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $value = ('href' === $attr) ? esc_url($value) : esc_attr($value);
                $attributes .= ' ' . $attr . '="' . $value . '"';
            }
        }

        $title = apply_filters('the_title', $item->title, $item->ID);
        $title = apply_filters('nav_menu_item_title', $title, $item, $args, $depth);

        $item_output = $args->before;
        $item_output .= '<a' . $attributes . '>';
        $item_output .= $args->link_before . $title . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

/**
 * Get theme option helper
 */
function tanwar_get_option($option_name, $default = '') {
    return get_theme_mod($option_name, $default);
}

/**
 * Phone number formatter for India
 */
function tanwar_format_phone($phone) {
    $phone = preg_replace('/[^0-9+]/', '', $phone);
    return $phone;
}

/**
 * Format currency in INR
 */
function tanwar_format_currency($amount) {
    return '₹' . number_format($amount, 0, '.', ',');
}

/**
 * Get social media links
 */
function tanwar_get_social_links() {
    return array(
        'facebook'  => tanwar_get_option('social_facebook', ''),
        'twitter'   => tanwar_get_option('social_twitter', ''),
        'linkedin'  => tanwar_get_option('social_linkedin', ''),
        'instagram' => tanwar_get_option('social_instagram', ''),
    );
}

/**
 * AJAX handler for contact form
 */
function tanwar_contact_form_handler() {
    check_ajax_referer('tanwar_nonce', 'nonce');

    $name    = sanitize_text_field($_POST['name'] ?? '');
    $email   = sanitize_email($_POST['email'] ?? '');
    $phone   = sanitize_text_field($_POST['phone'] ?? '');
    $subject = sanitize_text_field($_POST['subject'] ?? 'Contact Form Inquiry');
    $message = sanitize_textarea_field($_POST['message'] ?? '');

    if (empty($name) || empty($email) || empty($message)) {
        wp_send_json_error(array('message' => 'Please fill in all required fields.'));
    }

    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'Please enter a valid email address.'));
    }

    $to = tanwar_get_option('contact_email', get_option('admin_email'));
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . $name . ' <' . $email . '>',
        'Reply-To: ' . $email,
    );

    $body = "
        <h2>New Contact Form Submission</h2>
        <p><strong>Name:</strong> {$name}</p>
        <p><strong>Email:</strong> {$email}</p>
        <p><strong>Phone:</strong> {$phone}</p>
        <p><strong>Message:</strong></p>
        <p>{$message}</p>
    ";

    $sent = wp_mail($to, $subject, $body, $headers);

    if ($sent) {
        wp_send_json_success(array('message' => 'Thank you for your message. We will contact you shortly.'));
    } else {
        wp_send_json_error(array('message' => 'There was an error sending your message. Please try again.'));
    }
}
add_action('wp_ajax_tanwar_contact_form', 'tanwar_contact_form_handler');
add_action('wp_ajax_nopriv_tanwar_contact_form', 'tanwar_contact_form_handler');

/**
 * Add Schema.org markup for law firm
 */
function tanwar_schema_markup() {
    if (!is_front_page()) return;

    $schema = array(
        '@context' => 'https://schema.org',
        '@type' => 'LegalService',
        'name' => tanwar_get_option('firm_name', 'Tanwar & Associates'),
        'description' => tanwar_get_option('firm_tagline', 'Advocates & Legal Consultants'),
        'url' => home_url('/'),
        'logo' => tanwar_get_option('site_logo', ''),
        'address' => array(
            '@type' => 'PostalAddress',
            'streetAddress' => tanwar_get_option('address_line1', ''),
            'addressLocality' => tanwar_get_option('city', 'Jaipur'),
            'addressRegion' => tanwar_get_option('state', 'Rajasthan'),
            'postalCode' => tanwar_get_option('pincode', ''),
            'addressCountry' => 'IN',
        ),
        'telephone' => tanwar_get_option('phone', ''),
        'email' => tanwar_get_option('email', ''),
        'openingHours' => 'Mo-Sa 09:00-18:00',
        'priceRange' => '₹₹',
        'areaServed' => array(
            '@type' => 'City',
            'name' => 'Jaipur',
        ),
    );

    echo '<script type="application/ld+json">' . wp_json_encode($schema) . '</script>';
}
add_action('wp_head', 'tanwar_schema_markup');

/**
 * Add Open Graph meta tags
 */
function tanwar_og_meta_tags() {
    global $post;

    echo '<meta property="og:locale" content="en_IN" />';
    echo '<meta property="og:type" content="website" />';
    echo '<meta property="og:site_name" content="' . esc_attr(get_bloginfo('name')) . '" />';

    if (is_single() || is_page()) {
        echo '<meta property="og:title" content="' . esc_attr(get_the_title()) . '" />';
        echo '<meta property="og:url" content="' . esc_url(get_permalink()) . '" />';
        
        if (has_excerpt()) {
            echo '<meta property="og:description" content="' . esc_attr(get_the_excerpt()) . '" />';
        }

        if (has_post_thumbnail()) {
            $thumbnail = wp_get_attachment_image_src(get_post_thumbnail_id(), 'large');
            echo '<meta property="og:image" content="' . esc_url($thumbnail[0]) . '" />';
        }
    } else {
        echo '<meta property="og:title" content="' . esc_attr(get_bloginfo('name')) . '" />';
        echo '<meta property="og:url" content="' . esc_url(home_url('/')) . '" />';
        echo '<meta property="og:description" content="' . esc_attr(get_bloginfo('description')) . '" />';
    }
}
add_action('wp_head', 'tanwar_og_meta_tags');

/**
 * Disable Gutenberg for custom post types
 */
function tanwar_disable_gutenberg($current_status, $post_type) {
    if (in_array($post_type, array('attorney', 'testimonial', 'practice_area'))) {
        return false;
    }
    return $current_status;
}
add_filter('use_block_editor_for_post_type', 'tanwar_disable_gutenberg', 10, 2);

/**
 * Check if page is built with Elementor
 */
function tanwar_is_elementor_page($post_id = null) {
    if (!$post_id) {
        $post_id = get_the_ID();
    }
    
    if (!class_exists('\Elementor\Plugin')) {
        return false;
    }
    
    return \Elementor\Plugin::$instance->db->is_built_with_elementor($post_id);
}

/**
 * Get placeholder image URL
 */
function tanwar_get_placeholder_image($type = 'attorney') {
    $placeholders = array(
        'attorney' => 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=500&fit=crop',
        'testimonial' => 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop',
        'hero' => 'https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=1920&h=1080&fit=crop',
        'practice' => 'https://images.unsplash.com/photo-1505664194779-8beaceb93744?w=600&h=400&fit=crop',
    );
    
    return $placeholders[$type] ?? $placeholders['attorney'];
}