# Tanwar & Associates - WordPress Theme

A professional WordPress theme for Tanwar & Associates Law Firm with full Elementor integration.

## Installation

1. Upload the `tanwar-associates` folder to `wp-content/themes/`
2. Activate the theme in WordPress Dashboard → Appearance → Themes
3. Install and activate Elementor plugin for page builder functionality
4. (Optional) Install Elementor Pro for Theme Builder features
5. Create pages: Home, About, Contact, Practice Areas, Team, FAQ, Testimonials
6. Set Front Page Display to "A static page" and select Home
7. Customize via Appearance → Customize

## Features

- **Full Elementor Integration**: Every page and template is editable with Elementor
- **Elementor Theme Builder Support**: Custom header, footer, single post, and archive templates
- **14 Custom Elementor Widgets**:
  - Hero Section
  - Practice Areas Grid
  - Practice Area Card
  - Team Grid
  - Team Member Card
  - Testimonials Carousel
  - Contact Form
  - Statistics Counter
  - CTA Section
  - Blog Posts Grid
  - Services Slider
  - Clients Logo Carousel
  - Pricing Table
- Custom Post Types: Attorneys, Testimonials, Practice Areas
- Theme Customizer for contact info and social links
- Responsive design with mobile navigation
- Contact form with AJAX submission
- SEO optimized with Schema.org markup
- Bar Council of India compliant disclaimer

## Elementor Widgets

All custom widgets are found under the **"Tanwar Associates"** category in Elementor.

### Hero Section Widget
- Customizable title, subtitle, and CTAs
- Background image/video options
- Overlay and animation controls

### Practice Areas Grid Widget
- Grid/List/Masonry layouts
- Category filtering
- Dynamic content from Practice Area CPT

### Team Grid Widget
- Display attorneys from custom post type
- Filter by role/specialization
- Hover effects and social links

### Testimonials Carousel Widget
- Auto-play with navigation controls
- Star ratings display
- Client image and info

### Statistics Counter Widget
- Animated counting effect
- Multiple counter styles
- Icon support

### CTA Section Widget
- Multiple layout styles
- Button customization
- Background effects

### Blog Posts Grid Widget
- Category filtering
- Multiple layout options
- Pagination support

### Services Slider Widget
- Auto-play controls
- Multiple slide designs
- Progress bar navigation

### Clients Logo Carousel Widget
- Infinite scroll option
- Grayscale hover effects
- Responsive columns

### Pricing Table Widget
- Multiple tiers
- Featured/recommended plan highlighting
- Feature list with availability icons

### Contact Form Widget
- Built-in validation
- AJAX submission
- Success/error messaging

## Template Files

All templates support both Elementor editing and fallback theme content:

- `front-page.php` - Home page
- `page.php` - Generic page template
- `page-about.php` - About page
- `page-contact.php` - Contact page
- `page-practice-areas.php` - Practice areas
- `page-team.php` - Team page
- `page-faq.php` - FAQ page
- `page-testimonials.php` - Testimonials page
- `single.php` - Single blog post
- `single-attorney.php` - Attorney profile
- `single-practice_area.php` - Practice area detail
- `archive.php` - Blog/archive listing
- `index.php` - Default template

### Elementor Templates Directory

- `templates/template-elementor-canvas.php` - Full canvas (no header/footer)
- `templates/template-elementor-full-width.php` - Full width with header/footer

## Elementor Theme Builder Locations

The theme registers all core Elementor Theme Builder locations:
- Header
- Footer
- Single Post
- Single Page
- Archive
- Search Results
- 404 Page

## How to Edit with Elementor

### Editing a Page
1. Go to Pages → Select your page
2. Click "Edit with Elementor"
3. Use the visual builder to make changes
4. Click "Update" to save

### Using Custom Widgets
1. Open the Elementor panel
2. Find "Tanwar Associates" category
3. Drag and drop widgets onto your page
4. Customize using the widget controls

### Creating Custom Headers/Footers (Elementor Pro)
1. Go to Templates → Theme Builder
2. Add New Header or Footer
3. Design using Elementor
4. Set display conditions
5. Publish

## Customization

Edit settings via Appearance → Customize:
- Firm name, phone, email, address
- Social media URLs
- Logo upload
- Colors and typography

## Custom Post Types

### Attorneys
- Role, specialization, experience
- Education, bar council info
- Contact details, LinkedIn
- Photo gallery

### Practice Areas
- Icon selection
- Services list
- Related attorneys

### Testimonials
- Client name, role
- Rating (1-5 stars)
- Photo

## Support

Contact: info@tanwarassociates.com

## Requirements

- WordPress 5.9+
- PHP 7.4+
- Elementor 3.0+ (Free or Pro)
