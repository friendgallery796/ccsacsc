<?php
/**
 * Template Name: Front Page
 * The front page template file - Fully Elementor Editable
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor
$is_elementor = class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID());

if ($is_elementor) :
    // Elementor content - Display the Elementor-built page
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Default theme content - Fallback when Elementor is not used
?>

<?php get_template_part('template-parts/hero'); ?>

<?php get_template_part('template-parts/statistics'); ?>

<?php get_template_part('template-parts/practice-areas'); ?>

<?php get_template_part('template-parts/why-choose-us'); ?>

<?php get_template_part('template-parts/testimonials'); ?>

<?php get_template_part('template-parts/contact-cta'); ?>

<?php endif; // End Elementor check ?>

<?php get_footer(); ?>
