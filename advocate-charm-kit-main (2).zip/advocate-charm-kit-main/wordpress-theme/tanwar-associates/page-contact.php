<?php
/**
 * Template Name: Contact Page
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor
$is_elementor = class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID());

if ($is_elementor) :
    // Elementor content
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Default theme content
?>

<div class="contact-hero">
    <div class="container">
        <nav class="breadcrumbs">
            <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
            <span>/</span>
            <span>Contact Us</span>
        </nav>
        <h1><?php esc_html_e('Get in Touch', 'tanwar-associates'); ?></h1>
        <p><?php esc_html_e('Schedule a consultation with our experienced legal team. We are here to help you navigate your legal challenges.', 'tanwar-associates'); ?></p>
    </div>
</div>

<section class="section">
    <div class="container">
        <div class="contact-section">
            <!-- Contact Information -->
            <div>
                <h2 style="margin-bottom: 1.5rem;"><?php esc_html_e('Contact Information', 'tanwar-associates'); ?></h2>
                <p style="color: var(--muted-foreground); margin-bottom: 2rem;">
                    <?php esc_html_e('Reach out to us through any of the following channels. Our team responds within 24 hours.', 'tanwar-associates'); ?>
                </p>
                
                <div class="contact-info-list">
                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                                <circle cx="12" cy="10" r="3"></circle>
                            </svg>
                        </div>
                        <div class="contact-info-content">
                            <h4><?php esc_html_e('Office Address', 'tanwar-associates'); ?></h4>
                            <p>
                                <?php echo nl2br(esc_html(function_exists('tanwar_get_option') ? tanwar_get_option('address', "Chamber No. 123, High Court Premises\nJaipur, Rajasthan 302001\nIndia") : "Chamber No. 123, High Court Premises\nJaipur, Rajasthan 302001\nIndia")); ?>
                            </p>
                        </div>
                    </div>

                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                            </svg>
                        </div>
                        <div class="contact-info-content">
                            <h4><?php esc_html_e('Phone Number', 'tanwar-associates'); ?></h4>
                            <?php 
                            $phone = function_exists('tanwar_get_option') ? tanwar_get_option('phone', '+91 98290 12345') : '+91 98290 12345';
                            $phone_alt = function_exists('tanwar_get_option') ? tanwar_get_option('phone_alt', '+91 141 2560123') : '+91 141 2560123';
                            $phone_formatted = preg_replace('/[^0-9+]/', '', $phone);
                            $phone_alt_formatted = preg_replace('/[^0-9+]/', '', $phone_alt);
                            ?>
                            <p>
                                <a href="tel:<?php echo esc_attr($phone_formatted); ?>">
                                    <?php echo esc_html($phone); ?>
                                </a>
                            </p>
                            <p>
                                <a href="tel:<?php echo esc_attr($phone_alt_formatted); ?>">
                                    <?php echo esc_html($phone_alt); ?>
                                </a>
                            </p>
                        </div>
                    </div>

                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                        </div>
                        <div class="contact-info-content">
                            <h4><?php esc_html_e('Email Address', 'tanwar-associates'); ?></h4>
                            <?php $email = function_exists('tanwar_get_option') ? tanwar_get_option('email', 'info@tanwarassociates.com') : 'info@tanwarassociates.com'; ?>
                            <p>
                                <a href="mailto:<?php echo esc_attr($email); ?>">
                                    <?php echo esc_html($email); ?>
                                </a>
                            </p>
                        </div>
                    </div>

                    <div class="contact-info-item">
                        <div class="contact-info-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                        </div>
                        <div class="contact-info-content">
                            <h4><?php esc_html_e('Office Hours', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Monday - Saturday: 9:00 AM - 6:00 PM', 'tanwar-associates'); ?></p>
                            <p><?php esc_html_e('Sunday: By Appointment Only', 'tanwar-associates'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Court Locations -->
                <div style="margin-top: 2rem; padding: 1.5rem; background: var(--muted); border-radius: var(--radius);">
                    <h4 style="margin-bottom: 1rem;"><?php esc_html_e('Courts We Practice At', 'tanwar-associates'); ?></h4>
                    <ul style="color: var(--muted-foreground); font-size: 0.9375rem;">
                        <li style="margin-bottom: 0.5rem;">• Rajasthan High Court, Jaipur Bench</li>
                        <li style="margin-bottom: 0.5rem;">• District & Sessions Court, Jaipur</li>
                        <li style="margin-bottom: 0.5rem;">• Family Court, Jaipur</li>
                        <li style="margin-bottom: 0.5rem;">• Consumer Forum, Jaipur</li>
                        <li style="margin-bottom: 0.5rem;">• NCLT Jaipur Bench</li>
                        <li>• All District Courts in Rajasthan</li>
                    </ul>
                </div>
            </div>

            <!-- Contact Form -->
            <div class="contact-form-wrapper">
                <h3><?php esc_html_e('Send Us a Message', 'tanwar-associates'); ?></h3>
                <p style="color: var(--muted-foreground); margin-bottom: 1.5rem; font-size: 0.9375rem;">
                    <?php esc_html_e('Fill out the form below and we will get back to you within 24 hours.', 'tanwar-associates'); ?>
                </p>

                <form id="contact-form" method="post">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="name"><?php esc_html_e('Full Name', 'tanwar-associates'); ?> *</label>
                            <input type="text" id="name" name="name" class="form-control" placeholder="<?php esc_attr_e('Enter your full name', 'tanwar-associates'); ?>" required>
                        </div>
                        <div class="form-group">
                            <label for="phone"><?php esc_html_e('Phone Number', 'tanwar-associates'); ?> *</label>
                            <input type="tel" id="phone" name="phone" class="form-control" placeholder="<?php esc_attr_e('+91 98765 43210', 'tanwar-associates'); ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="email"><?php esc_html_e('Email Address', 'tanwar-associates'); ?> *</label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="<?php esc_attr_e('your.email@example.com', 'tanwar-associates'); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="subject"><?php esc_html_e('Subject / Legal Matter', 'tanwar-associates'); ?></label>
                        <select id="subject" name="subject" class="form-control">
                            <option value=""><?php esc_html_e('Select a practice area', 'tanwar-associates'); ?></option>
                            <option value="Civil Litigation"><?php esc_html_e('Civil Litigation', 'tanwar-associates'); ?></option>
                            <option value="Criminal Law"><?php esc_html_e('Criminal Law', 'tanwar-associates'); ?></option>
                            <option value="Corporate Law"><?php esc_html_e('Corporate & Commercial Law', 'tanwar-associates'); ?></option>
                            <option value="Family Law"><?php esc_html_e('Family & Matrimonial Law', 'tanwar-associates'); ?></option>
                            <option value="Property Law"><?php esc_html_e('Property & Real Estate', 'tanwar-associates'); ?></option>
                            <option value="Cheque Bounce"><?php esc_html_e('Cheque Bounce (Section 138)', 'tanwar-associates'); ?></option>
                            <option value="NCLT Matters"><?php esc_html_e('NCLT / Insolvency Matters', 'tanwar-associates'); ?></option>
                            <option value="Other"><?php esc_html_e('Other Legal Matter', 'tanwar-associates'); ?></option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="message"><?php esc_html_e('Your Message', 'tanwar-associates'); ?> *</label>
                        <textarea id="message" name="message" class="form-control" rows="5" placeholder="<?php esc_attr_e('Please describe your legal matter briefly...', 'tanwar-associates'); ?>" required></textarea>
                    </div>

                    <p style="font-size: 0.8125rem; color: var(--muted-foreground); margin-bottom: 1.5rem;">
                        <?php esc_html_e('* All information shared is kept strictly confidential as per advocate-client privilege.', 'tanwar-associates'); ?>
                    </p>

                    <button type="submit" class="btn btn-primary btn-lg w-full">
                        <?php esc_html_e('Send Message', 'tanwar-associates'); ?>
                    </button>
                </form>
            </div>
        </div>

        <!-- Google Map -->
        <div class="contact-map">
            <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3557.5!2d75.7873!3d26.9124!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2sRajasthan%20High%20Court!5e0!3m2!1sen!2sin!4v1600000000000!5m2!1sen!2sin" 
                width="100%" 
                height="100%" 
                style="border:0;" 
                allowfullscreen="" 
                loading="lazy" 
                referrerpolicy="no-referrer-when-downgrade"
                title="<?php esc_attr_e('Office Location Map', 'tanwar-associates'); ?>">
            </iframe>
        </div>
    </div>
</section>

<?php endif; // End Elementor check ?>

<?php get_footer(); ?>
