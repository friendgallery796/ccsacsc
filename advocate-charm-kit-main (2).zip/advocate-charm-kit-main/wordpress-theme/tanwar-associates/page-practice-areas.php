<?php
/**
 * Template Name: Practice Areas Page
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor
$is_elementor = class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID());

if ($is_elementor) :
    // Elementor content
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Default theme content

$practice_areas = array(
    array(
        'title' => 'Civil Litigation',
        'description' => 'Comprehensive civil litigation services including property disputes, contract enforcement, recovery suits, injunctions, declaratory suits, and partition matters.',
        'services' => array('Property Disputes', 'Contract Enforcement', 'Recovery Suits', 'Injunctions', 'Declaratory Suits', 'Partition Matters', 'Specific Performance'),
        'icon' => 'scale',
    ),
    array(
        'title' => 'Criminal Law',
        'description' => 'Expert criminal defense including bail applications, trial representation, appeals at High Court and Supreme Court, anticipatory bail, and quashing petitions.',
        'services' => array('Bail Applications', 'Criminal Trials', 'Appeals', 'Anticipatory Bail', 'Quashing Petitions', 'Cheating Cases', 'White Collar Crimes'),
        'icon' => 'shield',
    ),
    array(
        'title' => 'Corporate & Commercial Law',
        'description' => 'Full-service corporate legal solutions including company incorporation, contract drafting, M&A advisory, compliance, and NCLT matters.',
        'services' => array('Company Formation', 'Contract Drafting', 'M&A Advisory', 'Due Diligence', 'NCLT Matters', 'Insolvency Proceedings', 'Shareholder Disputes'),
        'icon' => 'building',
    ),
    array(
        'title' => 'Family & Matrimonial Law',
        'description' => 'Sensitive handling of family matters including divorce, child custody, maintenance, domestic violence protection, and inheritance disputes.',
        'services' => array('Divorce Proceedings', 'Child Custody', 'Maintenance Claims', 'Domestic Violence', 'Marriage Registration', 'Succession Matters', 'Adoption'),
        'icon' => 'users',
    ),
    array(
        'title' => 'Property & Real Estate',
        'description' => 'Complete property law services including title verification, sale deed drafting, RERA matters, land acquisition, and property documentation.',
        'services' => array('Title Verification', 'Sale Deed Drafting', 'RERA Matters', 'Land Disputes', 'Lease Agreements', 'Property Documentation', 'Builder Disputes'),
        'icon' => 'home',
    ),
    array(
        'title' => 'Cheque Bounce (NI Act)',
        'description' => 'Specialized practice in Section 138 Negotiable Instruments Act cases including complaints, defense, settlements, and recovery proceedings.',
        'services' => array('Section 138 Complaints', 'Defense in NI Cases', 'Settlement Negotiations', 'Recovery Proceedings', 'Appeal Matters', 'Compounding'),
        'icon' => 'file-text',
    ),
    array(
        'title' => 'Labour & Employment',
        'description' => 'Employment law matters including wrongful termination, workplace disputes, PF/ESI matters, and industrial disputes.',
        'services' => array('Wrongful Termination', 'Workplace Disputes', 'PF/ESI Matters', 'Industrial Disputes', 'Service Matters', 'Employment Contracts'),
        'icon' => 'briefcase',
    ),
    array(
        'title' => 'Consumer Protection',
        'description' => 'Consumer forum representation for product defects, deficient services, unfair trade practices, and compensation claims.',
        'services' => array('Consumer Complaints', 'Product Defects', 'Service Deficiency', 'Medical Negligence', 'Insurance Claims', 'Banking Disputes'),
        'icon' => 'shield-check',
    ),
);
?>

<div class="page-hero">
    <div class="container">
        <div class="page-hero-content">
            <nav class="breadcrumbs">
                <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                <span>/</span>
                <span>Practice Areas</span>
            </nav>
            <h1><?php esc_html_e('Our Practice Areas', 'tanwar-associates'); ?></h1>
            <p><?php esc_html_e('Comprehensive legal services across all major practice areas. Expert representation at Rajasthan High Court and all district courts.', 'tanwar-associates'); ?></p>
        </div>
    </div>
</div>

<section class="section">
    <div class="container">
        <div class="grid gap-8">
            <?php foreach ($practice_areas as $index => $area) : ?>
            <div class="card" style="padding: 0; overflow: hidden;">
                <div class="grid md:grid-cols-3" style="<?php echo $index % 2 === 1 ? '' : ''; ?>">
                    <div style="background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); padding: 2.5rem; display: flex; flex-direction: column; justify-content: center;">
                        <div style="width: 60px; height: 60px; background: rgba(255,255,255,0.1); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2">
                                <circle cx="12" cy="12" r="10"/>
                            </svg>
                        </div>
                        <h3 style="color: var(--primary-foreground); margin-bottom: 0.5rem;"><?php echo esc_html($area['title']); ?></h3>
                        <p style="color: rgba(255,255,255,0.8); font-size: 0.9375rem; margin-bottom: 0;">
                            <?php echo esc_html($area['description']); ?>
                        </p>
                    </div>
                    <div style="padding: 2.5rem; grid-column: span 2;">
                        <h4 style="margin-bottom: 1.5rem; color: var(--accent);"><?php esc_html_e('Services We Offer', 'tanwar-associates'); ?></h4>
                        <div class="grid sm:grid-cols-2 gap-3">
                            <?php foreach ($area['services'] as $service) : ?>
                            <div style="display: flex; align-items: center; gap: 0.75rem;">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2">
                                    <polyline points="20 6 9 17 4 12"></polyline>
                                </svg>
                                <span style="font-size: 0.9375rem;"><?php echo esc_html($service); ?></span>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div style="margin-top: 2rem;">
                            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-outline">
                                <?php esc_html_e('Consult Now', 'tanwar-associates'); ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="5" y1="12" x2="19" y2="12"></line>
                                    <polyline points="12 5 19 12 12 19"></polyline>
                                </svg>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/contact-cta'); ?>

<?php endif; // End Elementor check ?>

<?php get_footer(); ?>
