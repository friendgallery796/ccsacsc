<?php
/**
 * Template Name: About Page
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor
$is_elementor = class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID());

if ($is_elementor) :
    // Elementor content
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
else :
    // Default theme content
?>

<div class="page-hero">
    <div class="container">
        <div class="page-hero-content">
            <nav class="breadcrumbs">
                <a href="<?php echo esc_url(home_url('/')); ?>">Home</a>
                <span>/</span>
                <span>About Us</span>
            </nav>
            <h1><?php esc_html_e('About Tanwar & Associates', 'tanwar-associates'); ?></h1>
            <p><?php esc_html_e('Decades of legal excellence serving clients across Rajasthan with integrity, expertise, and dedication.', 'tanwar-associates'); ?></p>
        </div>
    </div>
</div>

<!-- About Content Section -->
<section class="section">
    <div class="container">
        <div class="about-grid">
            <div class="about-content">
                <span class="section-subtitle"><?php esc_html_e('Our Story', 'tanwar-associates'); ?></span>
                <h2><?php esc_html_e('A Legacy of Legal Excellence Since 1998', 'tanwar-associates'); ?></h2>
                
                <p>
                    <?php esc_html_e('Tanwar & Associates was established in 1998 by Adv. Rajesh Tanwar with a vision to provide accessible, high-quality legal services to individuals and businesses in Rajasthan. What started as a small practice has grown into one of the most respected law firms in Jaipur.', 'tanwar-associates'); ?>
                </p>
                
                <p>
                    <?php esc_html_e('Over the past 25+ years, we have successfully represented thousands of clients in matters ranging from complex civil litigation and corporate disputes to sensitive family matters and criminal defense. Our team of experienced advocates combines deep legal knowledge with a client-centered approach.', 'tanwar-associates'); ?>
                </p>
                
                <p>
                    <?php esc_html_e('We take pride in our track record of favorable judgments at the Rajasthan High Court, District Courts, and various tribunals. Our commitment to ethical practice, transparent communication, and relentless pursuit of justice has earned us the trust of clients across Rajasthan.', 'tanwar-associates'); ?>
                </p>

                <div class="about-features">
                    <div class="about-feature">
                        <div class="about-feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                        </div>
                        <div>
                            <h4><?php esc_html_e('Bar Council Registered', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('All our advocates are registered with the Bar Council of Rajasthan', 'tanwar-associates'); ?></p>
                        </div>
                    </div>
                    
                    <div class="about-feature">
                        <div class="about-feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                        </div>
                        <div>
                            <h4><?php esc_html_e('Confidentiality Assured', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Strict adherence to advocate-client privilege in all matters', 'tanwar-associates'); ?></p>
                        </div>
                    </div>
                    
                    <div class="about-feature">
                        <div class="about-feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                        </div>
                        <div>
                            <h4><?php esc_html_e('Timely Updates', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Regular communication on case progress and court dates', 'tanwar-associates'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="about-image">
                <img src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&h=800&fit=crop" alt="<?php esc_attr_e('Law Office Interior', 'tanwar-associates'); ?>" loading="lazy">
                <div class="about-image-badge">
                    <span class="about-image-badge-number">25+</span>
                    <span class="about-image-badge-text"><?php esc_html_e('Years of Excellence', 'tanwar-associates'); ?></span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Mission & Vision Section -->
<section class="section" style="background-color: var(--muted);">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle"><?php esc_html_e('Our Values', 'tanwar-associates'); ?></span>
            <h2 class="section-title"><?php esc_html_e('Mission & Vision', 'tanwar-associates'); ?></h2>
        </div>
        
        <div class="grid md:grid-cols-2 gap-8">
            <div class="card" style="padding: 2.5rem;">
                <div style="width: 60px; height: 60px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="2" y1="12" x2="22" y2="12"></line>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                    </svg>
                </div>
                <h3><?php esc_html_e('Our Mission', 'tanwar-associates'); ?></h3>
                <p style="color: var(--muted-foreground); line-height: 1.8;">
                    <?php esc_html_e('To provide accessible, ethical, and effective legal representation to every client, ensuring their rights are protected and justice is served. We strive to simplify complex legal matters while maintaining the highest standards of professional conduct.', 'tanwar-associates'); ?>
                </p>
            </div>
            
            <div class="card" style="padding: 2.5rem;">
                <div style="width: 60px; height: 60px; background: var(--primary); border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-bottom: 1.5rem;">
                    <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" stroke-width="2">
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                        <circle cx="12" cy="12" r="3"></circle>
                    </svg>
                </div>
                <h3><?php esc_html_e('Our Vision', 'tanwar-associates'); ?></h3>
                <p style="color: var(--muted-foreground); line-height: 1.8;">
                    <?php esc_html_e('To be recognized as the most trusted and client-focused law firm in Rajasthan, known for integrity, expertise, and a genuine commitment to achieving the best possible outcomes for our clients in every legal matter.', 'tanwar-associates'); ?>
                </p>
            </div>
        </div>
    </div>
</section>

<!-- Core Values Section -->
<section class="section">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle"><?php esc_html_e('What We Stand For', 'tanwar-associates'); ?></span>
            <h2 class="section-title"><?php esc_html_e('Our Core Values', 'tanwar-associates'); ?></h2>
        </div>
        
        <div class="grid md:grid-cols-4 gap-6">
            <div class="value-card">
                <div class="value-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
                    </svg>
                </div>
                <h4><?php esc_html_e('Integrity', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('Honest and ethical practice in every case we handle.', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="value-card">
                <div class="value-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
                    </svg>
                </div>
                <h4><?php esc_html_e('Excellence', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('Commitment to delivering the highest quality legal services.', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="value-card">
                <div class="value-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <h4><?php esc_html_e('Client Focus', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('Your needs and goals are always our top priority.', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="value-card">
                <div class="value-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                </div>
                <h4><?php esc_html_e('Timeliness', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('Prompt action and regular updates on all matters.', 'tanwar-associates'); ?></p>
            </div>
        </div>
    </div>
</section>

<!-- Courts We Practice At -->
<section class="section" style="background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%); color: var(--primary-foreground);">
    <div class="container">
        <div class="section-header" style="color: var(--primary-foreground);">
            <span class="section-subtitle" style="color: var(--accent);"><?php esc_html_e('Our Presence', 'tanwar-associates'); ?></span>
            <h2 class="section-title" style="color: var(--primary-foreground);"><?php esc_html_e('Courts We Practice At', 'tanwar-associates'); ?></h2>
            <p style="color: rgba(255,255,255,0.8); max-width: 600px; margin: 0 auto;">
                <?php esc_html_e('Our advocates regularly appear before various courts and tribunals across Rajasthan and beyond.', 'tanwar-associates'); ?>
            </p>
        </div>
        
        <div class="grid sm:grid-cols-2 md:grid-cols-3 gap-6">
            <div class="court-card">
                <div class="court-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="3" y1="22" x2="21" y2="22"></line>
                        <line x1="6" y1="18" x2="6" y2="11"></line>
                        <line x1="10" y1="18" x2="10" y2="11"></line>
                        <line x1="14" y1="18" x2="14" y2="11"></line>
                        <line x1="18" y1="18" x2="18" y2="11"></line>
                        <polygon points="12 2 20 7 4 7"></polygon>
                    </svg>
                </div>
                <h4><?php esc_html_e('Rajasthan High Court', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('Jaipur & Jodhpur Benches', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="court-card">
                <div class="court-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="2" y1="12" x2="22" y2="12"></line>
                        <path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path>
                    </svg>
                </div>
                <h4><?php esc_html_e('Supreme Court of India', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('New Delhi', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="court-card">
                <div class="court-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                        <polyline points="9 22 9 12 15 12 15 22"></polyline>
                    </svg>
                </div>
                <h4><?php esc_html_e('District & Sessions Courts', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('All Districts in Rajasthan', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="court-card">
                <div class="court-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                        <line x1="7" y1="7" x2="7.01" y2="7"></line>
                    </svg>
                </div>
                <h4><?php esc_html_e('NCLT Jaipur Bench', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('Company & Insolvency Matters', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="court-card">
                <div class="court-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path>
                        <circle cx="9" cy="7" r="4"></circle>
                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"></path>
                        <path d="M16 3.13a4 4 0 0 1 0 7.75"></path>
                    </svg>
                </div>
                <h4><?php esc_html_e('Family Courts', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('Matrimonial & Custody Matters', 'tanwar-associates'); ?></p>
            </div>
            
            <div class="court-card">
                <div class="court-card-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path>
                        <line x1="12" y1="17" x2="12.01" y2="17"></line>
                    </svg>
                </div>
                <h4><?php esc_html_e('Consumer Forums', 'tanwar-associates'); ?></h4>
                <p><?php esc_html_e('State & District Level', 'tanwar-associates'); ?></p>
            </div>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/contact-cta'); ?>

<?php endif; // End Elementor check ?>

<?php get_footer(); ?>
