<?php
/**
 * Single Attorney Profile Template
 * Fully Elementor Editable
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if Elementor Theme Builder handles this template
if (function_exists('elementor_theme_do_location') && elementor_theme_do_location('single')) {
    // Elementor Theme Builder single template
} elseif (class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID())) {
    // Individual attorney post built with Elementor
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
} else {
    // Default theme content

// Get attorney meta from custom post type
$attorney_id = get_the_ID();
$role = get_post_meta($attorney_id, '_attorney_role', true) ?: 'Senior Advocate';
$specialization = get_post_meta($attorney_id, '_attorney_specialization', true) ?: 'Legal Services';
$experience = get_post_meta($attorney_id, '_attorney_experience', true) ?: '10+ Years';
$education = get_post_meta($attorney_id, '_attorney_education', true) ?: 'LL.B.';
$bar_council = get_post_meta($attorney_id, '_attorney_bar_council', true) ?: 'Bar Council of Rajasthan';
$courts = get_post_meta($attorney_id, '_attorney_courts', true) ?: 'Rajasthan High Court, District Courts';
$attorney_email = get_post_meta($attorney_id, '_attorney_email', true);
$attorney_phone = get_post_meta($attorney_id, '_attorney_phone', true);
$linkedin = get_post_meta($attorney_id, '_attorney_linkedin', true);

// Default data for display
$languages = 'Hindi, English';
$expertise = array(
    'Legal Consultation & Advisory',
    'Court Representation',
    'Document Drafting',
    'Case Strategy & Analysis',
    'Settlement Negotiations',
    'Appeals & Revisions',
);

$achievements = array(
    'Successfully handled numerous cases at High Court',
    'Member of Bar Council of Rajasthan',
    'Regular speaker at legal seminars',
    'Published articles in law journals',
);

// Sample case history - In production, this would come from a related CPT or meta
$cases = array(
    array('title' => 'Property Dispute Resolution', 'outcome' => 'Won', 'year' => '2024', 'court' => 'Rajasthan High Court', 'description' => 'Successfully resolved a complex property dispute involving multiple parties.'),
    array('title' => 'Corporate Contract Enforcement', 'outcome' => 'Settled', 'year' => '2023', 'court' => 'NCLT Jaipur', 'description' => 'Negotiated favorable settlement in commercial contract dispute.'),
    array('title' => 'Criminal Defense Matter', 'outcome' => 'Acquitted', 'year' => '2023', 'court' => 'Sessions Court', 'description' => 'Secured full acquittal for client in criminal proceedings.'),
    array('title' => 'Family Law Case', 'outcome' => 'Won', 'year' => '2022', 'court' => 'Family Court', 'description' => 'Obtained favorable custody and maintenance order for client.'),
    array('title' => 'Consumer Protection Matter', 'outcome' => 'Won', 'year' => '2022', 'court' => 'Consumer Forum', 'description' => 'Recovered compensation for defective product purchase.'),
);

// Get related attorneys
$related_attorneys = get_posts(array(
    'post_type'      => 'attorney',
    'posts_per_page' => 3,
    'post__not_in'   => array($attorney_id),
    'orderby'        => 'rand',
));
?>

<div class="page-hero attorney-hero">
    <div class="container">
        <div class="page-hero-content">
            <nav class="breadcrumbs">
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'tanwar-associates'); ?></a>
                <span>/</span>
                <a href="<?php echo esc_url(home_url('/team/')); ?>"><?php esc_html_e('Our Team', 'tanwar-associates'); ?></a>
                <span>/</span>
                <span><?php the_title(); ?></span>
            </nav>
        </div>
    </div>
</div>

<section class="section">
    <div class="container">
        <div class="attorney-profile">
            <!-- Sidebar -->
            <aside class="attorney-sidebar">
                <div class="attorney-photo">
                    <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('attorney-large', array('alt' => get_the_title())); ?>
                    <?php else : ?>
                        <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=500&fit=crop" alt="<?php echo esc_attr(get_the_title()); ?>">
                    <?php endif; ?>
                </div>
                
                <div class="attorney-quick-info">
                    <h3><?php esc_html_e('Quick Info', 'tanwar-associates'); ?></h3>
                    <ul>
                        <li>
                            <span class="info-label"><?php esc_html_e('Experience', 'tanwar-associates'); ?></span>
                            <span class="info-value"><?php echo esc_html($experience); ?></span>
                        </li>
                        <li>
                            <span class="info-label"><?php esc_html_e('Education', 'tanwar-associates'); ?></span>
                            <span class="info-value"><?php echo esc_html($education); ?></span>
                        </li>
                        <li>
                            <span class="info-label"><?php esc_html_e('Bar Council', 'tanwar-associates'); ?></span>
                            <span class="info-value"><?php echo esc_html($bar_council); ?></span>
                        </li>
                        <li>
                            <span class="info-label"><?php esc_html_e('Languages', 'tanwar-associates'); ?></span>
                            <span class="info-value"><?php echo esc_html($languages); ?></span>
                        </li>
                    </ul>
                </div>

                <!-- Direct Contact -->
                <?php if ($attorney_phone || $attorney_email) : ?>
                <div class="attorney-direct-contact">
                    <h4><?php esc_html_e('Direct Contact', 'tanwar-associates'); ?></h4>
                    <?php if ($attorney_phone) : ?>
                    <a href="tel:<?php echo esc_attr(tanwar_format_phone($attorney_phone)); ?>" class="direct-contact-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        <span><?php echo esc_html($attorney_phone); ?></span>
                    </a>
                    <?php endif; ?>
                    <?php if ($attorney_email) : ?>
                    <a href="mailto:<?php echo esc_attr($attorney_email); ?>" class="direct-contact-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                            <polyline points="22,6 12,13 2,6"></polyline>
                        </svg>
                        <span><?php echo esc_html($attorney_email); ?></span>
                    </a>
                    <?php endif; ?>
                    <?php if ($linkedin) : ?>
                    <a href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener noreferrer" class="direct-contact-link">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                            <rect x="2" y="9" width="4" height="12"></rect>
                            <circle cx="4" cy="4" r="2"></circle>
                        </svg>
                        <span><?php esc_html_e('LinkedIn Profile', 'tanwar-associates'); ?></span>
                    </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <div class="attorney-cta-buttons">
                    <a href="#contact-form" class="btn btn-primary w-full">
                        <?php esc_html_e('Schedule Consultation', 'tanwar-associates'); ?>
                    </a>
                    <a href="tel:<?php echo esc_attr(tanwar_format_phone(tanwar_get_option('phone', '+919829012345'))); ?>" class="btn btn-outline w-full">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"></path>
                        </svg>
                        <?php esc_html_e('Call Now', 'tanwar-associates'); ?>
                    </a>
                </div>
            </aside>

            <!-- Main Content -->
            <div class="attorney-main">
                <div class="attorney-header">
                    <h1><?php the_title(); ?></h1>
                    <p class="attorney-role"><?php echo esc_html($role); ?> • <?php echo esc_html($specialization); ?></p>
                    
                    <div class="attorney-badge">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                        <span><?php esc_html_e('Verified Legal Professional', 'tanwar-associates'); ?></span>
                    </div>
                </div>

                <!-- Biography -->
                <div class="attorney-section">
                    <h3><?php esc_html_e('About', 'tanwar-associates'); ?></h3>
                    <div class="attorney-bio">
                        <?php 
                        if (have_posts()) : 
                            while (have_posts()) : the_post();
                                the_content();
                            endwhile;
                        endif;
                        
                        // Default bio if empty
                        if (empty(get_the_content())) :
                        ?>
                            <p><?php printf(esc_html__('%s is an experienced advocate at Tanwar & Associates with expertise in %s. With %s of dedicated practice, they have built a reputation for providing excellent legal representation and achieving favorable outcomes for clients.', 'tanwar-associates'), get_the_title(), esc_html($specialization), esc_html($experience)); ?></p>
                            
                            <p><?php esc_html_e('Their approach combines deep legal knowledge with a client-centered focus, ensuring that every case receives personalized attention and strategic planning. They regularly appear at courts across Rajasthan and are committed to upholding the highest standards of legal practice.', 'tanwar-associates'); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Courts of Practice -->
                <div class="attorney-section">
                    <h3><?php esc_html_e('Courts of Practice', 'tanwar-associates'); ?></h3>
                    <div class="courts-grid">
                        <?php 
                        $court_list = array_map('trim', explode(',', $courts));
                        foreach ($court_list as $court) : 
                        ?>
                        <div class="court-item">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="3" y1="22" x2="21" y2="22"></line>
                                <line x1="6" y1="18" x2="6" y2="11"></line>
                                <line x1="10" y1="18" x2="10" y2="11"></line>
                                <line x1="14" y1="18" x2="14" y2="11"></line>
                                <line x1="18" y1="18" x2="18" y2="11"></line>
                                <polygon points="12 2 20 7 4 7"></polygon>
                            </svg>
                            <span><?php echo esc_html($court); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Areas of Expertise -->
                <div class="attorney-section">
                    <h3><?php esc_html_e('Areas of Expertise', 'tanwar-associates'); ?></h3>
                    <div class="expertise-grid">
                        <?php foreach ($expertise as $item) : ?>
                        <div class="expertise-item">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <polyline points="20 6 9 17 4 12"></polyline>
                            </svg>
                            <span><?php echo esc_html($item); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Key Achievements -->
                <div class="attorney-section">
                    <h3><?php esc_html_e('Key Achievements', 'tanwar-associates'); ?></h3>
                    <div class="achievements-list">
                        <?php foreach ($achievements as $achievement) : ?>
                        <div class="achievement-item">
                            <div class="achievement-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="8" r="7"></circle>
                                    <polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"></polyline>
                                </svg>
                            </div>
                            <span><?php echo esc_html($achievement); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Case History -->
                <div class="attorney-section" id="case-history">
                    <h3><?php esc_html_e('Notable Case History', 'tanwar-associates'); ?></h3>
                    <p class="section-intro"><?php esc_html_e('A selection of significant cases handled, demonstrating expertise across various areas of law.', 'tanwar-associates'); ?></p>
                    
                    <div class="case-history-grid">
                        <?php foreach ($cases as $index => $case) : ?>
                        <div class="case-card" data-aos="fade-up" data-aos-delay="<?php echo $index * 100; ?>">
                            <div class="case-card-header">
                                <div class="case-outcome case-outcome-<?php echo strtolower(sanitize_title($case['outcome'])); ?>">
                                    <?php echo esc_html($case['outcome']); ?>
                                </div>
                                <span class="case-year"><?php echo esc_html($case['year']); ?></span>
                            </div>
                            <h4 class="case-title"><?php echo esc_html($case['title']); ?></h4>
                            <p class="case-description"><?php echo esc_html($case['description']); ?></p>
                            <div class="case-court">
                                <svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="3" y1="22" x2="21" y2="22"></line>
                                    <polygon points="12 2 20 7 4 7"></polygon>
                                </svg>
                                <span><?php echo esc_html($case['court']); ?></span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <p class="case-disclaimer">
                        <em><?php esc_html_e('* Case details are anonymized for client confidentiality. Outcomes depend on individual case circumstances.', 'tanwar-associates'); ?></em>
                    </p>
                </div>

                <!-- Contact Form -->
                <div class="attorney-section attorney-contact-section" id="contact-form">
                    <h3><?php printf(esc_html__('Consult with %s', 'tanwar-associates'), get_the_title()); ?></h3>
                    <p class="section-intro"><?php esc_html_e('Fill out the form below to schedule a consultation. All information is kept strictly confidential.', 'tanwar-associates'); ?></p>
                    
                    <form id="attorney-contact-form" class="attorney-form" novalidate>
                        <input type="hidden" name="attorney_name" value="<?php echo esc_attr(get_the_title()); ?>">
                        <input type="hidden" name="attorney_id" value="<?php echo esc_attr($attorney_id); ?>">
                        
                        <div class="form-row">
                            <div class="form-group">
                                <label for="contact-name"><?php esc_html_e('Full Name', 'tanwar-associates'); ?> <span class="required">*</span></label>
                                <input 
                                    type="text" 
                                    id="contact-name" 
                                    name="name" 
                                    class="form-control" 
                                    placeholder="<?php esc_attr_e('Enter your full name', 'tanwar-associates'); ?>"
                                    maxlength="100"
                                    pattern="^[a-zA-Z\s\.\-']+$"
                                    required
                                >
                                <span class="form-error" id="name-error"></span>
                            </div>
                            <div class="form-group">
                                <label for="contact-phone"><?php esc_html_e('Phone Number', 'tanwar-associates'); ?> <span class="required">*</span></label>
                                <input 
                                    type="tel" 
                                    id="contact-phone" 
                                    name="phone" 
                                    class="form-control" 
                                    placeholder="<?php esc_attr_e('+91 98765 43210', 'tanwar-associates'); ?>"
                                    maxlength="15"
                                    pattern="^[\+]?[0-9\s\-]{10,15}$"
                                    required
                                >
                                <span class="form-error" id="phone-error"></span>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="contact-email"><?php esc_html_e('Email Address', 'tanwar-associates'); ?> <span class="required">*</span></label>
                            <input 
                                type="email" 
                                id="contact-email" 
                                name="email" 
                                class="form-control" 
                                placeholder="<?php esc_attr_e('your.email@example.com', 'tanwar-associates'); ?>"
                                maxlength="255"
                                required
                            >
                            <span class="form-error" id="email-error"></span>
                        </div>

                        <div class="form-group">
                            <label for="contact-subject"><?php esc_html_e('Legal Matter Type', 'tanwar-associates'); ?></label>
                            <select id="contact-subject" name="subject" class="form-control">
                                <option value=""><?php esc_html_e('Select your legal matter', 'tanwar-associates'); ?></option>
                                <option value="Civil Litigation"><?php esc_html_e('Civil Litigation', 'tanwar-associates'); ?></option>
                                <option value="Criminal Law"><?php esc_html_e('Criminal Law', 'tanwar-associates'); ?></option>
                                <option value="Corporate Law"><?php esc_html_e('Corporate & Commercial Law', 'tanwar-associates'); ?></option>
                                <option value="Family Law"><?php esc_html_e('Family & Matrimonial Law', 'tanwar-associates'); ?></option>
                                <option value="Property Law"><?php esc_html_e('Property & Real Estate', 'tanwar-associates'); ?></option>
                                <option value="Cheque Bounce"><?php esc_html_e('Cheque Bounce (Section 138)', 'tanwar-associates'); ?></option>
                                <option value="Consumer Protection"><?php esc_html_e('Consumer Protection', 'tanwar-associates'); ?></option>
                                <option value="Labour Law"><?php esc_html_e('Labour & Employment Law', 'tanwar-associates'); ?></option>
                                <option value="Other"><?php esc_html_e('Other Legal Matter', 'tanwar-associates'); ?></option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label for="contact-message"><?php esc_html_e('Describe Your Legal Matter', 'tanwar-associates'); ?> <span class="required">*</span></label>
                            <textarea 
                                id="contact-message" 
                                name="message" 
                                class="form-control" 
                                rows="5" 
                                placeholder="<?php esc_attr_e('Please briefly describe your legal matter and how we can help...', 'tanwar-associates'); ?>"
                                maxlength="2000"
                                required
                            ></textarea>
                            <span class="form-error" id="message-error"></span>
                            <span class="char-count"><span id="message-count">0</span>/2000</span>
                        </div>

                        <div class="form-group form-checkbox">
                            <input type="checkbox" id="contact-consent" name="consent" required>
                            <label for="contact-consent">
                                <?php esc_html_e('I agree that my information will be used to contact me regarding my legal inquiry. All information is kept confidential.', 'tanwar-associates'); ?> <span class="required">*</span>
                            </label>
                            <span class="form-error" id="consent-error"></span>
                        </div>

                        <p class="form-disclaimer">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                            <?php esc_html_e('Your information is protected by advocate-client privilege and is kept strictly confidential.', 'tanwar-associates'); ?>
                        </p>

                        <button type="submit" class="btn btn-primary btn-lg" id="submit-btn">
                            <span class="btn-text"><?php esc_html_e('Send Consultation Request', 'tanwar-associates'); ?></span>
                            <span class="btn-loading" style="display: none;">
                                <svg class="spinner" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10" stroke-opacity="0.25"></circle>
                                    <path d="M12 2a10 10 0 0 1 10 10" stroke-linecap="round"></path>
                                </svg>
                                <?php esc_html_e('Sending...', 'tanwar-associates'); ?>
                            </span>
                        </button>
                        
                        <div id="form-success" class="form-message form-success" style="display: none;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                            <div>
                                <strong><?php esc_html_e('Thank you!', 'tanwar-associates'); ?></strong>
                                <p><?php esc_html_e('Your consultation request has been sent. We will contact you within 24 hours.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                        
                        <div id="form-error" class="form-message form-error-message" style="display: none;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <line x1="15" y1="9" x2="9" y2="15"></line>
                                <line x1="9" y1="9" x2="15" y2="15"></line>
                            </svg>
                            <div>
                                <strong><?php esc_html_e('Error', 'tanwar-associates'); ?></strong>
                                <p id="error-message"><?php esc_html_e('There was a problem sending your message. Please try again or call us directly.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Related Attorneys -->
<?php if (!empty($related_attorneys)) : ?>
<section class="section" style="background-color: var(--muted);">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle"><?php esc_html_e('Our Team', 'tanwar-associates'); ?></span>
            <h2 class="section-title"><?php esc_html_e('Other Advocates', 'tanwar-associates'); ?></h2>
        </div>
        
        <div class="team-grid team-grid-3">
            <?php foreach ($related_attorneys as $attorney) : 
                $atty_role = get_post_meta($attorney->ID, '_attorney_role', true) ?: 'Advocate';
                $atty_spec = get_post_meta($attorney->ID, '_attorney_specialization', true) ?: 'Legal Services';
            ?>
            <div class="team-card">
                <div class="team-card-image">
                    <?php if (has_post_thumbnail($attorney->ID)) : ?>
                        <?php echo get_the_post_thumbnail($attorney->ID, 'attorney-thumbnail'); ?>
                    <?php else : ?>
                        <img src="https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=500&fit=crop" alt="<?php echo esc_attr($attorney->post_title); ?>">
                    <?php endif; ?>
                    <div class="team-card-overlay">
                        <a href="<?php echo esc_url(get_permalink($attorney->ID)); ?>">
                            <?php esc_html_e('View Profile', 'tanwar-associates'); ?>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                                <polyline points="12 5 19 12 12 19"></polyline>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="team-card-body">
                    <h3 class="team-card-name"><?php echo esc_html($attorney->post_title); ?></h3>
                    <p class="team-card-role"><?php echo esc_html($atty_role); ?></p>
                    <p class="team-card-specialization"><?php echo esc_html($atty_spec); ?></p>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        
        <div style="text-align: center; margin-top: 2rem;">
            <a href="<?php echo esc_url(home_url('/team/')); ?>" class="btn btn-outline">
                <?php esc_html_e('View All Team Members', 'tanwar-associates'); ?>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <line x1="5" y1="12" x2="19" y2="12"></line>
                    <polyline points="12 5 19 12 12 19"></polyline>
                </svg>
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<?php get_template_part('template-parts/contact-cta'); ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('attorney-contact-form');
    const submitBtn = document.getElementById('submit-btn');
    const messageTextarea = document.getElementById('contact-message');
    const messageCount = document.getElementById('message-count');
    
    // Character counter
    if (messageTextarea && messageCount) {
        messageTextarea.addEventListener('input', function() {
            messageCount.textContent = this.value.length;
        });
    }
    
    // Form validation and submission
    if (form) {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Reset errors
            document.querySelectorAll('.form-error').forEach(el => el.textContent = '');
            document.querySelectorAll('.form-control').forEach(el => el.classList.remove('error'));
            
            // Get form values
            const name = document.getElementById('contact-name').value.trim();
            const phone = document.getElementById('contact-phone').value.trim();
            const email = document.getElementById('contact-email').value.trim();
            const message = document.getElementById('contact-message').value.trim();
            const consent = document.getElementById('contact-consent').checked;
            
            let hasErrors = false;
            
            // Validate name (letters, spaces, dots, hyphens, apostrophes only)
            if (!name) {
                document.getElementById('name-error').textContent = '<?php esc_html_e('Please enter your name', 'tanwar-associates'); ?>';
                document.getElementById('contact-name').classList.add('error');
                hasErrors = true;
            } else if (name.length > 100) {
                document.getElementById('name-error').textContent = '<?php esc_html_e('Name must be less than 100 characters', 'tanwar-associates'); ?>';
                document.getElementById('contact-name').classList.add('error');
                hasErrors = true;
            } else if (!/^[a-zA-Z\s\.\-']+$/.test(name)) {
                document.getElementById('name-error').textContent = '<?php esc_html_e('Name contains invalid characters', 'tanwar-associates'); ?>';
                document.getElementById('contact-name').classList.add('error');
                hasErrors = true;
            }
            
            // Validate phone (10-15 digits, may include + and spaces)
            if (!phone) {
                document.getElementById('phone-error').textContent = '<?php esc_html_e('Please enter your phone number', 'tanwar-associates'); ?>';
                document.getElementById('contact-phone').classList.add('error');
                hasErrors = true;
            } else if (!/^[\+]?[0-9\s\-]{10,15}$/.test(phone)) {
                document.getElementById('phone-error').textContent = '<?php esc_html_e('Please enter a valid phone number', 'tanwar-associates'); ?>';
                document.getElementById('contact-phone').classList.add('error');
                hasErrors = true;
            }
            
            // Validate email
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!email) {
                document.getElementById('email-error').textContent = '<?php esc_html_e('Please enter your email', 'tanwar-associates'); ?>';
                document.getElementById('contact-email').classList.add('error');
                hasErrors = true;
            } else if (!emailRegex.test(email) || email.length > 255) {
                document.getElementById('email-error').textContent = '<?php esc_html_e('Please enter a valid email address', 'tanwar-associates'); ?>';
                document.getElementById('contact-email').classList.add('error');
                hasErrors = true;
            }
            
            // Validate message
            if (!message) {
                document.getElementById('message-error').textContent = '<?php esc_html_e('Please describe your legal matter', 'tanwar-associates'); ?>';
                document.getElementById('contact-message').classList.add('error');
                hasErrors = true;
            } else if (message.length > 2000) {
                document.getElementById('message-error').textContent = '<?php esc_html_e('Message must be less than 2000 characters', 'tanwar-associates'); ?>';
                document.getElementById('contact-message').classList.add('error');
                hasErrors = true;
            }
            
            // Validate consent
            if (!consent) {
                document.getElementById('consent-error').textContent = '<?php esc_html_e('Please agree to the terms', 'tanwar-associates'); ?>';
                hasErrors = true;
            }
            
            if (hasErrors) {
                return;
            }
            
            // Show loading state
            submitBtn.disabled = true;
            submitBtn.querySelector('.btn-text').style.display = 'none';
            submitBtn.querySelector('.btn-loading').style.display = 'inline-flex';
            
            // Prepare form data
            const formData = new FormData(form);
            formData.append('action', 'tanwar_contact_form');
            formData.append('nonce', tanwarAjax.nonce);
            
            // Submit via AJAX
            fetch(tanwarAjax.ajaxUrl, {
                method: 'POST',
                body: formData,
                credentials: 'same-origin'
            })
            .then(response => response.json())
            .then(data => {
                submitBtn.disabled = false;
                submitBtn.querySelector('.btn-text').style.display = 'inline';
                submitBtn.querySelector('.btn-loading').style.display = 'none';
                
                if (data.success) {
                    document.getElementById('form-success').style.display = 'flex';
                    document.getElementById('form-error').style.display = 'none';
                    form.reset();
                    messageCount.textContent = '0';
                } else {
                    document.getElementById('error-message').textContent = data.data.message || '<?php esc_html_e('An error occurred. Please try again.', 'tanwar-associates'); ?>';
                    document.getElementById('form-error').style.display = 'flex';
                    document.getElementById('form-success').style.display = 'none';
                }
            })
            .catch(error => {
                submitBtn.disabled = false;
                submitBtn.querySelector('.btn-text').style.display = 'inline';
                submitBtn.querySelector('.btn-loading').style.display = 'none';
                document.getElementById('form-error').style.display = 'flex';
                document.getElementById('form-success').style.display = 'none';
            });
        });
    }
});
</script>

<?php } // End Elementor check ?>

<?php get_footer(); ?>
