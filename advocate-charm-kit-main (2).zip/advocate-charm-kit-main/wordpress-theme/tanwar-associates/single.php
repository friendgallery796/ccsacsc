<?php
/**
 * Single Post Template - Blog Article
 * Fully Elementor Editable
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if page is built with Elementor or if Elementor Theme Builder single template exists
if (function_exists('elementor_theme_do_location') && elementor_theme_do_location('single')) {
    // Elementor Theme Builder handles the single post template
} elseif (class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID())) {
    // Individual post built with Elementor
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
} else {
    // Default theme content

// Get post data
$post_id = get_the_ID();
$categories = get_the_category();
$tags = get_the_tags();
$author_id = get_the_author_meta('ID');
$author_name = get_the_author();
$author_bio = get_the_author_meta('description');
$author_avatar = get_avatar_url($author_id, array('size' => 100));

// Reading time estimate
$content = get_the_content();
$word_count = str_word_count(strip_tags($content));
$reading_time = ceil($word_count / 200);

// Related posts
$related_posts = array();
if (!empty($categories)) {
    $category_ids = wp_list_pluck($categories, 'term_id');
    $related_posts = get_posts(array(
        'post_type'      => 'post',
        'posts_per_page' => 3,
        'post__not_in'   => array($post_id),
        'category__in'   => $category_ids,
        'orderby'        => 'rand',
    ));
}

// Previous and next posts
$prev_post = get_previous_post();
$next_post = get_next_post();
?>

<article class="single-post" id="post-<?php the_ID(); ?>">
    <!-- Post Header -->
    <header class="post-header">
        <div class="container">
            <nav class="breadcrumbs">
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'tanwar-associates'); ?></a>
                <span>/</span>
                <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts')) ?: home_url('/blog/')); ?>"><?php esc_html_e('Blog', 'tanwar-associates'); ?></a>
                <span>/</span>
                <?php if (!empty($categories)) : ?>
                    <a href="<?php echo esc_url(get_category_link($categories[0]->term_id)); ?>"><?php echo esc_html($categories[0]->name); ?></a>
                    <span>/</span>
                <?php endif; ?>
                <span><?php echo wp_trim_words(get_the_title(), 5, '...'); ?></span>
            </nav>

            <div class="post-header-content">
                <?php if (!empty($categories)) : ?>
                <div class="post-categories">
                    <?php foreach ($categories as $cat) : ?>
                        <a href="<?php echo esc_url(get_category_link($cat->term_id)); ?>" class="post-category-tag">
                            <?php echo esc_html($cat->name); ?>
                        </a>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <h1 class="post-title"><?php the_title(); ?></h1>

                <?php if (has_excerpt()) : ?>
                <p class="post-excerpt"><?php echo get_the_excerpt(); ?></p>
                <?php endif; ?>

                <div class="post-meta">
                    <div class="post-author-info">
                        <img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr($author_name); ?>" class="post-author-avatar">
                        <div>
                            <span class="post-author-name"><?php echo esc_html($author_name); ?></span>
                            <span class="post-date"><?php echo get_the_date(); ?></span>
                        </div>
                    </div>
                    <div class="post-stats">
                        <span class="post-reading-time">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                            <?php printf(esc_html__('%d min read', 'tanwar-associates'), $reading_time); ?>
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Featured Image -->
    <?php if (has_post_thumbnail()) : ?>
    <div class="post-featured-image">
        <div class="container container-wide">
            <?php the_post_thumbnail('hero-image', array('alt' => get_the_title())); ?>
        </div>
    </div>
    <?php endif; ?>

    <!-- Post Content -->
    <div class="post-content-wrapper">
        <div class="container">
            <div class="post-layout">
                <!-- Share Sidebar (Desktop) -->
                <aside class="post-share-sidebar">
                    <div class="share-sticky">
                        <span class="share-label"><?php esc_html_e('Share', 'tanwar-associates'); ?></span>
                        <div class="share-buttons-vertical">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="noopener noreferrer" class="share-btn share-facebook" aria-label="Share on Facebook">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                                </svg>
                            </a>
                            <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>" target="_blank" rel="noopener noreferrer" class="share-btn share-twitter" aria-label="Share on Twitter">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                                </svg>
                            </a>
                            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(get_permalink()); ?>&title=<?php echo urlencode(get_the_title()); ?>" target="_blank" rel="noopener noreferrer" class="share-btn share-linkedin" aria-label="Share on LinkedIn">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                                    <rect x="2" y="9" width="4" height="12"></rect>
                                    <circle cx="4" cy="4" r="2"></circle>
                                </svg>
                            </a>
                            <a href="https://api.whatsapp.com/send?text=<?php echo urlencode(get_the_title() . ' ' . get_permalink()); ?>" target="_blank" rel="noopener noreferrer" class="share-btn share-whatsapp" aria-label="Share on WhatsApp">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                                </svg>
                            </a>
                            <button class="share-btn share-copy" onclick="copyToClipboard()" aria-label="Copy link">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"></path>
                                    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </aside>

                <!-- Main Content -->
                <div class="post-content">
                    <?php 
                    if (have_posts()) : 
                        while (have_posts()) : the_post();
                            the_content();
                        endwhile;
                    endif;
                    ?>

                    <!-- Tags -->
                    <?php if (!empty($tags)) : ?>
                    <div class="post-tags">
                        <span class="tags-label"><?php esc_html_e('Tags:', 'tanwar-associates'); ?></span>
                        <?php foreach ($tags as $tag) : ?>
                            <a href="<?php echo esc_url(get_tag_link($tag->term_id)); ?>" class="tag-link">
                                <?php echo esc_html($tag->name); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                    <!-- Share (Mobile) -->
                    <div class="post-share-mobile">
                        <span class="share-label"><?php esc_html_e('Share this article', 'tanwar-associates'); ?></span>
                        <div class="share-buttons-horizontal">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo urlencode(get_permalink()); ?>" target="_blank" rel="noopener noreferrer" class="share-btn share-facebook">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                                </svg>
                                Facebook
                            </a>
                            <a href="https://twitter.com/intent/tweet?url=<?php echo urlencode(get_permalink()); ?>&text=<?php echo urlencode(get_the_title()); ?>" target="_blank" rel="noopener noreferrer" class="share-btn share-twitter">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                                </svg>
                                Twitter
                            </a>
                            <a href="https://www.linkedin.com/shareArticle?mini=true&url=<?php echo urlencode(get_permalink()); ?>&title=<?php echo urlencode(get_the_title()); ?>" target="_blank" rel="noopener noreferrer" class="share-btn share-linkedin">
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                                    <rect x="2" y="9" width="4" height="12"></rect>
                                    <circle cx="4" cy="4" r="2"></circle>
                                </svg>
                                LinkedIn
                            </a>
                        </div>
                    </div>

                    <!-- Author Box -->
                    <div class="author-box">
                        <img src="<?php echo esc_url($author_avatar); ?>" alt="<?php echo esc_attr($author_name); ?>" class="author-box-avatar">
                        <div class="author-box-content">
                            <span class="author-box-label"><?php esc_html_e('Written by', 'tanwar-associates'); ?></span>
                            <h4 class="author-box-name"><?php echo esc_html($author_name); ?></h4>
                            <?php if ($author_bio) : ?>
                                <p class="author-box-bio"><?php echo esc_html($author_bio); ?></p>
                            <?php else : ?>
                                <p class="author-box-bio"><?php esc_html_e('Legal professional at Tanwar & Associates with expertise in providing insightful legal content and updates.', 'tanwar-associates'); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Post Navigation -->
                    <nav class="post-navigation">
                        <?php if ($prev_post) : ?>
                        <a href="<?php echo esc_url(get_permalink($prev_post->ID)); ?>" class="post-nav-link post-nav-prev">
                            <span class="post-nav-label">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="15 18 9 12 15 6"></polyline>
                                </svg>
                                <?php esc_html_e('Previous Article', 'tanwar-associates'); ?>
                            </span>
                            <span class="post-nav-title"><?php echo esc_html(wp_trim_words($prev_post->post_title, 8, '...')); ?></span>
                        </a>
                        <?php else : ?>
                        <div class="post-nav-link post-nav-empty"></div>
                        <?php endif; ?>

                        <?php if ($next_post) : ?>
                        <a href="<?php echo esc_url(get_permalink($next_post->ID)); ?>" class="post-nav-link post-nav-next">
                            <span class="post-nav-label">
                                <?php esc_html_e('Next Article', 'tanwar-associates'); ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                            </span>
                            <span class="post-nav-title"><?php echo esc_html(wp_trim_words($next_post->post_title, 8, '...')); ?></span>
                        </a>
                        <?php endif; ?>
                    </nav>
                </div>

                <!-- Table of Contents Sidebar -->
                <aside class="post-toc-sidebar">
                    <div class="toc-sticky">
                        <h4><?php esc_html_e('In This Article', 'tanwar-associates'); ?></h4>
                        <nav class="toc-nav" id="toc-nav">
                            <!-- Generated by JavaScript -->
                        </nav>
                        
                        <div class="toc-cta">
                            <p><?php esc_html_e('Need legal assistance?', 'tanwar-associates'); ?></p>
                            <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-sm w-full">
                                <?php esc_html_e('Free Consultation', 'tanwar-associates'); ?>
                            </a>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </div>

    <!-- Related Posts -->
    <?php if (!empty($related_posts)) : ?>
    <section class="related-posts-section">
        <div class="container">
            <div class="section-header">
                <h2 class="section-title"><?php esc_html_e('Related Articles', 'tanwar-associates'); ?></h2>
                <a href="<?php echo esc_url(get_permalink(get_option('page_for_posts')) ?: home_url('/blog/')); ?>" class="view-all-link">
                    <?php esc_html_e('View All', 'tanwar-associates'); ?>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <line x1="5" y1="12" x2="19" y2="12"></line>
                        <polyline points="12 5 19 12 12 19"></polyline>
                    </svg>
                </a>
            </div>
            
            <div class="related-posts-grid">
                <?php foreach ($related_posts as $related) : 
                    $related_cats = get_the_category($related->ID);
                ?>
                <article class="related-post-card">
                    <a href="<?php echo esc_url(get_permalink($related->ID)); ?>" class="related-post-image">
                        <?php if (has_post_thumbnail($related->ID)) : ?>
                            <?php echo get_the_post_thumbnail($related->ID, 'medium_large'); ?>
                        <?php else : ?>
                            <div class="related-post-image-placeholder">
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
                                    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path>
                                    <polyline points="14 2 14 8 20 8"></polyline>
                                </svg>
                            </div>
                        <?php endif; ?>
                    </a>
                    <div class="related-post-content">
                        <?php if (!empty($related_cats)) : ?>
                        <a href="<?php echo esc_url(get_category_link($related_cats[0]->term_id)); ?>" class="related-post-category">
                            <?php echo esc_html($related_cats[0]->name); ?>
                        </a>
                        <?php endif; ?>
                        <h3 class="related-post-title">
                            <a href="<?php echo esc_url(get_permalink($related->ID)); ?>">
                                <?php echo esc_html($related->post_title); ?>
                            </a>
                        </h3>
                        <span class="related-post-date"><?php echo get_the_date('', $related->ID); ?></span>
                    </div>
                </article>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php endif; ?>
</article>

<?php get_template_part('template-parts/contact-cta'); ?>

<script>
// Copy to clipboard function
function copyToClipboard() {
    const url = window.location.href;
    navigator.clipboard.writeText(url).then(function() {
        const btn = document.querySelector('.share-copy');
        btn.classList.add('copied');
        setTimeout(function() {
            btn.classList.remove('copied');
        }, 2000);
    });
}

// Generate Table of Contents
document.addEventListener('DOMContentLoaded', function() {
    const content = document.querySelector('.post-content');
    const tocNav = document.getElementById('toc-nav');
    
    if (content && tocNav) {
        const headings = content.querySelectorAll('h2, h3');
        
        if (headings.length > 0) {
            const tocList = document.createElement('ul');
            
            headings.forEach(function(heading, index) {
                // Add ID to heading if not present
                if (!heading.id) {
                    heading.id = 'section-' + index;
                }
                
                const li = document.createElement('li');
                li.className = heading.tagName === 'H3' ? 'toc-item toc-item-sub' : 'toc-item';
                
                const link = document.createElement('a');
                link.href = '#' + heading.id;
                link.textContent = heading.textContent;
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    heading.scrollIntoView({ behavior: 'smooth', block: 'start' });
                });
                
                li.appendChild(link);
                tocList.appendChild(li);
            });
            
            tocNav.appendChild(tocList);
        } else {
            // Hide TOC if no headings
            document.querySelector('.post-toc-sidebar').style.display = 'none';
        }
    }
});
</script>

<?php } // End Elementor check ?>

<?php get_footer(); ?>
