/**
 * Animations JavaScript for Tanwar & Associates Theme
 */
(function() {
    'use strict';

    // Intersection Observer for scroll animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in-up');
                entry.target.style.opacity = '1';
                observer.unobserve(entry.target);
            }
        });
    }, observerOptions);

    // Observe elements
    document.querySelectorAll('.card, .practice-area-card, .team-card, .stat-item, .feature-item, .section-header').forEach(el => {
        el.style.opacity = '0';
        observer.observe(el);
    });

    // Counter animation for statistics
    function animateCounter(el) {
        const target = parseInt(el.textContent.replace(/[^0-9]/g, ''));
        const suffix = el.textContent.replace(/[0-9]/g, '');
        const duration = 2000;
        const start = 0;
        const startTime = performance.now();

        function update(currentTime) {
            const elapsed = currentTime - startTime;
            const progress = Math.min(elapsed / duration, 1);
            const easeProgress = 1 - Math.pow(1 - progress, 3);
            const current = Math.floor(start + (target - start) * easeProgress);
            
            el.textContent = current.toLocaleString('en-IN') + suffix;
            
            if (progress < 1) {
                requestAnimationFrame(update);
            }
        }
        
        requestAnimationFrame(update);
    }

    // Observe stat values for counter animation
    const statObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                animateCounter(entry.target);
                statObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });

    document.querySelectorAll('.stat-value, .hero-stat-value').forEach(el => {
        statObserver.observe(el);
    });

    // Testimonials slider
    const track = document.getElementById('testimonials-track');
    const dots = document.querySelectorAll('.slider-dot');
    let currentSlide = 0;
    let autoSlideInterval;

    function goToSlide(index) {
        if (!track) return;
        const cards = track.querySelectorAll('.testimonial-card');
        if (cards.length === 0) return;
        
        currentSlide = index;
        const offset = window.innerWidth >= 1024 ? 33.333 : (window.innerWidth >= 768 ? 50 : 100);
        track.style.transform = `translateX(-${currentSlide * offset}%)`;
        
        dots.forEach((dot, i) => {
            dot.classList.toggle('active', i === currentSlide);
        });
    }

    function nextSlide() {
        const maxSlide = window.innerWidth >= 1024 ? 2 : (window.innerWidth >= 768 ? 3 : 4);
        goToSlide((currentSlide + 1) % (maxSlide + 1));
    }

    function startAutoSlide() {
        autoSlideInterval = setInterval(nextSlide, 5000);
    }

    function stopAutoSlide() {
        clearInterval(autoSlideInterval);
    }

    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            stopAutoSlide();
            goToSlide(index);
            startAutoSlide();
        });
    });

    if (track) {
        startAutoSlide();
        track.addEventListener('mouseenter', stopAutoSlide);
        track.addEventListener('mouseleave', startAutoSlide);
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href === '#') return;
            
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });

    // Parallax effect for hero
    window.addEventListener('scroll', () => {
        const hero = document.querySelector('.hero');
        if (hero) {
            const scrolled = window.pageYOffset;
            hero.style.backgroundPositionY = scrolled * 0.5 + 'px';
        }
    });

})();
