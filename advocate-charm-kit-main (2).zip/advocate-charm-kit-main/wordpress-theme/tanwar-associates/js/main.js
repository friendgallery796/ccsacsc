/**
 * Main JavaScript for Tanwar & Associates Theme
 */
(function($) {
    'use strict';

    // Header scroll effect
    $(window).scroll(function() {
        $('#site-header').toggleClass('scrolled', $(this).scrollTop() > 50);
        $('#back-to-top').toggle($(this).scrollTop() > 300);
    });

    // Mobile menu toggle
    $('#mobile-menu-toggle').click(function() {
        $('#mobile-nav, #mobile-nav-overlay').addClass('open');
        $('body').css('overflow', 'hidden');
    });

    $('#mobile-nav-close, #mobile-nav-overlay').click(function() {
        $('#mobile-nav, #mobile-nav-overlay').removeClass('open');
        $('body').css('overflow', '');
    });

    // Back to top
    $('#back-to-top').click(function() {
        $('html, body').animate({scrollTop: 0}, 500);
    });

    // Contact form AJAX
    $('#contact-form').submit(function(e) {
        e.preventDefault();
        var $form = $(this), $btn = $form.find('button[type="submit"]');
        
        $.ajax({
            url: tanwarData.ajaxUrl,
            type: 'POST',
            data: $form.serialize() + '&action=tanwar_contact_form&nonce=' + tanwarData.nonce,
            beforeSend: function() { $btn.prop('disabled', true).text('Sending...'); },
            success: function(res) {
                alert(res.data.message);
                if (res.success) $form[0].reset();
            },
            complete: function() { $btn.prop('disabled', false).text('Send Message'); }
        });
    });

})(jQuery);
