/**
 * Tanwar Associates - Elementor Widgets JavaScript
 */

(function($) {
    'use strict';

    // Testimonials Carousel
    function initTestimonialsCarousel() {
        $('.tanwar-testimonials-carousel').each(function() {
            var $carousel = $(this);
            var $slides = $carousel.find('.testimonial-slide');
            var $dots = $carousel.find('.dot');
            var $prevBtn = $carousel.find('.nav-prev');
            var $nextBtn = $carousel.find('.nav-next');
            var currentIndex = 0;
            var totalSlides = $slides.length;
            var autoplay = $carousel.data('autoplay') === 'yes';
            var speed = parseInt($carousel.data('speed')) || 5000;
            var autoplayTimer;

            function showSlide(index) {
                if (index >= totalSlides) index = 0;
                if (index < 0) index = totalSlides - 1;
                
                $slides.removeClass('active');
                $dots.removeClass('active');
                
                $slides.eq(index).addClass('active');
                $dots.eq(index).addClass('active');
                
                currentIndex = index;
            }

            function nextSlide() {
                showSlide(currentIndex + 1);
            }

            function prevSlide() {
                showSlide(currentIndex - 1);
            }

            function startAutoplay() {
                if (autoplay && totalSlides > 1) {
                    autoplayTimer = setInterval(nextSlide, speed);
                }
            }

            function stopAutoplay() {
                if (autoplayTimer) {
                    clearInterval(autoplayTimer);
                }
            }

            // Event handlers
            $nextBtn.on('click', function() {
                stopAutoplay();
                nextSlide();
                startAutoplay();
            });

            $prevBtn.on('click', function() {
                stopAutoplay();
                prevSlide();
                startAutoplay();
            });

            $dots.on('click', function() {
                var index = $(this).data('index');
                stopAutoplay();
                showSlide(index);
                startAutoplay();
            });

            // Pause on hover
            $carousel.on('mouseenter', stopAutoplay);
            $carousel.on('mouseleave', startAutoplay);

            // Initialize
            startAutoplay();
        });
    }

    // Statistics Counter Animation
    function initStatisticsCounter() {
        var animated = [];

        function animateCounter($element) {
            var $counter = $element.find('.counter');
            var target = parseInt($counter.data('target'));
            var duration = 2000;
            var start = 0;
            var startTime = null;

            function easeOutQuart(t) {
                return 1 - Math.pow(1 - t, 4);
            }

            function updateCounter(timestamp) {
                if (!startTime) startTime = timestamp;
                var progress = Math.min((timestamp - startTime) / duration, 1);
                var easedProgress = easeOutQuart(progress);
                var currentValue = Math.floor(easedProgress * target);
                
                $counter.text(currentValue.toLocaleString());
                
                if (progress < 1) {
                    requestAnimationFrame(updateCounter);
                } else {
                    $counter.text(target.toLocaleString());
                }
            }

            requestAnimationFrame(updateCounter);
        }

        function checkVisibility() {
            $('.statistic-item[data-animate="true"]').each(function() {
                var $item = $(this);
                var elementId = $item.closest('.tanwar-statistics-section').attr('id') || Math.random();
                
                if (animated.indexOf(elementId) !== -1) return;

                var elementTop = $item.offset().top;
                var elementBottom = elementTop + $item.outerHeight();
                var viewportTop = $(window).scrollTop();
                var viewportBottom = viewportTop + $(window).height();

                if (elementBottom > viewportTop && elementTop < viewportBottom) {
                    animated.push(elementId);
                    $item.closest('.tanwar-statistics-section').find('.statistic-item[data-animate="true"]').each(function() {
                        animateCounter($(this));
                    });
                }
            });
        }

        $(window).on('scroll', checkVisibility);
        checkVisibility();
    }

    // Contact Form AJAX
    function initContactForm() {
        $('.tanwar-contact-form').on('submit', function(e) {
            e.preventDefault();

            var $form = $(this);
            var $submitBtn = $form.find('button[type="submit"]');
            var $successMsg = $form.find('.form-message.success');
            var $errorMsg = $form.find('.form-message.error');
            var originalBtnText = $submitBtn.html();

            // Reset messages
            $successMsg.hide();
            $errorMsg.hide();

            // Disable button
            $submitBtn.prop('disabled', true).html('Sending...');

            $.ajax({
                url: tanwarData.ajaxUrl,
                type: 'POST',
                data: $form.serialize(),
                success: function(response) {
                    if (response.success) {
                        $successMsg.show();
                        $form[0].reset();
                    } else {
                        $errorMsg.text(response.data.message || 'An error occurred.').show();
                    }
                },
                error: function() {
                    $errorMsg.text('An error occurred. Please try again.').show();
                },
                complete: function() {
                    $submitBtn.prop('disabled', false).html(originalBtnText);
                }
            });
        });
    }

    // Initialize on document ready
    $(document).ready(function() {
        initTestimonialsCarousel();
        initStatisticsCounter();
        initContactForm();
    });

    // Reinitialize on Elementor frontend init
    $(window).on('elementor/frontend/init', function() {
        if (typeof elementorFrontend !== 'undefined') {
            elementorFrontend.hooks.addAction('frontend/element_ready/global', function() {
                initTestimonialsCarousel();
                initStatisticsCounter();
                initContactForm();
            });
        }
    });

})(jQuery);