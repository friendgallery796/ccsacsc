</main><!-- End Main Content -->

<?php
/**
 * Elementor Theme Builder Footer Location
 * 
 * If Elementor Pro is active and a custom footer template is assigned,
 * it will be displayed here. Otherwise, the default theme footer is used.
 */
if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('footer')) :
?>

<!-- Footer -->
<footer class="site-footer">
    <div class="container">
        <div class="footer-grid">
            <!-- About Column -->
            <div class="footer-about">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
                    <span class="site-logo-text">
                        Tanwar <span>&</span> Associates
                    </span>
                </a>
                <p>
                    <?php echo esc_html(tanwar_get_option('footer_about', 'A leading law firm in Jaipur, Rajasthan with expertise in civil, criminal, corporate, and family law. Practicing at Rajasthan High Court and all district courts.')); ?>
                </p>
                <div class="footer-social">
                    <?php
                    $social_links = tanwar_get_social_links();
                    if (!empty($social_links['facebook'])) :
                    ?>
                        <a href="<?php echo esc_url($social_links['facebook']); ?>" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                            </svg>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($social_links['twitter'])) : ?>
                        <a href="<?php echo esc_url($social_links['twitter']); ?>" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path>
                            </svg>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($social_links['linkedin'])) : ?>
                        <a href="<?php echo esc_url($social_links['linkedin']); ?>" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path>
                                <rect x="2" y="9" width="4" height="12"></rect>
                                <circle cx="4" cy="4" r="2"></circle>
                            </svg>
                        </a>
                    <?php endif; ?>

                    <?php if (!empty($social_links['instagram'])) : ?>
                        <a href="<?php echo esc_url($social_links['instagram']); ?>" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                            </svg>
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Quick Links -->
            <div class="footer-column">
                <h4 class="footer-heading"><?php esc_html_e('Quick Links', 'tanwar-associates'); ?></h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/about/')); ?>"><?php esc_html_e('About Us', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/practice-areas/')); ?>"><?php esc_html_e('Practice Areas', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/team/')); ?>"><?php esc_html_e('Our Team', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/contact/')); ?>"><?php esc_html_e('Contact', 'tanwar-associates'); ?></a></li>
                </ul>
            </div>

            <!-- Practice Areas -->
            <div class="footer-column">
                <h4 class="footer-heading"><?php esc_html_e('Practice Areas', 'tanwar-associates'); ?></h4>
                <ul class="footer-links">
                    <li><a href="<?php echo esc_url(home_url('/practice-areas/civil-litigation/')); ?>"><?php esc_html_e('Civil Litigation', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/practice-areas/criminal-law/')); ?>"><?php esc_html_e('Criminal Law', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/practice-areas/corporate-law/')); ?>"><?php esc_html_e('Corporate Law', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/practice-areas/family-law/')); ?>"><?php esc_html_e('Family Law', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/practice-areas/property-law/')); ?>"><?php esc_html_e('Property Law', 'tanwar-associates'); ?></a></li>
                    <li><a href="<?php echo esc_url(home_url('/practice-areas/nclt-matters/')); ?>"><?php esc_html_e('NCLT Matters', 'tanwar-associates'); ?></a></li>
                </ul>
            </div>

            <!-- Contact Info -->
            <div class="footer-column">
                <h4 class="footer-heading"><?php esc_html_e('Contact Us', 'tanwar-associates'); ?></h4>
                
                <div class="footer-contact-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path>
                        <circle cx="12" cy="10" r="3"></circle>
                    </svg>
                    <span>
                        <?php echo nl2br(esc_html(tanwar_get_option('address', "Chamber No. 123, High Court Premises\nJaipur, Rajasthan 302001\nIndia"))); ?>
                    </span>
                </div>

                <div class="footer-contact-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                    </svg>
                    <a href="tel:<?php echo esc_attr(tanwar_format_phone(tanwar_get_option('phone', '+91 98290 12345'))); ?>">
                        <?php echo esc_html(tanwar_get_option('phone', '+91 98290 12345')); ?>
                    </a>
                </div>

                <div class="footer-contact-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                        <polyline points="22,6 12,13 2,6"></polyline>
                    </svg>
                    <a href="mailto:<?php echo esc_attr(tanwar_get_option('email', 'info@tanwarassociates.com')); ?>">
                        <?php echo esc_html(tanwar_get_option('email', 'info@tanwarassociates.com')); ?>
                    </a>
                </div>

                <div class="footer-contact-item">
                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <circle cx="12" cy="12" r="10"></circle>
                        <polyline points="12 6 12 12 16 14"></polyline>
                    </svg>
                    <span>
                        <?php echo esc_html(tanwar_get_option('office_hours', 'Mon - Sat: 9:00 AM - 6:00 PM')); ?>
                    </span>
                </div>
            </div>
        </div>

        <!-- Footer Bottom -->
        <div class="footer-bottom">
            <div class="footer-bottom-inner">
                <p class="footer-copyright">
                    &copy; <?php echo date('Y'); ?> <?php echo esc_html(tanwar_get_option('firm_name', 'Tanwar & Associates')); ?>. 
                    <?php esc_html_e('All rights reserved.', 'tanwar-associates'); ?>
                </p>
                <p class="footer-disclaimer">
                    <?php esc_html_e('Disclaimer: This website is meant only for informational purposes and is compliant with the rules framed by the Bar Council of India under the Advocates Act, 1961. The information contained herein shall not constitute solicitation or advertisement.', 'tanwar-associates'); ?>
                </p>
            </div>
        </div>
    </div>
</footer>

<?php endif; // End Elementor footer check ?>

<!-- Back to Top Button -->
<button class="back-to-top" id="back-to-top" aria-label="<?php esc_attr_e('Back to top', 'tanwar-associates'); ?>" style="display: none; position: fixed; bottom: 2rem; right: 2rem; width: 50px; height: 50px; background-color: var(--accent); border: none; border-radius: 50%; cursor: pointer; z-index: 999; box-shadow: 0 4px 15px rgba(0,0,0,0.2); transition: all 0.3s ease;">
    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="display: block; margin: auto;">
        <polyline points="18 15 12 9 6 15"></polyline>
    </svg>
</button>

<?php wp_footer(); ?>

</body>
</html>
