<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    
    <!-- SEO Meta Tags -->
    <meta name="description" content="<?php echo esc_attr(tanwar_get_option('meta_description', 'Tanwar & Associates - Leading law firm in Jaipur, Rajasthan providing expert legal services in civil, criminal, corporate, family and property law. Practicing at Rajasthan High Court.')); ?>">
    <meta name="keywords" content="<?php echo esc_attr(tanwar_get_option('meta_keywords', 'lawyer jaipur, advocate rajasthan, high court lawyer, legal services jaipur, tanwar associates, best lawyer jaipur')); ?>">
    <meta name="author" content="Tanwar & Associates">
    <meta name="robots" content="index, follow">
    
    <!-- Favicon -->
    <?php if (has_site_icon()) : ?>
        <?php wp_site_icon(); ?>
    <?php else : ?>
        <link rel="icon" type="image/x-icon" href="<?php echo TANWAR_URI; ?>/images/favicon.ico">
    <?php endif; ?>
    
    <!-- Preconnect to Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- Skip to content link for accessibility -->
<a class="skip-link screen-reader-text" href="#main-content">
    <?php esc_html_e('Skip to content', 'tanwar-associates'); ?>
</a>

<?php
/**
 * Elementor Theme Builder Header Location
 * 
 * If Elementor Pro is active and a custom header template is assigned,
 * it will be displayed here. Otherwise, the default theme header is used.
 */
if (!function_exists('elementor_theme_do_location') || !elementor_theme_do_location('header')) :
?>

<!-- Header -->
<header class="site-header" id="site-header">
    <div class="container">
        <div class="header-inner">
            <!-- Logo -->
            <a href="<?php echo esc_url(home_url('/')); ?>" class="site-logo">
                <?php if (has_custom_logo()) : ?>
                    <?php the_custom_logo(); ?>
                <?php else : ?>
                    <span class="site-logo-text">
                        Tanwar <span>&</span> Associates
                    </span>
                <?php endif; ?>
            </a>

            <!-- Main Navigation -->
            <nav class="main-nav" role="navigation" aria-label="<?php esc_attr_e('Primary Navigation', 'tanwar-associates'); ?>">
                <?php
                wp_nav_menu(array(
                    'theme_location' => 'primary',
                    'menu_class'     => '',
                    'container'      => false,
                    'items_wrap'     => '%3$s',
                    'walker'         => new Tanwar_Nav_Walker(),
                    'fallback_cb'    => function() {
                        ?>
                        <a href="<?php echo esc_url(home_url('/')); ?>" class="<?php echo is_front_page() ? 'active' : ''; ?>">Home</a>
                        <a href="<?php echo esc_url(home_url('/practice-areas/')); ?>" class="<?php echo is_page('practice-areas') ? 'active' : ''; ?>">Practice Areas</a>
                        <a href="<?php echo esc_url(home_url('/team/')); ?>" class="<?php echo is_page('team') ? 'active' : ''; ?>">Our Team</a>
                        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="<?php echo is_page('contact') ? 'active' : ''; ?>">Contact</a>
                        <?php
                    },
                ));
                ?>
                <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary">
                    Free Consultation
                </a>
            </nav>

            <!-- Mobile Menu Toggle -->
            <button class="mobile-menu-toggle" id="mobile-menu-toggle" aria-label="<?php esc_attr_e('Toggle mobile menu', 'tanwar-associates'); ?>" aria-expanded="false">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </div>
</header>

<!-- Mobile Navigation Overlay -->
<div class="mobile-nav-overlay" id="mobile-nav-overlay"></div>

<!-- Mobile Navigation -->
<nav class="mobile-nav" id="mobile-nav" role="navigation" aria-label="<?php esc_attr_e('Mobile Navigation', 'tanwar-associates'); ?>">
    <button class="mobile-nav-close" id="mobile-nav-close" aria-label="<?php esc_attr_e('Close mobile menu', 'tanwar-associates'); ?>">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <line x1="18" y1="6" x2="6" y2="18"></line>
            <line x1="6" y1="6" x2="18" y2="18"></line>
        </svg>
    </button>

    <div class="site-logo" style="margin-bottom: 2rem;">
        <span class="site-logo-text">
            Tanwar <span>&</span> Associates
        </span>
    </div>

    <ul>
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'menu_class'     => '',
            'container'      => false,
            'items_wrap'     => '%3$s',
            'fallback_cb'    => function() {
                ?>
                <li><a href="<?php echo esc_url(home_url('/')); ?>">Home</a></li>
                <li><a href="<?php echo esc_url(home_url('/practice-areas/')); ?>">Practice Areas</a></li>
                <li><a href="<?php echo esc_url(home_url('/team/')); ?>">Our Team</a></li>
                <li><a href="<?php echo esc_url(home_url('/contact/')); ?>">Contact</a></li>
                <?php
            },
        ));
        ?>
    </ul>

    <div style="margin-top: 2rem;">
        <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary w-full">
            Free Consultation
        </a>
    </div>

    <!-- Mobile Contact Info -->
    <div style="margin-top: 2rem; padding-top: 2rem; border-top: 1px solid rgba(255,255,255,0.1);">
        <p style="color: rgba(255,255,255,0.7); font-size: 0.875rem; margin-bottom: 0.5rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 0.5rem;">
                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
            </svg>
            <?php echo esc_html(tanwar_get_option('phone', '+91 98290 12345')); ?>
        </p>
        <p style="color: rgba(255,255,255,0.7); font-size: 0.875rem;">
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 0.5rem;">
                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                <polyline points="22,6 12,13 2,6"></polyline>
            </svg>
            <?php echo esc_html(tanwar_get_option('email', 'info@tanwarassociates.com')); ?>
        </p>
    </div>
</nav>

<?php endif; // End Elementor header check ?>

<!-- Main Content -->
<main id="main-content" class="site-main">
