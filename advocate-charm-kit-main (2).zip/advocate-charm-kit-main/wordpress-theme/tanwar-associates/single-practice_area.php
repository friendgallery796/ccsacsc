<?php
/**
 * Single Practice Area Template
 * Fully Elementor Editable
 *
 * @package Tanwar_Associates
 */

get_header();

// Check if Elementor Theme Builder handles this template
if (function_exists('elementor_theme_do_location') && elementor_theme_do_location('single')) {
    // Elementor Theme Builder single template
} elseif (class_exists('\Elementor\Plugin') && \Elementor\Plugin::$instance->db->is_built_with_elementor(get_the_ID())) {
    // Individual practice area built with Elementor
    while (have_posts()) :
        the_post();
        the_content();
    endwhile;
} else {
    // Default theme content

// Get practice area meta
$icon = get_post_meta(get_the_ID(), '_practice_area_icon', true);
$services_raw = get_post_meta(get_the_ID(), '_practice_area_services', true);
$services = !empty($services_raw) ? array_filter(array_map('trim', explode("\n", $services_raw))) : array();

// Default services if none set
if (empty($services)) {
    $services = array(
        'Legal Consultation',
        'Case Analysis & Strategy',
        'Document Drafting',
        'Court Representation',
        'Appeals & Revisions',
        'Settlement Negotiations'
    );
}

// Related practice areas
$related_areas = get_posts(array(
    'post_type'      => 'practice_area',
    'posts_per_page' => 3,
    'post__not_in'   => array(get_the_ID()),
    'orderby'        => 'rand',
));
?>

<div class="page-hero practice-area-hero">
    <div class="container">
        <div class="page-hero-content">
            <nav class="breadcrumbs">
                <a href="<?php echo esc_url(home_url('/')); ?>"><?php esc_html_e('Home', 'tanwar-associates'); ?></a>
                <span>/</span>
                <a href="<?php echo esc_url(home_url('/practice-areas/')); ?>"><?php esc_html_e('Practice Areas', 'tanwar-associates'); ?></a>
                <span>/</span>
                <span><?php the_title(); ?></span>
            </nav>
            <div class="practice-area-hero-icon">
                <?php echo tanwar_get_practice_icon($icon); ?>
            </div>
            <h1><?php the_title(); ?></h1>
            <?php if (has_excerpt()) : ?>
                <p><?php echo get_the_excerpt(); ?></p>
            <?php else : ?>
                <p><?php esc_html_e('Expert legal representation and comprehensive services for all your legal needs.', 'tanwar-associates'); ?></p>
            <?php endif; ?>
        </div>
    </div>
</div>

<section class="section">
    <div class="container">
        <div class="practice-area-layout">
            <!-- Main Content -->
            <div class="practice-area-main">
                <!-- Overview -->
                <div class="practice-area-section">
                    <h2><?php esc_html_e('Overview', 'tanwar-associates'); ?></h2>
                    <div class="practice-area-content">
                        <?php 
                        if (have_posts()) : 
                            while (have_posts()) : the_post();
                                the_content();
                            endwhile;
                        endif;
                        
                        // Default content if empty
                        if (empty(get_the_content())) :
                        ?>
                            <p><?php printf(esc_html__('At Tanwar & Associates, our %s practice is dedicated to providing comprehensive legal solutions tailored to your specific needs. Our experienced advocates bring decades of combined experience to every case, ensuring you receive the highest quality representation.', 'tanwar-associates'), get_the_title()); ?></p>
                            
                            <p><?php esc_html_e('We understand that legal matters can be complex and stressful. That\'s why we take the time to thoroughly understand your situation, explain your options in clear terms, and develop a strategic approach designed to achieve the best possible outcome.', 'tanwar-associates'); ?></p>
                            
                            <p><?php esc_html_e('Our team regularly appears before the Rajasthan High Court, District Courts, and various tribunals, giving us deep insight into local legal procedures and practices. This experience allows us to navigate the legal system efficiently on your behalf.', 'tanwar-associates'); ?></p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Services We Offer -->
                <div class="practice-area-section">
                    <h2><?php esc_html_e('Services We Offer', 'tanwar-associates'); ?></h2>
                    <div class="services-grid">
                        <?php foreach ($services as $service) : ?>
                        <div class="service-item">
                            <div class="service-item-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="20 6 9 17 4 12"></polyline>
                                </svg>
                            </div>
                            <span><?php echo esc_html($service); ?></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Our Approach -->
                <div class="practice-area-section">
                    <h2><?php esc_html_e('Our Approach', 'tanwar-associates'); ?></h2>
                    <div class="approach-steps">
                        <div class="approach-step">
                            <div class="approach-step-number">1</div>
                            <div class="approach-step-content">
                                <h4><?php esc_html_e('Initial Consultation', 'tanwar-associates'); ?></h4>
                                <p><?php esc_html_e('We begin with a thorough discussion of your case to understand all aspects and evaluate the legal options available to you.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                        <div class="approach-step">
                            <div class="approach-step-number">2</div>
                            <div class="approach-step-content">
                                <h4><?php esc_html_e('Case Analysis', 'tanwar-associates'); ?></h4>
                                <p><?php esc_html_e('Our team conducts detailed research and analysis of applicable laws, precedents, and facts to build a strong foundation for your case.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                        <div class="approach-step">
                            <div class="approach-step-number">3</div>
                            <div class="approach-step-content">
                                <h4><?php esc_html_e('Strategy Development', 'tanwar-associates'); ?></h4>
                                <p><?php esc_html_e('We develop a customized legal strategy aligned with your goals, considering all possible outcomes and approaches.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                        <div class="approach-step">
                            <div class="approach-step-number">4</div>
                            <div class="approach-step-content">
                                <h4><?php esc_html_e('Representation & Resolution', 'tanwar-associates'); ?></h4>
                                <p><?php esc_html_e('We represent you vigorously in court or negotiations, keeping you informed at every step until your matter is resolved.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Why Choose Us -->
                <div class="practice-area-section">
                    <h2><?php printf(esc_html__('Why Choose Us for %s', 'tanwar-associates'), get_the_title()); ?></h2>
                    <div class="why-choose-grid">
                        <div class="why-choose-item">
                            <div class="why-choose-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                    <polyline points="22 4 12 14.01 9 11.01"></polyline>
                                </svg>
                            </div>
                            <h4><?php esc_html_e('Proven Track Record', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Successful outcomes in numerous cases at High Court and District Courts.', 'tanwar-associates'); ?></p>
                        </div>
                        <div class="why-choose-item">
                            <div class="why-choose-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <circle cx="12" cy="12" r="10"></circle>
                                    <polyline points="12 6 12 12 16 14"></polyline>
                                </svg>
                            </div>
                            <h4><?php esc_html_e('Timely Updates', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Regular communication on case progress and upcoming court dates.', 'tanwar-associates'); ?></p>
                        </div>
                        <div class="why-choose-item">
                            <div class="why-choose-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                    <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                                </svg>
                            </div>
                            <h4><?php esc_html_e('Confidentiality', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Complete discretion and protection of client information.', 'tanwar-associates'); ?></p>
                        </div>
                        <div class="why-choose-item">
                            <div class="why-choose-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="12" y1="1" x2="12" y2="23"></line>
                                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                                </svg>
                            </div>
                            <h4><?php esc_html_e('Transparent Fees', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Clear fee structure with no hidden costs or surprises.', 'tanwar-associates'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- FAQs -->
                <div class="practice-area-section">
                    <h2><?php esc_html_e('Frequently Asked Questions', 'tanwar-associates'); ?></h2>
                    <div class="faq-accordion">
                        <div class="faq-item">
                            <button class="faq-question" aria-expanded="false">
                                <span><?php esc_html_e('How long does a typical case take?', 'tanwar-associates'); ?></span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="6 9 12 15 18 9"></polyline>
                                </svg>
                            </button>
                            <div class="faq-answer">
                                <p><?php esc_html_e('Case duration varies depending on complexity, court workload, and whether parties are willing to settle. Simple matters may resolve in months, while complex litigation can take several years. We provide realistic timelines during your initial consultation.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question" aria-expanded="false">
                                <span><?php esc_html_e('What documents do I need to bring for consultation?', 'tanwar-associates'); ?></span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="6 9 12 15 18 9"></polyline>
                                </svg>
                            </button>
                            <div class="faq-answer">
                                <p><?php esc_html_e('Please bring all relevant documents such as agreements, correspondence, court notices, previous orders, identity proof, and any other papers related to your matter. The more information you provide, the better we can assess your case.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question" aria-expanded="false">
                                <span><?php esc_html_e('Do you offer payment plans?', 'tanwar-associates'); ?></span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="6 9 12 15 18 9"></polyline>
                                </svg>
                            </button>
                            <div class="faq-answer">
                                <p><?php esc_html_e('Yes, we understand that legal services can be a significant investment. We offer flexible payment arrangements for eligible cases. Please discuss your requirements during the consultation, and we will try to accommodate your situation.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question" aria-expanded="false">
                                <span><?php esc_html_e('Can you represent me in courts outside Jaipur?', 'tanwar-associates'); ?></span>
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="6 9 12 15 18 9"></polyline>
                                </svg>
                            </button>
                            <div class="faq-answer">
                                <p><?php esc_html_e('Yes, our advocates regularly appear in courts across Rajasthan including all district courts, the Jodhpur bench of High Court, and even the Supreme Court in New Delhi. We also have a network of associate advocates in other states if needed.', 'tanwar-associates'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Sidebar -->
            <aside class="practice-area-sidebar">
                <!-- Quick Contact Card -->
                <div class="sidebar-card">
                    <h3><?php esc_html_e('Need Legal Help?', 'tanwar-associates'); ?></h3>
                    <p><?php esc_html_e('Get expert advice on your legal matter. Schedule a consultation today.', 'tanwar-associates'); ?></p>
                    
                    <div class="sidebar-contact-info">
                        <a href="tel:<?php echo esc_attr(tanwar_format_phone(tanwar_get_option('phone', '+91 98290 12345'))); ?>" class="sidebar-contact-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                            </svg>
                            <span><?php echo esc_html(tanwar_get_option('phone', '+91 98290 12345')); ?></span>
                        </a>
                        <a href="mailto:<?php echo esc_attr(tanwar_get_option('email', 'info@tanwarassociates.com')); ?>" class="sidebar-contact-link">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path>
                                <polyline points="22,6 12,13 2,6"></polyline>
                            </svg>
                            <span><?php echo esc_html(tanwar_get_option('email', 'info@tanwarassociates.com')); ?></span>
                        </a>
                    </div>
                    
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary w-full">
                        <?php esc_html_e('Book Consultation', 'tanwar-associates'); ?>
                    </a>
                </div>

                <!-- Office Hours -->
                <div class="sidebar-card">
                    <h4><?php esc_html_e('Office Hours', 'tanwar-associates'); ?></h4>
                    <ul class="office-hours-list">
                        <li>
                            <span><?php esc_html_e('Monday - Friday', 'tanwar-associates'); ?></span>
                            <span>9:00 AM - 6:00 PM</span>
                        </li>
                        <li>
                            <span><?php esc_html_e('Saturday', 'tanwar-associates'); ?></span>
                            <span>9:00 AM - 2:00 PM</span>
                        </li>
                        <li>
                            <span><?php esc_html_e('Sunday', 'tanwar-associates'); ?></span>
                            <span><?php esc_html_e('By Appointment', 'tanwar-associates'); ?></span>
                        </li>
                    </ul>
                </div>

                <!-- Related Practice Areas -->
                <?php if (!empty($related_areas)) : ?>
                <div class="sidebar-card">
                    <h4><?php esc_html_e('Related Practice Areas', 'tanwar-associates'); ?></h4>
                    <ul class="related-areas-list">
                        <?php foreach ($related_areas as $area) : ?>
                        <li>
                            <a href="<?php echo esc_url(get_permalink($area->ID)); ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <polyline points="9 18 15 12 9 6"></polyline>
                                </svg>
                                <?php echo esc_html($area->post_title); ?>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                    <a href="<?php echo esc_url(home_url('/practice-areas/')); ?>" class="view-all-link">
                        <?php esc_html_e('View All Practice Areas', 'tanwar-associates'); ?>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="5" y1="12" x2="19" y2="12"></line>
                            <polyline points="12 5 19 12 12 19"></polyline>
                        </svg>
                    </a>
                </div>
                <?php endif; ?>

                <!-- Free Resources -->
                <div class="sidebar-card sidebar-card-highlight">
                    <h4><?php esc_html_e('Free Legal Resources', 'tanwar-associates'); ?></h4>
                    <p><?php esc_html_e('Download our free guide to understanding your legal rights.', 'tanwar-associates'); ?></p>
                    <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-outline w-full">
                        <?php esc_html_e('Get Free Guide', 'tanwar-associates'); ?>
                    </a>
                </div>
            </aside>
        </div>
    </div>
</section>

<?php get_template_part('template-parts/contact-cta'); ?>

<?php } // End Elementor check ?>

<?php get_footer(); ?>

<?php
/**
 * Helper function to get practice area icon SVG
 */
function tanwar_get_practice_icon($icon = 'scale') {
    $icons = array(
        'scale' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="12" y1="3" x2="12" y2="21"></line><polyline points="8 8 12 4 16 8"></polyline><path d="M1 14s2-1 4-1 4 1 4 1"></path><path d="M15 14s2-1 4-1 4 1 4 1"></path><path d="M1 14l4 7h-4"></path><path d="M23 14l-4 7h4"></path></svg>',
        'shield' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>',
        'building' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="4" y="2" width="16" height="20" rx="2" ry="2"></rect><path d="M9 22v-4h6v4"></path><path d="M8 6h.01"></path><path d="M16 6h.01"></path><path d="M12 6h.01"></path><path d="M12 10h.01"></path><path d="M12 14h.01"></path><path d="M16 10h.01"></path><path d="M16 14h.01"></path><path d="M8 10h.01"></path><path d="M8 14h.01"></path></svg>',
        'users' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>',
        'home' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>',
        'file-text' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>',
        'briefcase' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>',
        'shield-check' => '<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path><path d="M9 12l2 2 4-4"></path></svg>',
    );
    
    return isset($icons[$icon]) ? $icons[$icon] : $icons['scale'];
}
?>
