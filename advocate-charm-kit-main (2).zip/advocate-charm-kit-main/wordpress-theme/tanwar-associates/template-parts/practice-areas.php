<?php
/**
 * Practice Areas Template Part
 *
 * @package Tanwar_Associates
 */

$practice_areas = array(
    array('title' => 'Civil Litigation', 'desc' => 'Property disputes, contract matters, recovery suits, and injunctions.', 'icon' => 'scale'),
    array('title' => 'Criminal Law', 'desc' => 'Bail matters, trial defense, appeals at High Court and Supreme Court.', 'icon' => 'shield'),
    array('title' => 'Corporate & Commercial', 'desc' => 'Company formation, contracts, M&A, and business advisory.', 'icon' => 'building'),
    array('title' => 'Family & Matrimonial', 'desc' => 'Divorce, custody, maintenance, and domestic violence cases.', 'icon' => 'users'),
    array('title' => 'Property & Real Estate', 'desc' => 'Title verification, RERA matters, and property documentation.', 'icon' => 'home'),
    array('title' => 'Cheque Bounce (NI Act)', 'desc' => 'Section 138 cases, recovery proceedings, and settlements.', 'icon' => 'file-text'),
);
?>

<section class="practice-areas section">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle"><?php esc_html_e('Our Expertise', 'tanwar-associates'); ?></span>
            <h2 class="section-title"><?php esc_html_e('Practice Areas', 'tanwar-associates'); ?></h2>
            <p class="section-description"><?php esc_html_e('Comprehensive legal services tailored to protect your rights and interests.', 'tanwar-associates'); ?></p>
        </div>
        
        <div class="practice-areas-grid">
            <?php foreach ($practice_areas as $area) : ?>
            <div class="practice-area-card">
                <div class="practice-area-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/></svg>
                </div>
                <h3 class="practice-area-title"><?php echo esc_html($area['title']); ?></h3>
                <p class="practice-area-description"><?php echo esc_html($area['desc']); ?></p>
                <a href="#" class="practice-area-link">Learn More →</a>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
