<?php
/**
 * Why Choose Us Section Template Part
 *
 * @package Tanwar_Associates
 */
?>

<section class="why-choose-us section">
    <div class="container">
        <div class="why-choose-grid">
            <div class="why-choose-content">
                <span class="section-subtitle"><?php esc_html_e('Why Choose Us', 'tanwar-associates'); ?></span>
                <h2><?php esc_html_e('Trusted Legal Partners for Over 25 Years', 'tanwar-associates'); ?></h2>
                <p><?php esc_html_e('At Tanwar & Associates, we combine legal expertise with a client-first approach. Our team is committed to achieving the best possible outcomes for every case.', 'tanwar-associates'); ?></p>

                <div class="why-choose-features">
                    <div class="feature-item">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                                <polyline points="22 4 12 14.01 9 11.01"></polyline>
                            </svg>
                        </div>
                        <div class="feature-content">
                            <h4><?php esc_html_e('High Court Expertise', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Regular practice at Rajasthan High Court with proven track record in complex litigation.', 'tanwar-associates'); ?></p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                        </div>
                        <div class="feature-content">
                            <h4><?php esc_html_e('Timely Response', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('24-hour response time for urgent legal matters. We understand that time is critical.', 'tanwar-associates'); ?></p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect>
                                <path d="M7 11V7a5 5 0 0 1 10 0v4"></path>
                            </svg>
                        </div>
                        <div class="feature-content">
                            <h4><?php esc_html_e('Complete Confidentiality', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Your matters are handled with utmost discretion under advocate-client privilege.', 'tanwar-associates'); ?></p>
                        </div>
                    </div>

                    <div class="feature-item">
                        <div class="feature-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="12" y1="1" x2="12" y2="23"></line>
                                <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"></path>
                            </svg>
                        </div>
                        <div class="feature-content">
                            <h4><?php esc_html_e('Transparent Fees', 'tanwar-associates'); ?></h4>
                            <p><?php esc_html_e('Clear fee structure with no hidden costs. Free initial consultation for all matters.', 'tanwar-associates'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="why-choose-image">
                <img src="https://images.unsplash.com/photo-1589829545856-d10d557cf95f?w=600&h=800&fit=crop" alt="<?php esc_attr_e('Legal consultation at Tanwar Associates', 'tanwar-associates'); ?>">
            </div>
        </div>
    </div>
</section>
