<?php
/**
 * Testimonials Section Template Part
 *
 * @package Tanwar_Associates
 */

$testimonials = array(
    array(
        'name' => 'Mahesh Kumar Sharma',
        'role' => 'Business Owner, Jaipur',
        'text' => 'Tanwar & Associates handled my property dispute with exceptional professionalism. They secured a favorable judgment at the High Court within 8 months. Highly recommended for any civil matter.',
        'rating' => 5,
    ),
    array(
        'name' => 'Sunita Agarwal',
        'role' => 'Homemaker, Jodhpur',
        'text' => 'During my divorce proceedings, Adv. Priya Sharma was incredibly supportive and understanding. She fought for my rights and ensured fair custody arrangements for my children.',
        'rating' => 5,
    ),
    array(
        'name' => 'Rajendra Singh',
        'role' => 'Retired Government Officer',
        'text' => 'I had a complex inheritance dispute that had been ongoing for years. The team at Tanwar & Associates resolved it through mediation, saving us time and family relationships.',
        'rating' => 5,
    ),
    array(
        'name' => 'Vikram Joshi',
        'role' => 'Director, Tech Company',
        'text' => 'For all our corporate legal needs, we rely on Tanwar & Associates. Their expertise in NCLT matters and contract drafting has been invaluable to our business growth.',
        'rating' => 5,
    ),
    array(
        'name' => 'Priya Meena',
        'role' => 'Teacher, Jaipur',
        'text' => 'When I received a cheque bounce notice, I was worried. Adv. Sunita handled my case brilliantly and got the complaint dismissed. Very grateful for their help.',
        'rating' => 5,
    ),
);
?>

<section class="testimonials section">
    <div class="container">
        <div class="section-header">
            <span class="section-subtitle"><?php esc_html_e('Client Testimonials', 'tanwar-associates'); ?></span>
            <h2 class="section-title"><?php esc_html_e('What Our Clients Say', 'tanwar-associates'); ?></h2>
            <p class="section-description"><?php esc_html_e('Hear from clients who have trusted us with their legal matters.', 'tanwar-associates'); ?></p>
        </div>

        <div class="testimonials-slider">
            <div class="testimonials-track" id="testimonials-track">
                <?php foreach ($testimonials as $testimonial) : ?>
                <div class="testimonial-card">
                    <div class="testimonial-inner">
                        <div class="testimonial-quote">"</div>
                        <p class="testimonial-text"><?php echo esc_html($testimonial['text']); ?></p>
                        <div class="testimonial-author">
                            <div class="testimonial-avatar" style="width: 50px; height: 50px; background: var(--accent); border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 700; color: var(--accent-foreground);">
                                <?php echo esc_html(substr($testimonial['name'], 0, 1)); ?>
                            </div>
                            <div class="testimonial-info">
                                <h5><?php echo esc_html($testimonial['name']); ?></h5>
                                <p><?php echo esc_html($testimonial['role']); ?></p>
                                <div class="testimonial-stars">
                                    <?php for ($i = 0; $i < $testimonial['rating']; $i++) : ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2">
                                        <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
                                    </svg>
                                    <?php endfor; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="slider-dots" id="slider-dots">
            <?php for ($i = 0; $i < count($testimonials); $i++) : ?>
            <button class="slider-dot <?php echo $i === 0 ? 'active' : ''; ?>" data-index="<?php echo $i; ?>"></button>
            <?php endfor; ?>
        </div>
    </div>
</section>
