<?php
/**
 * Hero Section Template Part
 *
 * @package Tanwar_Associates
 */
?>

<section class="hero">
    <div class="container">
        <div class="hero-content animate-fade-in-up">
            <span class="hero-badge">
                ⚖️ <?php esc_html_e('Practicing at Rajasthan High Court', 'tanwar-associates'); ?>
            </span>
            
            <h1 class="hero-title">
                <?php esc_html_e('Trusted Legal Excellence for', 'tanwar-associates'); ?>
                <span><?php esc_html_e('Justice & Protection', 'tanwar-associates'); ?></span>
            </h1>
            
            <p class="hero-description">
                <?php esc_html_e('Tanwar & Associates provides expert legal representation across civil, criminal, corporate, and family law matters. With decades of combined experience at Rajasthan High Court and district courts.', 'tanwar-associates'); ?>
            </p>
            
            <div class="hero-buttons">
                <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">
                    <?php esc_html_e('Free Consultation', 'tanwar-associates'); ?>
                </a>
                <a href="tel:<?php echo esc_attr(tanwar_format_phone(tanwar_get_option('phone', '+919829012345'))); ?>" class="btn btn-secondary btn-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.127.96.361 1.903.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0 1 22 16.92z"></path>
                    </svg>
                    <?php esc_html_e('Call Now', 'tanwar-associates'); ?>
                </a>
            </div>
            
            <div class="hero-stats">
                <div class="hero-stat">
                    <div class="hero-stat-value">25+</div>
                    <div class="hero-stat-label"><?php esc_html_e('Years Experience', 'tanwar-associates'); ?></div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-value">5000+</div>
                    <div class="hero-stat-label"><?php esc_html_e('Cases Won', 'tanwar-associates'); ?></div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-value">₹50Cr+</div>
                    <div class="hero-stat-label"><?php esc_html_e('Client Recoveries', 'tanwar-associates'); ?></div>
                </div>
                <div class="hero-stat">
                    <div class="hero-stat-value">98%</div>
                    <div class="hero-stat-label"><?php esc_html_e('Success Rate', 'tanwar-associates'); ?></div>
                </div>
            </div>
        </div>
    </div>
</section>
