<?php
/**
 * Contact CTA Section Template Part
 *
 * @package Tanwar_Associates
 */
?>

<section class="contact-cta section">
    <div class="container">
        <div class="contact-cta-content">
            <h2><?php esc_html_e('Ready to Discuss Your Legal Matter?', 'tanwar-associates'); ?></h2>
            <p><?php esc_html_e('Schedule a free consultation with our experienced legal team. We are here to help you navigate your legal challenges with confidence.', 'tanwar-associates'); ?></p>
            
            <div class="contact-cta-buttons">
                <a href="<?php echo esc_url(home_url('/contact/')); ?>" class="btn btn-primary btn-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                    </svg>
                    <?php esc_html_e('Schedule Consultation', 'tanwar-associates'); ?>
                </a>
                
                <a href="tel:<?php echo esc_attr(tanwar_format_phone(tanwar_get_option('phone', '+919829012345'))); ?>" class="btn btn-outline btn-lg">
                    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                    </svg>
                    <?php echo esc_html(tanwar_get_option('phone', '+91 98290 12345')); ?>
                </a>
            </div>

            <p style="margin-top: 1.5rem; font-size: 0.875rem; color: var(--muted-foreground);">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: inline; vertical-align: middle; margin-right: 0.25rem;">
                    <circle cx="12" cy="12" r="10"></circle>
                    <polyline points="12 6 12 12 16 14"></polyline>
                </svg>
                <?php esc_html_e('Available Mon-Sat, 9 AM - 6 PM | Emergency support available', 'tanwar-associates'); ?>
            </p>
        </div>
    </div>
</section>
