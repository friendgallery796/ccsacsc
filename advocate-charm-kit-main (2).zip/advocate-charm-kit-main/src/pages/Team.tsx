import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { TeamHero } from "@/components/sections/TeamHero";
import { TeamGrid } from "@/components/sections/TeamGrid";
import { ContactCTA } from "@/components/sections/ContactCTA";

const Team = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <TeamHero />
        <TeamGrid />
        <ContactCTA />
      </main>
      <Footer />
    </div>
  );
};

export default Team;
