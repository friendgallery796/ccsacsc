import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { Hero } from "@/components/sections/Hero";
import { Statistics } from "@/components/sections/Statistics";
import { PracticeAreas } from "@/components/sections/PracticeAreas";
import { WhyChooseUs } from "@/components/sections/WhyChooseUs";
import { Testimonials } from "@/components/sections/Testimonials";
import { CaseCalculator } from "@/components/sections/CaseCalculator";
import { ConsultationForm } from "@/components/sections/ConsultationForm";
import { ContactCTA } from "@/components/sections/ContactCTA";
import { Toaster } from "@/components/ui/toaster";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <Hero />
        <Statistics />
        <PracticeAreas />
        <WhyChooseUs />
        <Testimonials />
        <CaseCalculator />
        <ConsultationForm />
        <ContactCTA />
      </main>
      <Footer />
      <Toaster />
    </div>
  );
};

export default Index;
