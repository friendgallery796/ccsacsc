import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { PracticeAreasHero } from "@/components/sections/PracticeAreasHero";
import { PracticeAreasGrid } from "@/components/sections/PracticeAreasGrid";
import { ContactCTA } from "@/components/sections/ContactCTA";

export default function PracticeAreas() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <PracticeAreasHero />
        <PracticeAreasGrid />
        <ContactCTA />
      </main>
      <Footer />
    </div>
  );
}
