import { useParams, Navigate } from "react-router-dom";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";
import { AttorneyBio } from "@/components/attorney/AttorneyBio";
import { AttorneyCaseHistory } from "@/components/attorney/AttorneyCaseHistory";
import { AttorneyContactForm } from "@/components/attorney/AttorneyContactForm";
import { getTeamMemberBySlug } from "@/data/teamMembers";

const AttorneyProfile = () => {
  const { slug } = useParams<{ slug: string }>();
  
  const attorney = slug ? getTeamMemberBySlug(slug) : undefined;

  if (!attorney) {
    return <Navigate to="/team" replace />;
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main>
        <AttorneyBio attorney={attorney} />
        
        <div className="container mx-auto px-4 pb-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
            {/* Case History */}
            <div className="lg:col-span-2">
              <AttorneyCaseHistory 
                cases={attorney.caseResults} 
                attorneyName={attorney.name} 
              />
            </div>

            {/* Contact Form */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <AttorneyContactForm
                  attorneyName={attorney.name}
                  attorneyEmail={attorney.email}
                />
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default AttorneyProfile;
