export interface CaseResult {
  id: number;
  title: string;
  court: string;
  year: string;
  outcome: string;
  description: string;
}

export interface TeamMember {
  id: number;
  slug: string;
  name: string;
  designation: string;
  qualifications: string;
  barCouncil: string;
  enrollmentYear: number;
  specializations: string[];
  bio: string;
  fullBio: string;
  phone: string;
  email: string;
  isPartner: boolean;
  education: string[];
  awards: string[];
  languages: string[];
  caseResults: CaseResult[];
}

export const teamMembers: TeamMember[] = [
  {
    id: 1,
    slug: "rajesh-kumar-tanwar",
    name: "Adv. Rajesh Kumar Tanwar",
    designation: "Founding Partner & Senior Advocate",
    qualifications: "B.A. LL.B., LL.M. (Constitutional Law)",
    barCouncil: "D/1234/1995",
    enrollmentYear: 1995,
    specializations: ["Constitutional Law", "Criminal Defense", "Supreme Court Practice"],
    bio: "With over 28 years of experience, Adv. Tanwar has argued numerous landmark cases before the Supreme Court and various High Courts. He is known for his expertise in constitutional matters and criminal defense.",
    fullBio: `Adv. Rajesh Kumar Tanwar is the founding partner of Tanwar & Associates, bringing over 28 years of distinguished legal practice to the firm. A graduate of Delhi University's prestigious Faculty of Law, he went on to complete his LL.M. in Constitutional Law from the National Law School of India University, Bangalore.

Throughout his illustrious career, Adv. Tanwar has argued numerous landmark cases before the Supreme Court of India and various High Courts across the country. His expertise in constitutional matters has earned him recognition as one of Delhi's leading constitutional lawyers.

He has been instrumental in shaping several significant judgments related to fundamental rights, administrative law, and criminal jurisprudence. His commitment to justice extends beyond the courtroom, as he regularly conducts legal awareness programs and pro bono work for underprivileged communities.

Adv. Tanwar is known for his meticulous preparation, persuasive advocacy, and unwavering commitment to his clients' causes. He has mentored numerous young lawyers who have gone on to become successful practitioners in their own right.`,
    phone: "+91 98765 43210",
    email: "rajesh.tanwar@tanwarassociates.in",
    isPartner: true,
    education: [
      "LL.M. (Constitutional Law) - NLSIU, Bangalore (1998)",
      "B.A. LL.B. - Delhi University (1995)",
      "Higher Secondary - St. Stephen's College, Delhi"
    ],
    awards: [
      "Best Advocate Award - Delhi High Court Bar Association (2018)",
      "Outstanding Contribution to Legal Aid - NALSA (2015)",
      "Distinguished Alumni Award - Delhi University (2012)"
    ],
    languages: ["Hindi", "English", "Punjabi"],
    caseResults: [
      {
        id: 1,
        title: "State vs. ABC Corporation",
        court: "Supreme Court of India",
        year: "2022",
        outcome: "Acquittal",
        description: "Successfully defended a major corporation against allegations of environmental violations, establishing important precedents for corporate liability."
      },
      {
        id: 2,
        title: "Sharma vs. Union of India",
        court: "Delhi High Court",
        year: "2021",
        outcome: "Favorable Judgment",
        description: "Landmark PIL challenging arbitrary government policy, resulting in policy amendment benefiting thousands of citizens."
      },
      {
        id: 3,
        title: "Criminal Appeal No. 456/2020",
        court: "Supreme Court of India",
        year: "2020",
        outcome: "Acquittal",
        description: "Secured acquittal for client wrongfully convicted in a high-profile criminal case after 5 years of litigation."
      }
    ]
  },
  {
    id: 2,
    slug: "priya-sharma",
    name: "Adv. Priya Sharma",
    designation: "Managing Partner",
    qualifications: "B.A. LL.B. (Hons.), LL.M. (Corporate Law)",
    barCouncil: "D/5678/2002",
    enrollmentYear: 2002,
    specializations: ["Corporate Law", "Mergers & Acquisitions", "NCLT Matters"],
    bio: "Adv. Priya Sharma leads our corporate practice with expertise in complex M&A transactions, NCLT proceedings, and corporate restructuring. She has advised numerous Fortune 500 companies.",
    fullBio: `Adv. Priya Sharma serves as the Managing Partner at Tanwar & Associates, overseeing the firm's corporate and commercial practice. With over two decades of experience, she has established herself as one of India's foremost corporate lawyers.

A gold medalist from the National Law University, Delhi, Adv. Sharma pursued her LL.M. in Corporate Law from the University of Cambridge, UK. Her international exposure and deep understanding of Indian corporate law make her the preferred advisor for multinational corporations entering the Indian market.

She has successfully handled some of the largest M&A transactions in India, including cross-border acquisitions, joint ventures, and corporate restructuring exercises. Her expertise in NCLT matters has helped numerous companies navigate complex insolvency proceedings.

Adv. Sharma is a regular speaker at corporate law seminars and has authored several articles in leading legal journals. She serves on the board of several non-profit organizations and is passionate about promoting women in legal profession.`,
    phone: "+91 98765 43211",
    email: "priya.sharma@tanwarassociates.in",
    isPartner: true,
    education: [
      "LL.M. (Corporate Law) - University of Cambridge, UK (2005)",
      "B.A. LL.B. (Hons.) - NLU Delhi, Gold Medalist (2002)",
      "Commerce Graduate - Lady Shri Ram College, Delhi"
    ],
    awards: [
      "Top 50 Women in Law - Legal Era Awards (2023)",
      "Best Corporate Lawyer - India Business Law Journal (2021)",
      "Young Achiever Award - Bar Council of Delhi (2010)"
    ],
    languages: ["Hindi", "English", "French"],
    caseResults: [
      {
        id: 1,
        title: "XYZ Ltd. Acquisition",
        court: "NCLT Mumbai",
        year: "2023",
        outcome: "Successful Completion",
        description: "Led a ₹2,500 crore cross-border acquisition of an Indian tech company by a US multinational, navigating complex regulatory approvals."
      },
      {
        id: 2,
        title: "Corporate Insolvency Resolution",
        court: "NCLT Delhi",
        year: "2022",
        outcome: "Successful Resolution",
        description: "Successfully represented resolution applicant in acquiring stressed assets worth ₹800 crores under IBC proceedings."
      },
      {
        id: 3,
        title: "Merger of ABC & DEF Companies",
        court: "NCLT Bangalore",
        year: "2021",
        outcome: "Approved",
        description: "Structured and executed a complex merger involving two listed companies with combined valuation of ₹5,000 crores."
      }
    ]
  },
  {
    id: 3,
    slug: "vikram-singh",
    name: "Adv. Vikram Singh",
    designation: "Senior Partner",
    qualifications: "B.Com., LL.B., LL.M. (Taxation)",
    barCouncil: "D/9012/2005",
    enrollmentYear: 2005,
    specializations: ["Tax Law", "GST", "Income Tax Tribunal"],
    bio: "Specializing in direct and indirect taxation, Adv. Vikram has successfully represented clients before ITAT and GST Appellate Tribunals. He advises on tax planning and dispute resolution.",
    fullBio: `Adv. Vikram Singh heads the taxation practice at Tanwar & Associates, bringing specialized expertise in both direct and indirect taxation. His unique combination of commerce and legal education provides him with a comprehensive understanding of tax matters.

After completing his B.Com. from Shri Ram College of Commerce and LL.B. from Delhi University, he pursued his LL.M. in Taxation from NALSAR University of Law. He has represented clients before the Income Tax Appellate Tribunal, GST Appellate Tribunal, and various High Courts in tax matters.

Adv. Singh has been instrumental in helping businesses navigate the transition to GST and has successfully resolved numerous complex tax disputes. His practice covers tax planning, tax litigation, transfer pricing, and international taxation.

He is a member of the Delhi Tax Bar Association and regularly contributes to tax journals. He has conducted numerous workshops on GST compliance for industry bodies and professional associations.`,
    phone: "+91 98765 43212",
    email: "vikram.singh@tanwarassociates.in",
    isPartner: true,
    education: [
      "LL.M. (Taxation) - NALSAR University of Law (2008)",
      "LL.B. - Delhi University (2005)",
      "B.Com. (Hons.) - SRCC, Delhi University (2002)"
    ],
    awards: [
      "Best Tax Advocate - DTBA Annual Awards (2022)",
      "Excellence in GST Practice - ICAI Recognition (2019)",
      "Rising Star in Tax Law - Legal500 (2015)"
    ],
    languages: ["Hindi", "English"],
    caseResults: [
      {
        id: 1,
        title: "Major IT Company vs. DCIT",
        court: "ITAT Delhi",
        year: "2023",
        outcome: "Relief Granted",
        description: "Secured ₹150 crore tax relief for a major IT company in transfer pricing dispute involving software development services."
      },
      {
        id: 2,
        title: "GST Refund Matter",
        court: "GST Appellate Tribunal",
        year: "2022",
        outcome: "Full Refund Ordered",
        description: "Successfully obtained ₹45 crore GST refund for an exporter wrongfully denied input tax credit."
      },
      {
        id: 3,
        title: "Assessment Challenge",
        court: "Delhi High Court",
        year: "2021",
        outcome: "Assessment Set Aside",
        description: "Challenged arbitrary income tax assessment, resulting in complete set aside of ₹200 crore demand."
      }
    ]
  },
  {
    id: 4,
    slug: "anita-deshmukh",
    name: "Adv. Anita Deshmukh",
    designation: "Senior Associate",
    qualifications: "B.A. LL.B. (Hons.), LL.M. (Family Law)",
    barCouncil: "MH/3456/2010",
    enrollmentYear: 2010,
    specializations: ["Family Law", "Matrimonial Disputes", "Child Custody"],
    bio: "Adv. Anita brings compassion and expertise to sensitive family matters. She has handled numerous divorce, maintenance, and child custody cases with a focus on mediation and amicable resolution.",
    fullBio: `Adv. Anita Deshmukh leads the family law practice at Tanwar & Associates, bringing a unique blend of legal expertise and emotional intelligence to sensitive family matters. Her approach emphasizes mediation and amicable resolution while being fully prepared for litigation when necessary.

A graduate of ILS Law College, Pune, she completed her LL.M. in Family Law from Mumbai University. She has handled hundreds of matrimonial cases including divorce, maintenance, child custody, and domestic violence matters.

Adv. Deshmukh is a trained mediator and believes in resolving family disputes through dialogue and negotiation wherever possible. She has been instrumental in establishing the firm's family law mediation center, which has successfully resolved numerous cases without protracted litigation.

She is actively involved in women's rights organizations and provides pro bono assistance to domestic violence survivors. She regularly conducts awareness sessions on women's legal rights in educational institutions.`,
    phone: "+91 98765 43213",
    email: "anita.deshmukh@tanwarassociates.in",
    isPartner: false,
    education: [
      "LL.M. (Family Law) - Mumbai University (2013)",
      "B.A. LL.B. (Hons.) - ILS Law College, Pune (2010)",
      "Certified Family Mediator - MCPC (2015)"
    ],
    awards: [
      "Champion for Women's Rights - NCW Recognition (2022)",
      "Best Family Lawyer - Maharashtra Bar Council (2020)",
      "Outstanding Pro Bono Service - Legal Aid Committee (2018)"
    ],
    languages: ["Hindi", "English", "Marathi"],
    caseResults: [
      {
        id: 1,
        title: "Complex Child Custody Matter",
        court: "Family Court, Delhi",
        year: "2023",
        outcome: "Joint Custody Ordered",
        description: "Successfully negotiated joint custody arrangement in a high-conflict international custody dispute, prioritizing child's welfare."
      },
      {
        id: 2,
        title: "Matrimonial Property Division",
        court: "Delhi High Court",
        year: "2022",
        outcome: "Favorable Settlement",
        description: "Secured fair division of ₹50 crore matrimonial assets for client in a complex divorce involving multiple properties and businesses."
      }
    ]
  },
  {
    id: 5,
    slug: "suresh-reddy",
    name: "Adv. Suresh Reddy",
    designation: "Senior Associate",
    qualifications: "B.Tech., LL.B., LL.M. (IPR)",
    barCouncil: "TS/7890/2012",
    enrollmentYear: 2012,
    specializations: ["Intellectual Property", "Patent Law", "Trademark Disputes"],
    bio: "With a unique combination of engineering and legal expertise, Adv. Suresh specializes in patent prosecution, trademark litigation, and technology transfer agreements.",
    fullBio: `Adv. Suresh Reddy brings a rare combination of technical and legal expertise to the firm's intellectual property practice. His engineering background provides him with the technical understanding essential for patent matters, particularly in the IT and pharmaceutical sectors.

After completing his B.Tech. in Computer Science from JNTU Hyderabad, he pursued law and obtained his LL.B. from Osmania University. He further specialized with an LL.M. in Intellectual Property Rights from NALSAR University of Law.

His practice encompasses all aspects of intellectual property law including patents, trademarks, copyrights, and trade secrets. He has successfully handled patent prosecution for major technology companies and has represented clients in high-stakes trademark infringement cases.

Adv. Reddy regularly advises startups on IP strategy and protection. He is a registered Patent Agent and a member of the Intellectual Property Attorneys Association.`,
    phone: "+91 98765 43214",
    email: "suresh.reddy@tanwarassociates.in",
    isPartner: false,
    education: [
      "LL.M. (IPR) - NALSAR University of Law (2015)",
      "LL.B. - Osmania University (2012)",
      "B.Tech. (Computer Science) - JNTU Hyderabad (2008)",
      "Registered Patent Agent - Indian Patent Office"
    ],
    awards: [
      "Best IP Lawyer Under 40 - IP India Awards (2023)",
      "Innovation in Legal Practice - Telangana Bar Council (2021)"
    ],
    languages: ["Hindi", "English", "Telugu"],
    caseResults: [
      {
        id: 1,
        title: "Patent Infringement Suit",
        court: "Delhi High Court",
        year: "2023",
        outcome: "Permanent Injunction Granted",
        description: "Secured permanent injunction against a major pharmaceutical company for patent infringement, protecting client's ₹200 crore drug patent."
      },
      {
        id: 2,
        title: "Trademark Opposition",
        court: "Trademark Registry",
        year: "2022",
        outcome: "Opposition Sustained",
        description: "Successfully opposed registration of a confusingly similar trademark, protecting client's established brand identity."
      }
    ]
  },
  {
    id: 6,
    slug: "neha-gupta",
    name: "Adv. Neha Gupta",
    designation: "Associate",
    qualifications: "B.A. LL.B. (Hons.)",
    barCouncil: "D/2345/2018",
    enrollmentYear: 2018,
    specializations: ["Civil Litigation", "Property Disputes", "Consumer Law"],
    bio: "Adv. Neha handles civil litigation matters including property disputes, contract breaches, and consumer complaints. She is known for her thorough research and persuasive arguments.",
    fullBio: `Adv. Neha Gupta is a skilled civil litigator specializing in property disputes, contract law, and consumer protection matters. Her attention to detail and thorough research skills have earned her recognition in the Delhi legal community.

A graduate of Amity Law School, Delhi, she joined Tanwar & Associates immediately after her enrollment and has grown into a capable advocate handling complex civil matters independently.

She has successfully represented clients in numerous property disputes, including title suits, partition matters, and specific performance cases. Her consumer law practice has helped individuals and businesses resolve disputes through consumer forums and commissions.

Adv. Gupta is passionate about access to justice and volunteers with legal aid clinics in Delhi. She is also pursuing a diploma in Alternative Dispute Resolution.`,
    phone: "+91 98765 43215",
    email: "neha.gupta@tanwarassociates.in",
    isPartner: false,
    education: [
      "B.A. LL.B. (Hons.) - Amity Law School, Delhi (2018)",
      "Diploma in ADR - Indian Institute of Arbitration (Pursuing)"
    ],
    awards: [
      "Best Junior Advocate - Delhi District Courts (2022)"
    ],
    languages: ["Hindi", "English"],
    caseResults: [
      {
        id: 1,
        title: "Property Title Dispute",
        court: "Delhi High Court",
        year: "2023",
        outcome: "Title Declared",
        description: "Successfully established client's title to prime commercial property in Delhi after 4-year litigation."
      },
      {
        id: 2,
        title: "Consumer Complaint",
        court: "State Consumer Commission",
        year: "2022",
        outcome: "Full Compensation Awarded",
        description: "Obtained ₹35 lakh compensation for deficiency in real estate developer's services."
      }
    ]
  },
  {
    id: 7,
    slug: "mohammed-farhan",
    name: "Adv. Mohammed Farhan",
    designation: "Associate",
    qualifications: "B.A. LL.B., LL.M. (Criminal Law)",
    barCouncil: "UP/6789/2019",
    enrollmentYear: 2019,
    specializations: ["Criminal Defense", "Bail Matters", "Trial Advocacy"],
    bio: "Adv. Farhan assists in criminal matters ranging from bail applications to full trials. He is dedicated to ensuring fair representation for all clients.",
    fullBio: `Adv. Mohammed Farhan is a dedicated criminal defense lawyer who believes strongly in the constitutional right to fair trial and legal representation. He handles the full spectrum of criminal matters from initial bail applications through trial and appeals.

A graduate of Aligarh Muslim University's prestigious law faculty, he pursued his LL.M. in Criminal Law from Jamia Millia Islamia. His academic excellence and courtroom presence have quickly established him as a rising star in criminal defense.

He works closely with the senior partners on complex criminal matters and has independently handled numerous sessions and magistrate court cases. His practice includes economic offenses, white-collar crimes, and general criminal defense.

Adv. Farhan is committed to legal aid and regularly takes up cases for underprivileged accused persons. He believes that everyone deserves competent legal representation regardless of their financial circumstances.`,
    phone: "+91 98765 43216",
    email: "farhan@tanwarassociates.in",
    isPartner: false,
    education: [
      "LL.M. (Criminal Law) - Jamia Millia Islamia (2021)",
      "B.A. LL.B. - Aligarh Muslim University (2019)"
    ],
    awards: [
      "Best Moot Court Advocate - AMU (2018)",
      "Legal Aid Excellence - DLSA Recognition (2023)"
    ],
    languages: ["Hindi", "English", "Urdu"],
    caseResults: [
      {
        id: 1,
        title: "Economic Offense Case",
        court: "Sessions Court, Delhi",
        year: "2023",
        outcome: "Acquittal",
        description: "Secured acquittal for businessman falsely accused of cheating, after thorough investigation revealed fabricated evidence."
      },
      {
        id: 2,
        title: "Bail in NDPS Matter",
        court: "Delhi High Court",
        year: "2022",
        outcome: "Bail Granted",
        description: "Obtained bail for first-time offender in NDPS case after being in custody for 8 months, on grounds of parity and medical issues."
      }
    ]
  },
  {
    id: 8,
    slug: "kavitha-nair",
    name: "Adv. Kavitha Nair",
    designation: "Associate",
    qualifications: "B.B.A. LL.B. (Hons.)",
    barCouncil: "KL/1234/2020",
    enrollmentYear: 2020,
    specializations: ["Banking Law", "SARFAESI", "Debt Recovery"],
    bio: "Adv. Kavitha specializes in banking and finance law, handling SARFAESI proceedings, DRT matters, and negotiable instruments cases for leading financial institutions.",
    fullBio: `Adv. Kavitha Nair specializes in banking and finance law, representing both financial institutions and borrowers in complex debt recovery and enforcement matters. Her practice covers the full spectrum of banking litigation.

A graduate of Government Law College, Thiruvananthapuram with a BBA LLB (Hons.) degree, she brings a strong understanding of business and finance to her legal practice. She joined Tanwar & Associates to build her expertise in Delhi's robust banking law ecosystem.

Her practice includes SARFAESI proceedings, DRT matters, negotiable instruments cases, and bank fraud litigation. She represents several leading public and private sector banks in their recovery proceedings.

Adv. Nair is known for her efficient handling of large volumes of banking cases while maintaining high success rates. She is currently pursuing a certification in Banking Law from the Indian Institute of Banking and Finance.`,
    phone: "+91 98765 43217",
    email: "kavitha.nair@tanwarassociates.in",
    isPartner: false,
    education: [
      "B.B.A. LL.B. (Hons.) - Government Law College, Thiruvananthapuram (2020)",
      "Certified Credit Professional - IIBF (Pursuing)"
    ],
    awards: [
      "Best All-Rounder - GLC Thiruvananthapuram (2020)"
    ],
    languages: ["Hindi", "English", "Malayalam", "Tamil"],
    caseResults: [
      {
        id: 1,
        title: "SARFAESI Recovery",
        court: "DRT Delhi",
        year: "2023",
        outcome: "Full Recovery",
        description: "Successfully recovered ₹15 crores for a PSU bank through SARFAESI proceedings against defaulting corporate borrower."
      },
      {
        id: 2,
        title: "Section 138 NI Act",
        court: "Metropolitan Magistrate Court",
        year: "2022",
        outcome: "Conviction & Recovery",
        description: "Obtained conviction and recovery order for ₹2.5 crores in a cheque bounce case involving multiple dishonored instruments."
      }
    ]
  }
];

export const getTeamMemberBySlug = (slug: string): TeamMember | undefined => {
  return teamMembers.find((member) => member.slug === slug);
};

export const getTeamMemberById = (id: number): TeamMember | undefined => {
  return teamMembers.find((member) => member.id === id);
};
