import { 
  Scale, 
  Gavel, 
  Building2, 
  Home, 
  ShoppingCart, 
  Heart, 
  ScrollText, 
  FileSearch, 
  Receipt, 
  MapPin, 
  Shield, 
  FileText,
  LucideIcon
} from "lucide-react";

export interface PracticeArea {
  id: string;
  slug: string;
  icon: LucideIcon;
  title: string;
  shortDescription: string;
  fullDescription: string;
  services: string[];
  relevantLaws: string[];
  tribunals?: string[];
  featured?: boolean;
}

export const practiceAreas: PracticeArea[] = [
  {
    id: "civil-litigation",
    slug: "civil-litigation",
    icon: Scale,
    title: "Civil Litigation",
    shortDescription: "Comprehensive civil dispute resolution including property matters, recovery suits, injunctions, and declaratory suits.",
    fullDescription: "Our civil litigation practice handles all aspects of civil disputes before the Rajasthan High Court and subordinate courts. We represent clients in complex property disputes, recovery suits, partition matters, specific performance cases, and declaratory suits with a track record of favorable outcomes.",
    services: [
      "Property dispute resolution",
      "Money recovery suits",
      "Partition suits",
      "Specific performance actions",
      "Declaratory suits",
      "Injunction applications",
      "Appeals and revisions"
    ],
    relevantLaws: [
      "Code of Civil Procedure, 1908 (CPC)",
      "Transfer of Property Act, 1882",
      "Specific Relief Act, 1963",
      "Limitation Act, 1963"
    ],
    tribunals: ["District Courts", "High Court", "Supreme Court"],
    featured: true
  },
  {
    id: "criminal-defense",
    slug: "criminal-defense",
    icon: Gavel,
    title: "Criminal Defense",
    shortDescription: "Expert criminal defense including bail matters, trials, and appeals for all categories of offenses.",
    fullDescription: "We provide vigorous criminal defense representation at all stages - from FIR to appeal. Our team handles regular and anticipatory bail applications, conducts robust trials, and pursues appeals in serious criminal matters including IPC offenses, NDPS cases, and white-collar crimes.",
    services: [
      "Regular & anticipatory bail",
      "Criminal trial defense",
      "Appeals & revisions",
      "Quashing petitions (Section 482 CrPC)",
      "NDPS case defense",
      "White-collar crime defense",
      "Victim representation"
    ],
    relevantLaws: [
      "Indian Penal Code, 1860 (IPC)",
      "Code of Criminal Procedure, 1973 (CrPC)",
      "Bharatiya Nyaya Sanhita, 2023",
      "NDPS Act, 1985",
      "Prevention of Corruption Act, 1988"
    ],
    tribunals: ["Sessions Courts", "High Court", "Supreme Court"],
    featured: true
  },
  {
    id: "nclt-insolvency",
    slug: "nclt-insolvency",
    icon: Building2,
    title: "NCLT & Insolvency",
    shortDescription: "Corporate disputes, insolvency resolution, and company law matters before the National Company Law Tribunal.",
    fullDescription: "Our specialized NCLT practice handles corporate insolvency resolution proceedings, oppression and mismanagement petitions, winding up applications, and scheme of arrangements. We represent corporate debtors, financial creditors, operational creditors, and resolution applicants.",
    services: [
      "Corporate Insolvency Resolution (CIRP)",
      "Personal Insolvency proceedings",
      "Oppression & mismanagement petitions",
      "Winding up petitions",
      "Scheme of arrangements",
      "Appeals before NCLAT"
    ],
    relevantLaws: [
      "Insolvency and Bankruptcy Code, 2016 (IBC)",
      "Companies Act, 2013",
      "Limited Liability Partnership Act, 2008"
    ],
    tribunals: ["NCLT Jaipur Bench", "NCLAT", "Supreme Court"],
    featured: true
  },
  {
    id: "rera-matters",
    slug: "rera-matters",
    icon: Home,
    title: "RERA Matters",
    shortDescription: "Builder-buyer disputes, project delays, refund claims, and regulatory compliance under RERA.",
    fullDescription: "We represent homebuyers in disputes against developers for project delays, possession issues, and refund claims before the Rajasthan Real Estate Regulatory Authority. We also advise developers on RERA compliance and registration requirements.",
    services: [
      "Refund claims for project delays",
      "Possession enforcement",
      "Interest compensation claims",
      "Developer compliance advisory",
      "RERA registration assistance",
      "Appellate Tribunal appeals"
    ],
    relevantLaws: [
      "Real Estate (Regulation and Development) Act, 2016",
      "Rajasthan RERA Rules, 2017"
    ],
    tribunals: ["Rajasthan RERA Authority", "RERA Appellate Tribunal", "High Court"]
  },
  {
    id: "consumer-protection",
    slug: "consumer-protection",
    icon: ShoppingCart,
    title: "Consumer Protection",
    shortDescription: "Consumer complaints for deficient services, defective products, and unfair trade practices.",
    fullDescription: "We file and defend consumer complaints before District, State, and National Consumer Disputes Redressal Commissions. Our practice covers complaints against hospitals, insurance companies, builders, e-commerce platforms, and service providers.",
    services: [
      "Consumer complaint filing",
      "Medical negligence claims",
      "Insurance claim disputes",
      "E-commerce disputes",
      "Banking & financial services complaints",
      "Defective product claims"
    ],
    relevantLaws: [
      "Consumer Protection Act, 2019",
      "Consumer Protection Rules, 2020"
    ],
    tribunals: ["District Consumer Forum", "State Consumer Commission", "NCDRC"]
  },
  {
    id: "matrimonial-family",
    slug: "matrimonial-family",
    icon: Heart,
    title: "Matrimonial & Family Law",
    shortDescription: "Divorce, maintenance, custody, domestic violence, and all family law matters with sensitivity.",
    fullDescription: "Our family law practice handles divorce proceedings (mutual and contested), maintenance claims, child custody disputes, domestic violence cases, and restitution of conjugal rights. We approach every case with compassion while protecting our clients' interests.",
    services: [
      "Divorce petitions (mutual & contested)",
      "Maintenance & alimony claims",
      "Child custody & visitation rights",
      "Domestic violence (DV Act) cases",
      "Restitution of conjugal rights",
      "Dowry harassment defense (498A)"
    ],
    relevantLaws: [
      "Hindu Marriage Act, 1955",
      "Special Marriage Act, 1954",
      "Protection of Women from Domestic Violence Act, 2005",
      "Hindu Adoption and Maintenance Act, 1956",
      "Guardians and Wards Act, 1890"
    ],
    tribunals: ["Family Courts", "High Court", "Supreme Court"],
    featured: true
  },
  {
    id: "constitutional-law",
    slug: "constitutional-law",
    icon: ScrollText,
    title: "Constitutional Law & Writs",
    shortDescription: "Writ petitions for fundamental rights, public interest litigation, and constitutional remedies.",
    fullDescription: "We file writ petitions under Articles 226 and 32 for enforcement of fundamental rights, challenge arbitrary government actions, and undertake public interest litigation. Our constitutional practice addresses issues of liberty, equality, and administrative law.",
    services: [
      "Writ petitions (Habeas Corpus, Mandamus, Certiorari)",
      "Public Interest Litigation (PIL)",
      "Fundamental rights enforcement",
      "Challenging government orders",
      "Service matters & disciplinary proceedings",
      "Administrative law disputes"
    ],
    relevantLaws: [
      "Constitution of India (Articles 14, 19, 21, 226, 32)",
      "Administrative law principles"
    ],
    tribunals: ["High Court", "Supreme Court"]
  },
  {
    id: "rti-transparency",
    slug: "rti-transparency",
    icon: FileSearch,
    title: "RTI & Transparency",
    shortDescription: "RTI applications, first and second appeals, and information disclosure matters.",
    fullDescription: "We assist citizens in exercising their right to information through properly drafted RTI applications, first appeals to designated authorities, and second appeals before the State/Central Information Commission. We also defend public authorities in RTI proceedings.",
    services: [
      "RTI application drafting",
      "First appeals to appellate authority",
      "Second appeals to Information Commission",
      "Complaints for RTI Act violations",
      "Defense of public authorities"
    ],
    relevantLaws: [
      "Right to Information Act, 2005",
      "RTI Rules (Central & State)"
    ],
    tribunals: ["First Appellate Authority", "State Information Commission", "Central Information Commission"]
  },
  {
    id: "cheque-bounce",
    slug: "cheque-bounce",
    icon: Receipt,
    title: "Cheque Bounce Cases",
    shortDescription: "Prosecution and defense in dishonour of cheque cases under Section 138 of the NI Act.",
    fullDescription: "We handle cheque bounce matters from legal notice stage to trial and appeals. We represent both complainants seeking recovery and accused defending against unfounded complaints, with expertise in negotiating settlements.",
    services: [
      "Legal notice under Section 138",
      "Filing of criminal complaints",
      "Defense in cheque bounce cases",
      "Compounding and settlement negotiations",
      "Appeals and revisions"
    ],
    relevantLaws: [
      "Negotiable Instruments Act, 1881 (Section 138-142)",
      "Code of Criminal Procedure, 1973"
    ],
    tribunals: ["Magistrate Courts", "Sessions Court", "High Court"]
  },
  {
    id: "property-law",
    slug: "property-law",
    icon: MapPin,
    title: "Property Law",
    shortDescription: "Title disputes, partition, registration, mutation, and comprehensive property documentation.",
    fullDescription: "Our property law practice covers the entire spectrum of real estate matters - from title verification and due diligence to litigation over disputed properties. We handle partition suits, title disputes, encroachment matters, and land revenue issues.",
    services: [
      "Title verification & due diligence",
      "Property dispute litigation",
      "Partition suits",
      "Encroachment removal",
      "Land revenue matters",
      "Mutation and registration"
    ],
    relevantLaws: [
      "Transfer of Property Act, 1882",
      "Registration Act, 1908",
      "Rajasthan Land Revenue Act",
      "Rajasthan Tenancy Act"
    ],
    tribunals: ["Revenue Courts", "Civil Courts", "High Court"]
  },
  {
    id: "cybercrime-defense",
    slug: "cybercrime-defense",
    icon: Shield,
    title: "Cybercrime Defense",
    shortDescription: "Defense in IT Act matters, online fraud cases, data privacy issues, and digital crimes.",
    fullDescription: "We defend individuals and companies accused of cybercrimes including hacking, data theft, online fraud, and IT Act violations. We also represent victims of cybercrime and handle matters related to digital evidence and data privacy.",
    services: [
      "Defense in IT Act prosecutions",
      "Online fraud case defense",
      "Data privacy advisory",
      "Digital evidence challenges",
      "Cyber defamation matters",
      "Victim representation"
    ],
    relevantLaws: [
      "Information Technology Act, 2000",
      "IT (Amendment) Act, 2008",
      "IT Rules, 2021",
      "Indian Penal Code (cyber offenses)"
    ],
    tribunals: ["Cyber Crime Cells", "Sessions Courts", "High Court"]
  },
  {
    id: "legal-documentation",
    slug: "legal-documentation",
    icon: FileText,
    title: "Legal Documentation",
    shortDescription: "Drafting and vetting of contracts, agreements, deeds, and all legal instruments.",
    fullDescription: "We provide comprehensive legal documentation services including drafting, vetting, and registration of all types of legal instruments. Our practice covers commercial contracts, property documents, partnership deeds, and corporate agreements.",
    services: [
      "Contract drafting & vetting",
      "Sale deeds & conveyancing",
      "Lease and rental agreements",
      "Partnership & LLP agreements",
      "Wills and succession documents",
      "Power of Attorney",
      "Affidavits and declarations"
    ],
    relevantLaws: [
      "Indian Contract Act, 1872",
      "Registration Act, 1908",
      "Indian Stamp Act, 1899",
      "Transfer of Property Act, 1882"
    ]
  }
];

export const featuredPracticeAreas = practiceAreas.filter(area => area.featured);
