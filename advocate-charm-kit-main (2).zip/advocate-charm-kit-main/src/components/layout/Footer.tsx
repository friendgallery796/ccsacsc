import { Phone, Mail, MapPin, Facebook, Twitter, Linkedin } from "lucide-react";
import { Link } from "react-router-dom";
import logo from "@/assets/logo.jpg";

const quickLinks = [
  { label: "About Us", href: "#about" },
  { label: "Practice Areas", href: "/practice-areas" },
  { label: "Our Team", href: "/team" },
  { label: "Testimonials", href: "#testimonials" },
  { label: "Contact", href: "/contact" },
];

const practiceAreas = [
  { label: "Civil & Criminal Litigation", href: "/practice-areas" },
  { label: "NCLT & Insolvency", href: "/practice-areas" },
  { label: "RERA Matters", href: "/practice-areas" },
  { label: "Matrimonial & Family Law", href: "/practice-areas" },
  { label: "Consumer Protection", href: "/practice-areas" },
  { label: "Cheque Bounce Cases", href: "/practice-areas" },
];

export function Footer() {
  return (
    <footer className="bg-foreground text-background">
      <div className="container mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* About Column */}
          <div className="lg:col-span-1">
            <Link to="/" className="flex items-center gap-3 mb-6">
              <img src={logo} alt="Tanwar & Associates Logo" className="w-12 h-12 rounded-full object-cover" />
              <div>
                <span className="font-heading text-lg font-semibold">Tanwar</span>
                <span className="font-heading text-lg font-light text-primary"> & Associates</span>
              </div>
            </Link>
            <p className="text-background/70 text-sm mb-6 leading-relaxed">
              Dedicated to providing exceptional legal representation with compassion and integrity. 
              Serving clients across India for over 25 years.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-background/70 hover:text-primary transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-background/70 hover:text-primary transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-background/70 hover:text-primary transition-colors">
                <Linkedin className="h-5 w-5" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading text-lg font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.label}>
                  {link.href.startsWith("/") ? (
                    <Link
                      to={link.href}
                      className="text-background/70 hover:text-primary transition-colors text-sm"
                    >
                      {link.label}
                    </Link>
                  ) : (
                    <a
                      href={link.href}
                      className="text-background/70 hover:text-primary transition-colors text-sm"
                    >
                      {link.label}
                    </a>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Practice Areas */}
          <div>
            <h4 className="font-heading text-lg font-semibold mb-6">Practice Areas</h4>
            <ul className="space-y-3">
              {practiceAreas.map((area) => (
                <li key={area.label}>
                  <Link
                    to={area.href}
                    className="text-background/70 hover:text-primary transition-colors text-sm"
                  >
                    {area.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-heading text-lg font-semibold mb-6">Contact Us</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="tel:+919876543210"
                  className="flex items-start gap-3 text-background/70 hover:text-primary transition-colors text-sm"
                >
                  <Phone className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>+91 98765 43210</span>
                </a>
              </li>
              <li>
                <a
                  href="mailto:info@tanwarassociates.in"
                  className="flex items-start gap-3 text-background/70 hover:text-primary transition-colors text-sm"
                >
                  <Mail className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>info@tanwarassociates.in</span>
                </a>
              </li>
              <li>
                <Link 
                  to="/contact"
                  className="flex items-start gap-3 text-background/70 hover:text-primary transition-colors text-sm"
                >
                  <MapPin className="h-4 w-4 mt-0.5 flex-shrink-0" />
                  <span>
                    Chamber No. 456, Rajasthan High Court
                    <br />
                    Jodhpur - 342001
                  </span>
                </Link>
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-background/10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-background/60">
            <p>© {new Date().getFullYear()} Tanwar & Associates. All rights reserved.</p>
            <p className="text-center md:text-right">
              As per the Bar Council of India rules, solicitation of work and advertising is prohibited.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
