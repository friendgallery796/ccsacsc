import { motion } from "framer-motion";
import { Scale, Calendar, Award } from "lucide-react";
import type { CaseResult } from "@/data/teamMembers";

interface AttorneyCaseHistoryProps {
  cases: CaseResult[];
  attorneyName: string;
}

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, x: -20 },
  visible: {
    opacity: 1,
    x: 0,
    transition: { duration: 0.4 },
  },
};

export function AttorneyCaseHistory({ cases, attorneyName }: AttorneyCaseHistoryProps) {
  if (cases.length === 0) {
    return null;
  }

  return (
    <section className="py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="mb-8"
      >
        <h2 className="font-heading text-2xl md:text-3xl font-bold text-foreground mb-2">
          Notable Case Results
        </h2>
        <p className="text-muted-foreground">
          Selected cases demonstrating {attorneyName.split(" ")[1]}'s expertise and successful outcomes.
        </p>
      </motion.div>

      <motion.div
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true }}
        className="space-y-4"
      >
        {cases.map((caseResult) => (
          <motion.div
            key={caseResult.id}
            variants={cardVariants}
            className="bg-card border border-border rounded-xl p-6 hover:shadow-lg transition-shadow"
          >
            <div className="flex flex-col md:flex-row md:items-start gap-4">
              <div className="flex-shrink-0">
                <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                  <Scale className="h-6 w-6 text-primary" />
                </div>
              </div>

              <div className="flex-grow">
                <div className="flex flex-wrap items-center gap-3 mb-2">
                  <h3 className="font-heading text-lg font-semibold text-foreground">
                    {caseResult.title}
                  </h3>
                  <span className="px-2.5 py-0.5 bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 text-xs font-medium rounded-full flex items-center gap-1">
                    <Award className="h-3 w-3" />
                    {caseResult.outcome}
                  </span>
                </div>

                <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground mb-3">
                  <span className="flex items-center gap-1">
                    <Scale className="h-3.5 w-3.5" />
                    {caseResult.court}
                  </span>
                  <span className="flex items-center gap-1">
                    <Calendar className="h-3.5 w-3.5" />
                    {caseResult.year}
                  </span>
                </div>

                <p className="text-muted-foreground text-sm">
                  {caseResult.description}
                </p>
              </div>
            </div>
          </motion.div>
        ))}
      </motion.div>

      <p className="text-xs text-muted-foreground mt-6 italic">
        * Case names may have been modified to protect client confidentiality. Past results do not guarantee similar outcomes in future cases.
      </p>
    </section>
  );
}
