import { motion } from "framer-motion";
import { GraduationCap, Award, Languages, User, Phone, Mail, Scale, ArrowLeft } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import type { TeamMember } from "@/data/teamMembers";

interface AttorneyBioProps {
  attorney: TeamMember;
}

export function AttorneyBio({ attorney }: AttorneyBioProps) {
  const yearsOfExperience = new Date().getFullYear() - attorney.enrollmentYear;

  return (
    <section className="pt-32 pb-12 bg-gradient-to-b from-secondary to-background">
      <div className="container mx-auto px-4">
        {/* Back Link */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="mb-8"
        >
          <Link to="/team">
            <Button variant="ghost" className="text-muted-foreground hover:text-foreground">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back to Team
            </Button>
          </Link>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 lg:gap-12">
          {/* Photo & Quick Info */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="lg:col-span-1"
          >
            {/* Image Placeholder */}
            <div className="aspect-[3/4] bg-muted rounded-xl flex items-center justify-center relative overflow-hidden mb-6">
              <div className="absolute inset-0 bg-gradient-to-b from-transparent to-foreground/5" />
              <User className="h-32 w-32 text-muted-foreground/30" />
              <div className="absolute bottom-4 left-4 right-4">
                <span className="inline-block px-3 py-1 bg-primary text-primary-foreground text-sm font-medium rounded-full">
                  {attorney.isPartner ? "Partner" : "Associate"}
                </span>
              </div>
            </div>

            {/* Quick Contact */}
            <div className="bg-card border border-border rounded-xl p-6 space-y-4">
              <h3 className="font-heading text-lg font-semibold text-foreground">
                Contact Information
              </h3>
              <a
                href={`tel:${attorney.phone.replace(/\s/g, "")}`}
                className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors"
              >
                <Phone className="h-5 w-5 flex-shrink-0" />
                <span>{attorney.phone}</span>
              </a>
              <a
                href={`mailto:${attorney.email}`}
                className="flex items-center gap-3 text-muted-foreground hover:text-primary transition-colors break-all"
              >
                <Mail className="h-5 w-5 flex-shrink-0" />
                <span>{attorney.email}</span>
              </a>
              <div className="flex items-center gap-3 text-muted-foreground">
                <Scale className="h-5 w-5 flex-shrink-0" />
                <span>Bar Council: {attorney.barCouncil}</span>
              </div>
            </div>
          </motion.div>

          {/* Main Bio Content */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="lg:col-span-2"
          >
            <span className="inline-block px-4 py-1.5 bg-primary/10 text-primary text-sm font-medium rounded-full mb-4">
              {attorney.designation}
            </span>

            <h1 className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4">
              {attorney.name}
            </h1>

            <p className="text-lg text-muted-foreground mb-2">
              {attorney.qualifications}
            </p>

            <p className="text-primary font-medium mb-6">
              {yearsOfExperience}+ Years of Legal Practice
            </p>

            {/* Specializations */}
            <div className="flex flex-wrap gap-2 mb-8">
              {attorney.specializations.map((spec) => (
                <span
                  key={spec}
                  className="px-3 py-1 bg-secondary text-foreground text-sm rounded-full"
                >
                  {spec}
                </span>
              ))}
            </div>

            {/* Full Bio */}
            <div className="prose prose-neutral dark:prose-invert max-w-none mb-8">
              {attorney.fullBio.split("\n\n").map((paragraph, index) => (
                <p key={index} className="text-muted-foreground leading-relaxed mb-4">
                  {paragraph}
                </p>
              ))}
            </div>

            {/* Education, Awards, Languages */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Education */}
              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <GraduationCap className="h-5 w-5 text-primary" />
                  <h3 className="font-heading font-semibold text-foreground">Education</h3>
                </div>
                <ul className="space-y-2">
                  {attorney.education.map((edu, index) => (
                    <li key={index} className="text-sm text-muted-foreground">
                      {edu}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Awards */}
              {attorney.awards.length > 0 && (
                <div className="bg-card border border-border rounded-xl p-5">
                  <div className="flex items-center gap-2 mb-4">
                    <Award className="h-5 w-5 text-primary" />
                    <h3 className="font-heading font-semibold text-foreground">Recognition</h3>
                  </div>
                  <ul className="space-y-2">
                    {attorney.awards.map((award, index) => (
                      <li key={index} className="text-sm text-muted-foreground">
                        {award}
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {/* Languages */}
              <div className="bg-card border border-border rounded-xl p-5">
                <div className="flex items-center gap-2 mb-4">
                  <Languages className="h-5 w-5 text-primary" />
                  <h3 className="font-heading font-semibold text-foreground">Languages</h3>
                </div>
                <div className="flex flex-wrap gap-2">
                  {attorney.languages.map((lang) => (
                    <span
                      key={lang}
                      className="px-2.5 py-1 bg-secondary text-foreground text-sm rounded-full"
                    >
                      {lang}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
