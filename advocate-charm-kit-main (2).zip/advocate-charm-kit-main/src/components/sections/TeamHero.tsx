import { motion } from "framer-motion";

export function TeamHero() {
  return (
    <section className="pt-32 pb-16 bg-gradient-to-b from-secondary to-background">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto"
        >
          <span className="inline-block px-4 py-1.5 bg-primary/10 text-primary text-sm font-medium rounded-full mb-6">
            Our Legal Team
          </span>
          <h1 className="font-heading text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6">
            Meet the <span className="text-primary">Advocates</span> Fighting for You
          </h1>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Our team of experienced advocates brings decades of combined legal expertise 
            across civil, criminal, and corporate law. We are committed to delivering 
            justice with integrity and dedication.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
