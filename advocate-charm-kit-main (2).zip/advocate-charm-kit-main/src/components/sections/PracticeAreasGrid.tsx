import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, X, CheckCircle, BookOpen, Building } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { practiceAreas, PracticeArea } from "@/data/practiceAreas";
import { Link } from "react-router-dom";

export function PracticeAreasGrid() {
  const [selectedArea, setSelectedArea] = useState<PracticeArea | null>(null);

  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        {/* Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {practiceAreas.map((area, index) => (
            <motion.div
              key={area.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.05 }}
              viewport={{ once: true }}
            >
              <Card 
                className={`group h-full bg-card hover:shadow-xl transition-all duration-300 border-border hover:border-primary/40 cursor-pointer ${
                  area.featured ? "ring-1 ring-primary/20" : ""
                }`}
                onClick={() => setSelectedArea(area)}
              >
                <CardContent className="p-6 flex flex-col h-full">
                  {area.featured && (
                    <span className="text-[10px] font-semibold uppercase tracking-wider text-primary mb-3">
                      Featured
                    </span>
                  )}
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary group-hover:scale-110 transition-all duration-300">
                    <area.icon className="h-6 w-6 text-primary group-hover:text-primary-foreground transition-colors duration-300" />
                  </div>
                  <h3 className="font-heading text-lg font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                    {area.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed flex-grow line-clamp-3">
                    {area.shortDescription}
                  </p>
                  <div className="flex items-center text-primary text-sm font-medium mt-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span>View Details</span>
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Detail Modal */}
        <AnimatePresence>
          {selectedArea && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-sm"
              onClick={() => setSelectedArea(null)}
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.95, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95, y: 20 }}
                transition={{ duration: 0.2 }}
                className="bg-card border border-border rounded-2xl shadow-2xl max-w-2xl w-full max-h-[85vh] overflow-y-auto"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Header */}
                <div className="sticky top-0 bg-card border-b border-border p-6 flex items-start justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                      <selectedArea.icon className="h-7 w-7 text-primary" />
                    </div>
                    <div>
                      <h2 className="font-heading text-2xl font-bold text-foreground">
                        {selectedArea.title}
                      </h2>
                      {selectedArea.featured && (
                        <span className="text-xs font-medium text-primary">Featured Practice Area</span>
                      )}
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setSelectedArea(null)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="h-5 w-5" />
                  </Button>
                </div>

                {/* Content */}
                <div className="p-6 space-y-6">
                  {/* Description */}
                  <p className="text-muted-foreground leading-relaxed">
                    {selectedArea.fullDescription}
                  </p>

                  {/* Services */}
                  <div>
                    <h4 className="flex items-center gap-2 font-heading text-lg font-semibold text-foreground mb-3">
                      <CheckCircle className="h-5 w-5 text-primary" />
                      Services We Offer
                    </h4>
                    <ul className="grid sm:grid-cols-2 gap-2">
                      {selectedArea.services.map((service) => (
                        <li key={service} className="flex items-start gap-2 text-sm text-muted-foreground">
                          <span className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                          {service}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Relevant Laws */}
                  <div>
                    <h4 className="flex items-center gap-2 font-heading text-lg font-semibold text-foreground mb-3">
                      <BookOpen className="h-5 w-5 text-primary" />
                      Relevant Laws & Acts
                    </h4>
                    <div className="flex flex-wrap gap-2">
                      {selectedArea.relevantLaws.map((law) => (
                        <span
                          key={law}
                          className="px-3 py-1.5 bg-primary/10 text-primary text-xs rounded-full font-medium"
                        >
                          {law}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Tribunals */}
                  {selectedArea.tribunals && selectedArea.tribunals.length > 0 && (
                    <div>
                      <h4 className="flex items-center gap-2 font-heading text-lg font-semibold text-foreground mb-3">
                        <Building className="h-5 w-5 text-primary" />
                        Courts & Tribunals
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedArea.tribunals.map((tribunal) => (
                          <span
                            key={tribunal}
                            className="px-3 py-1.5 bg-muted text-muted-foreground text-xs rounded-full"
                          >
                            {tribunal}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* CTA */}
                  <div className="pt-4 border-t border-border">
                    <Link to="/#contact">
                      <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                        Schedule a Consultation
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
