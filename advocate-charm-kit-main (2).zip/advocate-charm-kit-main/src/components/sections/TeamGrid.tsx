import { motion } from "framer-motion";
import { Phone, Mail, Scale, User } from "lucide-react";
import { Link } from "react-router-dom";
import { teamMembers, type TeamMember } from "@/data/teamMembers";

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

function TeamCard({ member }: { member: TeamMember }) {
  return (
    <motion.div variants={cardVariants}>
      <Link
        to={`/team/${member.slug}`}
        className={`block bg-card border border-border rounded-xl overflow-hidden hover:shadow-xl transition-all duration-300 hover:-translate-y-1 group ${
          member.isPartner ? "lg:col-span-1" : ""
        }`}
      >
        {/* Image Placeholder */}
        <div className="aspect-[4/5] bg-muted flex items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-transparent to-foreground/5" />
          <User className="h-24 w-24 text-muted-foreground/30 group-hover:scale-110 transition-transform duration-300" />
          <div className="absolute bottom-4 left-4 right-4">
            <span className="inline-block px-3 py-1 bg-primary text-primary-foreground text-xs font-medium rounded-full">
              {member.isPartner ? "Partner" : "Associate"}
            </span>
          </div>
        </div>

        {/* Content */}
        <div className="p-6">
          <h3 className="font-heading text-xl font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">
            {member.name}
          </h3>
          <p className="text-primary font-medium text-sm mb-2">{member.designation}</p>
          <p className="text-muted-foreground text-xs mb-3">{member.qualifications}</p>
          
          <div className="flex items-center gap-2 text-xs text-muted-foreground mb-4">
            <Scale className="h-3 w-3" />
            <span>Bar Council: {member.barCouncil}</span>
          </div>

          {/* Specializations */}
          <div className="flex flex-wrap gap-1.5 mb-4">
            {member.specializations.map((spec) => (
              <span
                key={spec}
                className="px-2 py-0.5 bg-secondary text-foreground text-xs rounded-full"
              >
                {spec}
              </span>
            ))}
          </div>

          {/* Bio */}
          <p className="text-muted-foreground text-sm mb-4 line-clamp-3">{member.bio}</p>

          {/* Contact */}
          <div className="flex flex-col gap-2 pt-4 border-t border-border">
            <span className="flex items-center gap-2 text-sm text-muted-foreground">
              <Phone className="h-4 w-4" />
              <span>{member.phone}</span>
            </span>
            <span className="flex items-center gap-2 text-sm text-muted-foreground truncate">
              <Mail className="h-4 w-4 flex-shrink-0" />
              <span className="truncate">{member.email}</span>
            </span>
          </div>

          {/* View Profile CTA */}
          <div className="mt-4 pt-4 border-t border-border">
            <span className="text-primary text-sm font-medium group-hover:underline">
              View Full Profile →
            </span>
          </div>
        </div>
      </Link>
    </motion.div>
  );
}

export function TeamGrid() {
  const partners = teamMembers.filter((m) => m.isPartner);
  const associates = teamMembers.filter((m) => !m.isPartner);

  return (
    <section className="py-16 bg-background">
      <div className="container mx-auto px-4">
        {/* Partners Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Partners
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            The founding partners bring decades of experience and a track record of success 
            across India's highest courts.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-20"
        >
          {partners.map((member) => (
            <TeamCard key={member.id} member={member} />
          ))}
        </motion.div>

        {/* Associates Section */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="text-center mb-12"
        >
          <h2 className="font-heading text-3xl md:text-4xl font-bold text-foreground mb-4">
            Our Associates
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our talented associates provide dedicated support across all practice areas, 
            ensuring comprehensive legal solutions for our clients.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6"
        >
          {associates.map((member) => (
            <TeamCard key={member.id} member={member} />
          ))}
        </motion.div>
      </div>
    </section>
  );
}
