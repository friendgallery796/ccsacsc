import { motion } from "framer-motion";
import { Award, Users, Clock, Shield } from "lucide-react";

const reasons = [
  {
    icon: Award,
    title: "Proven Track Record",
    description: "Over $500 million recovered for our clients with a 98% success rate in cases we take to trial.",
  },
  {
    icon: Users,
    title: "Personalized Attention",
    description: "Every case is handled with individual care. You'll work directly with experienced attorneys, not paralegals.",
  },
  {
    icon: Clock,
    title: "Available 24/7",
    description: "Legal emergencies don't wait for business hours. We're here when you need us, day or night.",
  },
  {
    icon: Shield,
    title: "No Win, No Fee",
    description: "For personal injury cases, you pay nothing unless we win. We believe in your case as much as you do.",
  },
];

export function WhyChooseUs() {
  return (
    <section id="about" className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <span className="text-primary text-sm font-semibold uppercase tracking-wider">
              Why Choose Us
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground mt-2 mb-6">
              A Law Firm That Treats You Like Family
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              At Harrison & Associates, we understand that facing a legal challenge can be one of 
              the most stressful experiences of your life. That's why we combine aggressive advocacy 
              with genuine compassion—fighting fiercely for your rights while treating you with the 
              respect and care you deserve.
            </p>
            <div className="space-y-6">
              {reasons.slice(0, 2).map((reason, index) => (
                <motion.div
                  key={reason.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="flex gap-4"
                >
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <reason.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-heading text-lg font-semibold text-foreground mb-1">
                      {reason.title}
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      {reason.description}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Right Content */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            {reasons.slice(2).map((reason, index) => (
              <motion.div
                key={reason.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
                className="bg-card p-6 rounded-xl shadow-md border border-border"
              >
                <div className="flex gap-4">
                  <div className="flex-shrink-0 w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                    <reason.icon className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h4 className="font-heading text-lg font-semibold text-foreground mb-1">
                      {reason.title}
                    </h4>
                    <p className="text-muted-foreground text-sm">
                      {reason.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}

            {/* Quote Card */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              viewport={{ once: true }}
              className="bg-primary p-6 rounded-xl"
            >
              <blockquote className="text-primary-foreground">
                <p className="font-heading text-lg italic mb-4">
                  "Our commitment is simple: we fight for justice as if it were our own family's 
                  case—because that's exactly how we see it."
                </p>
                <footer className="text-primary-foreground/80 text-sm">
                  — James Harrison, Founding Partner
                </footer>
              </blockquote>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
