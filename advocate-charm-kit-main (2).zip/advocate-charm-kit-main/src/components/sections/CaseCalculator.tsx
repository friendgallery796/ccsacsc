import { useState } from "react";
import { motion } from "framer-motion";
import { Calculator, IndianRupee, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const caseTypes = [
  { value: "mact", label: "Motor Accident Claim (MACT)", multiplier: 1.5 },
  { value: "medical-negligence", label: "Medical Negligence", multiplier: 2.0 },
  { value: "consumer-dispute", label: "Consumer Dispute (NCDRC)", multiplier: 1.3 },
  { value: "workplace-injury", label: "Workplace Injury (ESIC)", multiplier: 1.4 },
  { value: "death-compensation", label: "Death Compensation", multiplier: 2.5 },
  { value: "insurance-claim", label: "Insurance Claim Dispute", multiplier: 1.2 },
  { value: "railway-accident", label: "Railway Accident Claim", multiplier: 1.8 },
  { value: "road-traffic", label: "Road Traffic Accident", multiplier: 1.4 },
];

const severityLevels = [
  { value: "minor", label: "Minor Injury (Simple)", multiplier: 0.5 },
  { value: "moderate", label: "Moderate Injury (Grievous Simple)", multiplier: 1.0 },
  { value: "serious", label: "Serious Injury (Grievous)", multiplier: 1.8 },
  { value: "permanent", label: "Permanent Disability", multiplier: 2.5 },
  { value: "total", label: "Total Disability / Fatal", multiplier: 4.0 },
];

// Format number in Indian numbering system (lakhs, crores)
const formatIndianCurrency = (num: number): string => {
  return "₹" + num.toLocaleString("en-IN");
};

// Format in lakhs for display
const formatInLakhs = (num: number): string => {
  if (num >= 10000000) {
    return `₹${(num / 10000000).toFixed(1)} Cr`;
  } else if (num >= 100000) {
    return `₹${(num / 100000).toFixed(1)} L`;
  }
  return formatIndianCurrency(num);
};

export function CaseCalculator() {
  const [caseType, setCaseType] = useState("");
  const [severity, setSeverity] = useState("");
  const [medicalBills, setMedicalBills] = useState([250000]);
  const [lostWages, setLostWages] = useState([100000]);

  const calculateEstimate = () => {
    if (!caseType || !severity) return null;

    const caseMultiplier = caseTypes.find((c) => c.value === caseType)?.multiplier || 1;
    const severityMultiplier = severityLevels.find((s) => s.value === severity)?.multiplier || 1;

    const baseDamages = medicalBills[0] + lostWages[0];
    const painAndSuffering = medicalBills[0] * severityMultiplier;
    const totalEstimate = (baseDamages + painAndSuffering) * caseMultiplier;

    return {
      low: Math.round(totalEstimate * 0.7),
      high: Math.round(totalEstimate * 1.3),
      average: Math.round(totalEstimate),
    };
  };

  const estimate = calculateEstimate();

  return (
    <section className="py-20 bg-secondary">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-primary text-sm font-semibold uppercase tracking-wider">
              Free Tool
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground mt-2 mb-4">
              Case Value Calculator
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Get a preliminary estimate of your case value under Indian law. This tool provides a general range 
              based on MACT guidelines and tribunal precedents—actual values may vary significantly.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="bg-card rounded-2xl shadow-lg border border-border overflow-hidden"
          >
            <div className="grid lg:grid-cols-2">
              {/* Input Section */}
              <div className="p-8 space-y-6">
                <div className="flex items-center gap-3 mb-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                    <Calculator className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="font-heading text-xl font-semibold text-foreground">
                    Enter Your Details
                  </h3>
                </div>

                {/* Case Type */}
                <div className="space-y-2">
                  <Label>Type of Case</Label>
                  <Select value={caseType} onValueChange={setCaseType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select case type" />
                    </SelectTrigger>
                    <SelectContent>
                      {caseTypes.map((type) => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Severity */}
                <div className="space-y-2">
                  <Label>Injury Severity</Label>
                  <Select value={severity} onValueChange={setSeverity}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select severity level" />
                    </SelectTrigger>
                    <SelectContent>
                      {severityLevels.map((level) => (
                        <SelectItem key={level.value} value={level.value}>
                          {level.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                {/* Medical Bills Slider */}
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <Label>Medical Expenses (Estimated)</Label>
                    <span className="text-primary font-semibold">
                      {formatIndianCurrency(medicalBills[0])}
                    </span>
                  </div>
                  <Slider
                    value={medicalBills}
                    onValueChange={setMedicalBills}
                    min={10000}
                    max={5000000}
                    step={10000}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>₹10,000</span>
                    <span>₹50 Lakhs</span>
                  </div>
                </div>

                {/* Lost Wages Slider */}
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <Label>Lost Income / Wages</Label>
                    <span className="text-primary font-semibold">
                      {formatIndianCurrency(lostWages[0])}
                    </span>
                  </div>
                  <Slider
                    value={lostWages}
                    onValueChange={setLostWages}
                    min={0}
                    max={2500000}
                    step={10000}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>₹0</span>
                    <span>₹25 Lakhs</span>
                  </div>
                </div>
              </div>

              {/* Results Section */}
              <div className="bg-primary/5 p-8 flex flex-col justify-center">
                {estimate ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3 }}
                    className="text-center"
                  >
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-6">
                      <IndianRupee className="h-8 w-8 text-primary" />
                    </div>
                    <p className="text-muted-foreground text-sm mb-2">Estimated Compensation Value</p>
                    <p className="font-heading text-4xl sm:text-5xl font-bold text-primary mb-2">
                      {formatInLakhs(estimate.average)}
                    </p>
                    <p className="text-muted-foreground text-sm mb-6">
                      Range: {formatInLakhs(estimate.low)} - {formatInLakhs(estimate.high)}
                    </p>

                    <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mb-4">
                      Get Free Case Review
                    </Button>

                    <p className="text-xs text-muted-foreground">
                      No obligation • Confidential consultation
                    </p>
                  </motion.div>
                ) : (
                  <div className="text-center">
                    <div className="w-16 h-16 bg-muted rounded-full flex items-center justify-center mx-auto mb-6">
                      <Calculator className="h-8 w-8 text-muted-foreground" />
                    </div>
                    <p className="text-muted-foreground">
                      Select your case type and injury severity to see an estimate
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Disclaimer */}
            <div className="bg-muted/50 px-8 py-4 flex items-start gap-3">
              <AlertTriangle className="h-5 w-5 text-accent flex-shrink-0 mt-0.5" />
              <p className="text-xs text-muted-foreground">
                <strong>Disclaimer:</strong> This calculator provides rough estimates based on Motor Vehicles Act, 1988, 
                Consumer Protection Act, 2019, and relevant Supreme Court & High Court guidelines. Actual compensation 
                depends on factors including evidence, tribunal/court jurisdiction, structured settlement, multiplier method, 
                and insurance policy limits. This does not constitute legal advice under the Advocates Act, 1961. 
                Contact us for a free, confidential case evaluation.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
