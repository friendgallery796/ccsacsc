import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Check, ChevronRight, User, FileText, MessageSquare } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { toast } from "@/hooks/use-toast";

const caseTypes = [
  { value: "personal-injury", label: "Personal Injury" },
  { value: "medical-malpractice", label: "Medical Malpractice" },
  { value: "family-law", label: "Family Law" },
  { value: "criminal-defense", label: "Criminal Defense" },
  { value: "estate-planning", label: "Estate Planning" },
  { value: "business-law", label: "Business Law" },
  { value: "other", label: "Other" },
];

const steps = [
  { id: 1, title: "Case Type", icon: FileText },
  { id: 2, title: "Contact Info", icon: User },
  { id: 3, title: "Case Details", icon: MessageSquare },
];

export function ConsultationForm() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    caseType: "",
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    caseDetails: "",
    howDidYouHear: "",
  });

  const updateFormData = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (currentStep < 3) {
      setCurrentStep((prev) => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => prev - 1);
    }
  };

  const handleSubmit = () => {
    toast({
      title: "Consultation Request Submitted!",
      description: "We'll contact you within 24 hours to schedule your free consultation.",
    });
    // Reset form
    setCurrentStep(1);
    setFormData({
      caseType: "",
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      caseDetails: "",
      howDidYouHear: "",
    });
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return formData.caseType !== "";
      case 2:
        return formData.firstName && formData.lastName && formData.email && formData.phone;
      case 3:
        return formData.caseDetails.length > 10;
      default:
        return false;
    }
  };

  return (
    <section id="contact" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto">
          {/* Section Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <span className="text-primary text-sm font-semibold uppercase tracking-wider">
              Get Started
            </span>
            <h2 className="font-heading text-3xl sm:text-4xl font-bold text-foreground mt-2 mb-4">
              Schedule Your Free Consultation
            </h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Take the first step toward justice. Fill out this form and one of our attorneys 
              will contact you within 24 hours.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="bg-card rounded-2xl shadow-lg border border-border p-8"
          >
            {/* Progress Steps */}
            <div className="flex items-center justify-center mb-10">
              {steps.map((step, index) => (
                <div key={step.id} className="flex items-center">
                  <div
                    className={`flex items-center justify-center w-10 h-10 rounded-full border-2 transition-all duration-300 ${
                      currentStep > step.id
                        ? "bg-primary border-primary"
                        : currentStep === step.id
                        ? "border-primary text-primary"
                        : "border-muted text-muted-foreground"
                    }`}
                  >
                    {currentStep > step.id ? (
                      <Check className="h-5 w-5 text-primary-foreground" />
                    ) : (
                      <step.icon className="h-5 w-5" />
                    )}
                  </div>
                  <span
                    className={`hidden sm:block ml-2 text-sm font-medium ${
                      currentStep >= step.id ? "text-foreground" : "text-muted-foreground"
                    }`}
                  >
                    {step.title}
                  </span>
                  {index < steps.length - 1 && (
                    <div
                      className={`w-12 sm:w-20 h-0.5 mx-4 transition-all duration-300 ${
                        currentStep > step.id ? "bg-primary" : "bg-muted"
                      }`}
                    />
                  )}
                </div>
              ))}
            </div>

            {/* Form Steps */}
            <AnimatePresence mode="wait">
              {currentStep === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div>
                    <Label className="text-base mb-4 block">What type of legal matter do you need help with?</Label>
                    <RadioGroup
                      value={formData.caseType}
                      onValueChange={(value) => updateFormData("caseType", value)}
                      className="grid grid-cols-1 sm:grid-cols-2 gap-3"
                    >
                      {caseTypes.map((type) => (
                        <div key={type.value}>
                          <RadioGroupItem
                            value={type.value}
                            id={type.value}
                            className="peer sr-only"
                          />
                          <Label
                            htmlFor={type.value}
                            className="flex items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary cursor-pointer transition-all"
                          >
                            {type.label}
                            {formData.caseType === type.value && (
                              <Check className="h-5 w-5 text-primary" />
                            )}
                          </Label>
                        </div>
                      ))}
                    </RadioGroup>
                  </div>
                </motion.div>
              )}

              {currentStep === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="firstName">First Name *</Label>
                      <Input
                        id="firstName"
                        value={formData.firstName}
                        onChange={(e) => updateFormData("firstName", e.target.value)}
                        placeholder="John"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="lastName">Last Name *</Label>
                      <Input
                        id="lastName"
                        value={formData.lastName}
                        onChange={(e) => updateFormData("lastName", e.target.value)}
                        placeholder="Doe"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email Address *</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                      placeholder="john.doe@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number *</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => updateFormData("phone", e.target.value)}
                      placeholder="(555) 123-4567"
                    />
                  </div>
                </motion.div>
              )}

              {currentStep === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.3 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <Label htmlFor="caseDetails">Please describe your case *</Label>
                    <Textarea
                      id="caseDetails"
                      value={formData.caseDetails}
                      onChange={(e) => updateFormData("caseDetails", e.target.value)}
                      placeholder="Please provide a brief description of your legal matter..."
                      rows={5}
                    />
                    <p className="text-xs text-muted-foreground">
                      Your information is confidential and protected by attorney-client privilege.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="howDidYouHear">How did you hear about us? (Optional)</Label>
                    <Input
                      id="howDidYouHear"
                      value={formData.howDidYouHear}
                      onChange={(e) => updateFormData("howDidYouHear", e.target.value)}
                      placeholder="Referral, Google, Social Media, etc."
                    />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Navigation Buttons */}
            <div className="flex justify-between mt-8 pt-6 border-t border-border">
              <Button
                variant="outline"
                onClick={handleBack}
                disabled={currentStep === 1}
                className="border-primary text-primary hover:bg-primary hover:text-primary-foreground"
              >
                Back
              </Button>
              {currentStep < 3 ? (
                <Button
                  onClick={handleNext}
                  disabled={!isStepValid()}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Continue
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button
                  onClick={handleSubmit}
                  disabled={!isStepValid()}
                  className="bg-primary hover:bg-primary/90 text-primary-foreground"
                >
                  Submit Request
                </Button>
              )}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
