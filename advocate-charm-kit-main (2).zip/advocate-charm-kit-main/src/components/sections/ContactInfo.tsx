import { motion } from "framer-motion";
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  MessageCircle,
  Building
} from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const contactDetails = [
  {
    icon: Phone,
    title: "Phone",
    details: ["+91 98765 43210", "+91 141 234 5678"],
    action: "tel:+919876543210",
    actionText: "Call Now"
  },
  {
    icon: Mail,
    title: "Email",
    details: ["info@tanwarassociates.in", "legal@tanwarassociates.in"],
    action: "mailto:info@tanwarassociates.in",
    actionText: "Send Email"
  },
  {
    icon: MessageCircle,
    title: "WhatsApp",
    details: ["+91 98765 43210"],
    action: "https://wa.me/919876543210",
    actionText: "Chat on WhatsApp"
  }
];

const officeHours = [
  { day: "Monday - Friday", hours: "9:00 AM - 6:00 PM" },
  { day: "Saturday", hours: "10:00 AM - 2:00 PM" },
  { day: "Sunday", hours: "Closed (Emergency calls accepted)" }
];

export function ContactInfo() {
  return (
    <section className="py-16 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left Column - Contact Cards & Hours */}
          <div className="space-y-8">
            {/* Contact Methods */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              viewport={{ once: true }}
            >
              <h2 className="font-heading text-2xl font-bold text-foreground mb-6">
                Reach Out To Us
              </h2>
              <div className="grid sm:grid-cols-2 lg:grid-cols-1 xl:grid-cols-2 gap-4">
                {contactDetails.map((contact, index) => (
                  <motion.div
                    key={contact.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <Card className="h-full bg-card hover:shadow-md transition-shadow">
                      <CardContent className="p-5">
                        <div className="flex items-start gap-4">
                          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                            <contact.icon className="h-5 w-5 text-primary" />
                          </div>
                          <div className="flex-grow">
                            <h3 className="font-heading font-semibold text-foreground mb-1">
                              {contact.title}
                            </h3>
                            {contact.details.map((detail) => (
                              <p key={detail} className="text-sm text-muted-foreground">
                                {detail}
                              </p>
                            ))}
                            <a href={contact.action} target="_blank" rel="noopener noreferrer">
                              <Button 
                                variant="link" 
                                className="p-0 h-auto text-primary text-sm mt-2"
                              >
                                {contact.actionText} →
                              </Button>
                            </a>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>
            </motion.div>

            {/* Office Hours */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              viewport={{ once: true }}
            >
              <Card className="bg-card">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                      <Clock className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="font-heading text-xl font-semibold text-foreground">
                      Office Hours
                    </h3>
                  </div>
                  <div className="space-y-3">
                    {officeHours.map((schedule) => (
                      <div 
                        key={schedule.day} 
                        className="flex justify-between items-center py-2 border-b border-border last:border-0"
                      >
                        <span className="text-foreground font-medium">{schedule.day}</span>
                        <span className="text-muted-foreground text-sm">{schedule.hours}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Right Column - Office Location & Map */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <h2 className="font-heading text-2xl font-bold text-foreground">
              Our Office
            </h2>

            {/* Office Address Card */}
            <Card className="bg-card">
              <CardContent className="p-6">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                    <Building className="h-6 w-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg font-semibold text-foreground mb-2">
                      Rajasthan High Court Chambers
                    </h3>
                    <div className="flex items-start gap-2 text-muted-foreground">
                      <MapPin className="h-4 w-4 mt-1 flex-shrink-0" />
                      <p className="text-sm leading-relaxed">
                        Chamber No. 456, New Building<br />
                        Rajasthan High Court, Jodhpur<br />
                        Rajasthan - 342001, India
                      </p>
                    </div>
                    <a 
                      href="https://maps.google.com/?q=Rajasthan+High+Court+Jodhpur" 
                      target="_blank" 
                      rel="noopener noreferrer"
                    >
                      <Button 
                        variant="outline" 
                        className="mt-4 border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                      >
                        <MapPin className="h-4 w-4 mr-2" />
                        Get Directions
                      </Button>
                    </a>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Map Placeholder */}
            <Card className="bg-card overflow-hidden">
              <div className="relative h-72 bg-muted">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3577.8877!2d72.9963!3d26.2389!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39418c4eaa06ccb9%3A0x8114ea5b0ae1abb8!2sRajasthan%20High%20Court!5e0!3m2!1sen!2sin!4v1234567890"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Rajasthan High Court Location"
                  className="absolute inset-0"
                />
              </div>
            </Card>

            {/* Additional Info */}
            <div className="bg-primary/5 rounded-xl p-5 border border-primary/10">
              <p className="text-sm text-muted-foreground leading-relaxed">
                <span className="font-semibold text-foreground">Note:</span> For urgent matters 
                outside office hours, please call our emergency line. All communications are 
                treated with strict confidentiality as per the Advocates Act, 1961.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
